import UIKit

/// 図面写真 → DrawingRecord(部品一覧+各部品の展開形状)
struct DrawingReader {
    let client: ClaudeClient
    let settings: AppSettings

    init(apiKey: String, settings: AppSettings) {
        self.client = ClaudeClient(apiKey: apiKey, model: settings.model)
        self.settings = settings
    }

    func read(images: [UIImage],
              into base: DrawingRecord,
              progress: @escaping @MainActor (String) -> Void) async throws -> DrawingRecord {
        await progress("写真を拡大タイルに分割中…")
        let prepared = ImagePreprocessor.prepare(images, grid: settings.tileMode.grid)
        guard !prepared.isEmpty else { throw ClaudeError.noToolResult("画像を読み込めませんでした") }

        // 段階A
        await progress("部品を洗い出し中(材質・板厚・数量)…")
        var rec = base
        let inv = try await inventory(prepared)
        apply(inventory: inv, to: &rec)

        // 段階B(レーザー部品だけ、並列)
        let targets = rec.parts.filter { $0.process == .laser }
        await progress("展開形状を読み取り中(0/\(targets.count))…")
        var done = 0
        let snapshot = rec
        var results: [UUID: Result<FlatPattern, Error>] = [:]
        try await withThrowingTaskGroup(of: (UUID, Result<FlatPattern, Error>).self) { group in
            for p in targets {
                group.addTask {
                    do { return (p.id, .success(try await flatPattern(for: p, drawing: snapshot, images: prepared))) }
                    catch { return (p.id, .failure(error)) }
                }
            }
            for try await (id, r) in group {
                results[id] = r
                done += 1
                await progress("展開形状を読み取り中(\(done)/\(targets.count))…")
            }
        }
        for i in rec.parts.indices {
            switch results[rec.parts[i].id] {
            case .success(let f)?: rec.parts[i].flat = f; rec.parts[i].readError = nil
            case .failure(let e)?: rec.parts[i].readError = e.localizedDescription
            case nil: break
            }
        }
        rec.appVersion = AppInfo.version
        return rec
    }

    /// 1部品だけ読み直す(ユーザーのヒント付き)
    func reread(part: Part, drawing: DrawingRecord, images: [UIImage]) async throws -> FlatPattern {
        let prepared = ImagePreprocessor.prepare(images, grid: settings.tileMode.grid)
        return try await flatPattern(for: part, drawing: drawing, images: prepared)
    }

    // MARK: - 段階A

    private func inventory(_ images: [PreparedImage]) async throws -> [String: Any] {
        var content = ClaudeClient.imageBlocks(images, cacheLast: false)
        content.append(["type": "text", "text": "この図面のレーザー加工対象の板部品をすべて洗い出してください。"])
        do {
            return try await client.callTool(system: Prompts.inventorySystem, content: content,
                                             toolName: "report_inventory",
                                             toolDescription: "図面から部品一覧を報告する",
                                             inputSchemaJSON: Prompts.inventorySchema, maxTokens: 8000)
        } catch ClaudeError.truncated {
            return try await client.callTool(system: Prompts.inventorySystem, content: content,
                                             toolName: "report_inventory",
                                             toolDescription: "図面から部品一覧を報告する",
                                             inputSchemaJSON: Prompts.inventorySchema, maxTokens: 20000)
        }
    }

    private func apply(inventory o: [String: Any], to rec: inout DrawingRecord) {
        rec.analysis = J.str(o["analysis"])
        rec.drawingNumber = J.str(o["drawing_number"])
        rec.title = J.str(o["title"])
        rec.productNumber = J.str(o["product_number"])
        rec.notes = J.strs(o["notes"])
        rec.questions = J.strs(o["questions"])
        let defMat = J.str(o["default_material"])
        rec.parts = J.arr(o["parts"]).enumerated().map { (i, p) -> Part in
            var part = Part()
            part.partKey = J.str(p["id"]).isEmpty ? "P\(i + 1)" : J.str(p["id"])
            part.name = J.str(p["name"])
            let m = J.str(p["material"])
            part.material = m.isEmpty ? defMat : m
            part.thickness = J.num(p["thickness_mm"])
            part.thicknessSource = J.str(p["thickness_source"]).isEmpty ? "unknown" : J.str(p["thickness_source"])
            part.thicknessEvidence = J.str(p["thickness_evidence"])
            part.process = PartProcess(rawValue: J.str(p["process"])) ?? .laser
            part.quantity = max(1, Int(J.num(p["quantity"]) ?? 1))
            part.mirrorPair = (p["mirror_pair"] as? Bool) ?? false
            part.bendsCount = Int(J.num(p["bends_count"]) ?? 0)
            part.viewsDescription = J.str(p["views"])
            part.confidence = J.num(p["confidence"]) ?? 0
            part.include = part.process == .laser
            return part
        }
    }

    // MARK: - 段階B

    private func flatPattern(for part: Part, drawing: DrawingRecord, images: [PreparedImage]) async throws -> FlatPattern {
        var content = ClaudeClient.imageBlocks(images, cacheLast: true)
        let others = drawing.parts.filter { $0.id != part.id }
            .map { "\($0.partKey) \($0.name)(\($0.process.label)、t\($0.thickness.map(Fmt.num) ?? "?"))" }
            .joined(separator: " / ")
        var text = """
        対象部品: \(part.partKey)「\(part.name)」
        材質: \(part.material)  板厚: \(part.thickness.map { "t" + Fmt.num($0) } ?? "未確定")  曲げ回数(参考): \(part.bendsCount)
        描かれている場所: \(part.viewsDescription)
        図面の注記: \(drawing.notes.joined(separator: " / "))
        同じ図面の他の部品(これらは出さない): \(others.isEmpty ? "なし" : others)
        この部品1つだけの展開形状を出してください。
        """
        if !part.userHint.isEmpty {
            text += "\n\n【作業者からの指示(最優先)】\n\(part.userHint)"
        }
        content.append(["type": "text", "text": text])
        let system = Prompts.flatSystem(tapTable: settings.tapDrills)
        let out: [String: Any]
        do {
            out = try await client.callTool(system: system, content: content, toolName: "report_flat_pattern",
                                            toolDescription: "1部品の展開形状を報告する",
                                            inputSchemaJSON: Prompts.flatSchema, maxTokens: 16000)
        } catch ClaudeError.truncated {
            out = try await client.callTool(system: system, content: content, toolName: "report_flat_pattern",
                                            toolDescription: "1部品の展開形状を報告する",
                                            inputSchemaJSON: Prompts.flatSchema, maxTokens: 32000)
        }
        return Self.parseFlat(out)
    }

    static func parseFlat(_ o: [String: Any]) -> FlatPattern {
        var f = FlatPattern()
        f.analysis = J.str(o["analysis"])
        f.developedBy = J.str(o["developed_by"]) == "outer_dims" ? .outerDims : .flat
        f.outline = J.arr(o["outline"]).compactMap { (v) -> OutlineVertex? in
            guard let x = J.num(v["x"]), let y = J.num(v["y"]) else { return nil }
            var ov = OutlineVertex(x: x, y: y)
            ov.cornerType = CornerType(rawValue: J.str(v["corner_type"])) ?? .none
            ov.cornerSize = J.num(v["corner_size"]) ?? 0
            if ov.cornerSize <= 0 { ov.cornerType = .none }
            if let a = v["arc_to_next"] as? [String: Any], let cx = J.num(a["cx"]), let cy = J.num(a["cy"]) {
                ov.arcToNext = ArcSpec(cx: cx, cy: cy, clockwise: (a["clockwise"] as? Bool) ?? false)
            }
            return ov
        }
        // 最後の頂点が最初と同じなら除く
        if f.outline.count > 2, let a = f.outline.first, let b = f.outline.last,
           abs(a.x - b.x) < 0.001, abs(a.y - b.y) < 0.001 { f.outline.removeLast() }

        f.holes = J.arr(o["holes"]).compactMap { (h) -> Hole? in
            guard let t = HoleType(rawValue: J.str(h["type"])) else { return nil }
            var hole = Hole(type: t)
            hole.cx = J.num(h["cx"]) ?? 0; hole.cy = J.num(h["cy"]) ?? 0; hole.d = J.num(h["d"]) ?? 0
            hole.x1 = J.num(h["x1"]) ?? 0; hole.y1 = J.num(h["y1"]) ?? 0
            hole.x2 = J.num(h["x2"]) ?? 0; hole.y2 = J.num(h["y2"]) ?? 0
            hole.width = J.num(h["width"]) ?? 0
            hole.w = J.num(h["w"]) ?? 0; hole.h = J.num(h["h"]) ?? 0
            hole.angle = J.num(h["angle"]) ?? 0; hole.cornerR = J.num(h["corner_r"]) ?? 0
            hole.points = (h["points"] as? [Any] ?? []).compactMap { (p) -> P2? in
                guard let a = p as? [Any], a.count >= 2, let x = J.num(a[0]), let y = J.num(a[1]) else { return nil }
                return P2(x: x, y: y)
            }
            hole.note = J.str(h["note"])
            return hole
        }
        f.bends = J.arr(o["bends"]).compactMap { (b) -> Bend? in
            guard let pos = J.num(b["position"]) else { return nil }
            var bend = Bend()
            bend.axis = J.str(b["axis"]) == "y" ? .y : .x
            bend.position = pos
            bend.angleDeg = J.num(b["angle_deg"]) ?? 90
            bend.up = J.str(b["direction"]) != "down"
            bend.note = J.str(b["note"])
            return bend
        }
        f.keyDimensions = J.arr(o["key_dimensions"]).compactMap { (k) -> KeyDimension? in
            guard let v = J.num(k["value"]) else { return nil }
            return KeyDimension(label: J.str(k["label"]), value: v, axis: J.str(k["axis"]))
        }
        f.uncertain = J.strs(o["uncertain"])
        f.confidence = J.num(o["confidence"]) ?? 0
        return f
    }
}

/// 型がぶれても読めるJSONヘルパー(数値が文字列で来ても可)
enum J {
    static func str(_ a: Any?) -> String {
        if let s = a as? String { return s }
        if let n = a as? NSNumber { return n.stringValue }
        return ""
    }
    static func strs(_ a: Any?) -> [String] { (a as? [Any] ?? []).map { str($0) }.filter { !$0.isEmpty } }
    static func arr(_ a: Any?) -> [[String: Any]] { a as? [[String: Any]] ?? [] }
    static func num(_ a: Any?) -> Double? {
        if let n = a as? NSNumber {
            if CFGetTypeID(n) == CFBooleanGetTypeID() { return nil }
            return n.doubleValue
        }
        if let s = a as? String {
            let cleaned = s.replacingOccurrences(of: ",", with: "")
                .trimmingCharacters(in: CharacterSet(charactersIn: " tTφΦmMR"))
            return Double(cleaned)
        }
        return nil
    }
}
