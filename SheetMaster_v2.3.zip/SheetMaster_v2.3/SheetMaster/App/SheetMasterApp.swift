import SwiftUI

@main
struct SheetMasterApp: App {
    @State private var store = AppStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(store)
        }
    }
}

struct ContentView: View {
    var body: some View {
        TabView {
            NavigationStack { DrawingListView() }
                .tabItem { Label("図面", systemImage: "doc.viewfinder") }
            NavigationStack { GroupExportView() }
                .tabItem { Label("板厚別", systemImage: "square.stack.3d.up") }
            NavigationStack { TransferGuideView() }
                .tabItem { Label("転送案内", systemImage: "arrow.right.doc.on.clipboard") }
            NavigationStack { SettingsView() }
                .tabItem { Label("設定", systemImage: "gearshape") }
        }
    }
}
