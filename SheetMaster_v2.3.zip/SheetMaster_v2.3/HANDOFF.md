# SHEET MASTER v2.3 引き継ぎ書(ビルド担当AIへ)

## 目的
v2.2 では、曲げ・溶接組立・複数板厚の図面(例: キャスタベース DM261395J-M042、シュート DM231906J-M091)を読み取れなかった。
v2.3 では読み取り部分を作り直し、**展開した平板の切断データ(DXF)を、材質・板厚ごとに分けて出す**。

## v2.2 で失敗していた原因と対策
| 原因 | v2.3 の対策 | ファイル |
|---|---|---|
| iPhone写真を丸ごと送り、API側で約1568pxに縮小され小さい寸法数字が潰れる | 全体1枚+重なり付き拡大タイル(2×2 / 3×3)に分割、白黒・コントラスト強調 | `Reading/ImagePreprocessor.swift` |
| 自由文の中のJSONを取り出していて、文章混じり・途中切れで失敗 | Messages API の **tool_use を強制**(tool_choice)して必ずJSONで受け取る。max_tokens切れは自動で上限を上げて再試行 | `Reading/ClaudeClient.swift` |
| 1回の呼び出しで全部を出させていた(1枚板前提) | **2段階**: A=部品の洗い出し(材質・板厚・数量・勝手違い・機械加工品の除外) → B=レーザー部品1つずつ展開形状 | `Reading/DrawingReader.swift`, `Reading/Prompts.swift` |
| 曲げ品の展開をAIに計算させていた | AIは「外寸を並べた座標+曲げ線」だけを返し、**控除はアプリが控除表で計算** | `Geometry/Geometry.swift` |
| 429/529/通信断で即失敗 | 指数的に待って最大3回再試行 | `Reading/ClaudeClient.swift` |

## 構成(SwiftUI / iOS 17 以上 / 外部ライブラリなし)
```
SheetMaster/
  App/      SheetMasterApp.swift(@main, タブ)  AppStore.swift(保存・設定・控除表)
  Models/   Models.swift(部品・外形・穴・曲げ)
  Reading/  ImagePreprocessor / ClaudeClient / Prompts / DrawingReader
  Geometry/ Geometry.swift(控除計算・面取り・R・円弧・反転・検証)
  Export/   DXFWriter.swift(R12 DXF、板厚別まとめ書き出し)
  Views/    DrawingViews / PartViews / OtherViews
  Support/  Keychain.swift
project.yml  … XcodeGen 用(新規プロジェクトにする場合)
```

## 進め方は2通り(どちらでもよい)
### A. v2.3 一式をそのまま使う(おすすめ)
1. 既存リポジトリの Bundle ID・署名・チーム・GitHub Actions(TestFlightアップロード)の設定は**そのまま残す**。
2. アプリのSwiftソースを `SheetMaster/` 以下の内容に置き換える。
3. Info.plist に以下を入れる:
   - `NSCameraUsageDescription` = 「図面を撮影して読み取るためにカメラを使います」
   - `NSPhotoLibraryUsageDescription` = 「図面の写真を読み込むために使います」
4. `CFBundleShortVersionString` = **2.3**、ビルド番号は前回より大きく。最低iOS = 17.0。
5. ビルド → TestFlight。

### B. v2.2 の画面を残し、読み取り部分だけ差し替える
- `Reading/` 4ファイル、`Geometry/Geometry.swift`、`Export/DXFWriter.swift`、`Models/Models.swift` を移植。
- v2.2 の読み取り呼び出しを `DrawingReader(apiKey:settings:).read(images:into:progress:)` に置き換える。
- 板厚別ボタン画面は `Exporter.groups(_:)` と `Exporter.export(items:settings:)` を使う。
- v2.2 の「転送案内」画面やAPIキー保存方法があれば、そちらを使ってよい(v2.3 は Keychain に `claude_api_key` で保存)。

## 注意(必ず読むこと)
- このソースは **Macが無い環境で書いたため、まだコンパイルしていない**。ビルドエラーが出たら、仕様を変えずに文法・型の修正だけ行うこと。
- 幾何計算(面取り・R・U溝の円弧・曲げ控除・左右反転)は同じ計算をPythonで再現し、外形が閉じること・寸法(例: 外寸167 − 控除7 = 160)を確認済み。
- 使用モデル: 既定 `claude-opus-5-5`、設定で `claude-sonnet-5-5` に切替可。API: `https://api.anthropic.com/v1/messages`、`anthropic-version: 2023-06-01`。
- 段階Bは部品ごとに同じ画像を送るため、最後の画像に `cache_control: ephemeral` を付けてプロンプトキャッシュを使っている(料金・時間の節約)。
- 曲げ控除表の初期値は**すべて仮値**(画面に「仮」表示)。ユーザーが現場の表に入れ替える前提。勝手に「正しい値」に変えないこと。
- 保存ファイル名は `drawings_v23.json` / `settings_v23.json`(v2.2 のデータとは別)。

## DXF 仕様
- AutoCAD R12(AC1009)ASCII、改行CRLF、単位mm、原点=展開形状の左下
- エンティティは LINE / ARC / CIRCLE のみ。切断線はすべて `CUT` レイヤー
- 曲げ線は設定ONのときだけ `BEND` レイヤー(既定OFF。レーザーで切らないため)
- 勝手違いは `_MIRROR` 付きの別ファイル。ファイル名例: `SUS304_t3_DM231906J-M091_P2_x2.dxf`
- 板厚未確定・控除表に無い板厚の部品は書き出さず、理由を表示する

## 動作確認のしかた
1. 設定でAPIキーを入れる。
2. 「新しい図面を読み取る」でキャスタベースの写真を読む → 部品一覧に SUS304 の曲げ板が出て、勝手違い有・数量各1 になること。
3. シュートの写真を読む → 本体板と「t3板」が**別の板厚の部品**に分かれ、φ25/φ12h7のシャフトが「機械加工品」になって書き出し対象外になること。
4. 「板厚別」タブで材質・板厚のボタンを押し、DXFが共有メニューで出ること。
5. 部品画面で数値を手で直す・「この部品だけ読み直す」(ヒント文付き)ができること。
