# SHEET MASTER v2.1 ― 図面を、確かなデータに

図面の写真から、レーザー加工機（アマダ LASMAC LC-1212αⅢNT 等）用の **展開済み平板DXF** を作る iPhone アプリです。
v2.0 では「曲げ・溶接・複数部品の図面」に対応し、**AIが読み取れなかった値はアプリ上で入力できる** ようにしました。

---

## 引き継ぎ担当のAIへ（ビルド・アップロード手順）

このフォルダは **XcodeGen 形式** です（`.xcodeproj` は含めていません）。

1. GitHub にこのフォルダ一式を push する
2. Mac（または GitHub Actions の macOS ランナー）で
   ```bash
   brew install xcodegen
   xcodegen generate
   open SheetMaster.xcodeproj
   ```
3. `project.yml` の次の2か所を書き換えてから `xcodegen generate` し直す
   - `PRODUCT_BUNDLE_IDENTIFIER` → **既存の SHEET MASTER と同じ Bundle ID**（同じアプリの更新として出すため）
   - `DEVELOPMENT_TEAM` → Apple Developer の Team ID
4. `MARKETING_VERSION` / `CURRENT_PROJECT_VERSION` を、App Store Connect に上がっている既存ビルドより大きい値にする
5. Archive → App Store Connect へアップロード → TestFlight

### 重要な注意
- **このコードは Mac が無い環境で書かれたため、まだ一度もコンパイルしていません。**
  `.github/workflows/build.yml` が push 時にシミュレータ向けビルドを行うので、エラーが出たら修正してください。
  （Swift 5.9 / Xcode 15 以降・iOS 17 以降を前提にしています）
- 既存の SHEET MASTER のコードがある場合、このプロジェクトで **置き換える** 想定です。
  既存版にしか無い機能があれば、このプロジェクトに移植してください。
- 外部ライブラリは使っていません（SwiftUI / VisionKit / PhotosUI / Security のみ）。

---

## 機能

| 画面 | 内容 |
|---|---|
| ホーム | 図面スキャン（斜め補正付き）・カメラ・写真から選択・デモデータ／読み取り履歴 |
| 読み取り | 補足（例「本体はt1.5」）を添えて Claude API に送信 |
| 図面 | AIからの確認事項、部品一覧（レーザー／旋盤／購入品）、要入力・要確認の件数 |
| 部品 | 材質・板厚・数量、外形（面ごとの外寸＋曲げ角）、角R/C、穴、けがき線を編集。図面画像をいつでも拡大表示 |
| 穴 | 丸穴・タップ（下穴表で自動変換）・皿穴・長穴・角穴・多角形（星形ひな形あり） |
| 展開図 | 展開サイズと形状をプレビュー（ピンチで拡大） |
| DXF出力 | 部品ごとに1ファイル。レイヤー選択。共有／アプリ内「DXF」フォルダに保存 |
| 板ごと（タブ） | 全図面のレーザー部品を「SUS304 t3」「SS400 t4.5」のような材質・板厚ボタンに自動で仕分け。押すとその板の部品が一覧で出て、まとめてDXF作成・共有。出力済み／未出力を管理 |
| PCへ送る | OneDrive・メール・USB（Apple Devices アプリ）の手順 |
| 設定 | APIキー（キーチェーン保存）、モデル、曲げ控除表、K係数、タップ下穴表 |

### 値の色分け（正確さのための仕組み）
- **赤** … 図面に書かれていない（AIが推測せず空欄にした）→ 入力しないと DXF を出力できない
- **黄** … AIの推定・参考値・計算値 → 確認ボタンで確定。残ったまま出力すると警告
- **無色** … 図面に明記されている、または作業者が入力した値

### 曲げ展開の計算
- 展開長 = 各面の外寸の合計 − 曲げ1か所ごとの控除値
- 90°曲げ … 設定の「曲げ控除表」（材質・板厚ごと）。**表に無い組み合わせは出力前に入力を要求**
- 90°以外 … `D = 2(r+t)·tan(θ/2) − θ(r + K·t)` で計算し「要確認」表示
- 部品ごと・曲げごとに控除値の手入力も可能
- 参考値（一般値）も登録できるが、黄色表示のまま。自社の実測値に置き換える運用

### DXF 仕様
- 形式 R12（AC1009）、単位 mm、文字コード Shift_JIS、改行 CRLF
- レイヤー：`CUT_OUTER`（外形・白）／`CUT_INNER`（穴・赤）／`BEND`（曲げ線・緑）／`MARK`（けがき・水色）／`TEXT`（文字・黄）
- 原点は展開図の左下
- ファイル名：`図番_部品名_材質_t板厚_数量個.dxf`
- 保存先：アプリ内 `DXF/材質_t板厚/`（例 `DXF/SUS304_t3/`）。材質名は全角・半角・大文字小文字・空白の違いをそろえて仕分け

---

## ファイル構成

```
project.yml                  XcodeGen 設定
SheetMaster/
  App/SheetMasterApp.swift
  Models/DrawingModels.swift   読み取り結果のデータ構造（Val = 値＋確からしさ）
  Models/AppSettings.swift     設定・曲げ控除表・タップ下穴表
  Services/AnalysisPrompt.swift  Claude への指示文と出力スキーマ
  Services/ClaudeClient.swift    Messages API 呼び出し（tool use で構造化出力）
  Services/FlatPattern.swift     控除計算・入力チェック・展開図生成
  Services/DXFWriter.swift       DXF 書き出し
  Services/Storage.swift         キーチェーン・画像・履歴の保存
  Services/DemoData.swift        APIキー無しで試せるデモ
  Views/…                        各画面
.github/workflows/build.yml    ビルド確認
```

## 今後の拡張候補
- 箱曲げ（二方向曲げ）の自動展開と角逃がし
- 1枚の図面を複数枚に分けて撮影・結合
- 会社の加工ソフト向けの専用レイヤー名・色への変更設定
