import Foundation
import Observation

/// 曲げ控除表の1行（90°曲げ・外寸基準の控除値）
struct BendEntry: Codable, Hashable, Identifiable {
    var id = UUID()
    /// 材質キー。"/" 区切りで複数可（例: "SPCC/SPHC/SS400"）。部品の材質名に含まれていれば一致
    var material: String
    var thickness: Double
    var deduction: Double
    /// false = 参考値・要確認（黄色表示）
    var verified: Bool
    /// 使う金型のV幅（メモ）
    var vWidth: Double? = nil
    /// メモ（手書き追記の内容など）
    var note: String? = nil

    func matches(material m: String, thickness t: Double) -> Bool {
        guard abs(thickness - t) < 0.01 else { return false }
        let target = m.uppercased().replacingOccurrences(of: " ", with: "")
        guard !target.isEmpty else { return false }
        return material.uppercased()
            .split(separator: "/")
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .contains { !$0.isEmpty && target.contains($0) }
    }


    /// 会社の控除表（現場掲示の表より。2026-11-24 登録）
    /// 手書きの追記・訂正がある値は verified = false（要確認）にしている
    static let companyDefaults: [BendEntry] = {
        let spcc = "SPCC"
        let sus = "SUS"
        let al = "AL/A1050/A1100/A2017/A5052/A5083/A6061/A6063"
        func e(_ m: String, _ t: Double, _ d: Double, v: Double, ok: Bool = true, _ note: String? = nil) -> BendEntry {
            BendEntry(material: m, thickness: t, deduction: d, verified: ok, vWidth: v, note: note)
        }
        return [
            e(spcc, 0.5, 0.9, v: 4),
            e(spcc, 0.8, 1.4, v: 6),
            e(spcc, 1.0, 1.8, v: 6),
            e(spcc, 1.2, 2.1, v: 8),
            e(spcc, 1.6, 2.6, v: 8),
            e(spcc, 2.0, 3.2, v: 10),
            e(spcc, 2.3, 3.8, v: 12),
            e(spcc, 2.6, 4.2, v: 12),
            e(spcc, 2.9, 4.8, v: 16),
            e(spcc, 3.0, 5.0, v: 16, ok: false, "表に手書きで「5」"),
            e(spcc, 3.2, 5.2, v: 16, "手書きで (5.4) V18 の追記あり"),
            e(spcc, 4.0, 7.0, v: 25),
            e(spcc, 4.5, 7.4, v: 25),
            e(spcc, 5.0, 8.5, v: 25),
            e(spcc, 6.0, 9.4, v: 25),
            e(spcc, 9.0, 15.5, v: 64, ok: false, "印字13.2をカッコ書き、手書き15.5（V64）"),
            e(sus, 1.5, 2.6, v: 8),
            e(sus, 2.0, 3.4, v: 10),
            e(sus, 2.5, 4.0, v: 12),
            e(sus, 3.0, 5.4, v: 16),
            e(sus, 4.0, 7.2, v: 25),
            e(sus, 5.0, 8.5, v: 25, ok: false, "印字7.2を消して手書き8.5（横に小さく9.2）"),
            e(sus, 6.0, 9.4, v: 25),
            e(al, 1.5, 2.6, v: 8),
            e(al, 2.5, 3.8, v: 12),
            e(al, 3.0, 4.7, v: 16),
            e(al, 4.0, 7.2, v: 25, ok: false, "カッコ書きで (6.8) の追記あり"),
            e(al, 5.0, 7.8, v: 25),
            e(al, 6.0, 9.8, v: 25, ok: false, "手書きで9.8"),
        ]
    }()

    /// 一般的な参考値（V幅 約6〜8t のエアベンド想定）。必ず自社の実測値に置き換えること
    static let references: [BendEntry] = [
        .init(material: "SPCC/SPHC/SS400/SECC", thickness: 1.0, deduction: 1.7, verified: false),
        .init(material: "SPCC/SPHC/SS400/SECC", thickness: 1.2, deduction: 2.0, verified: false),
        .init(material: "SPCC/SPHC/SS400/SECC", thickness: 1.6, deduction: 2.7, verified: false),
        .init(material: "SPCC/SPHC/SS400/SECC", thickness: 2.3, deduction: 3.9, verified: false),
        .init(material: "SPCC/SPHC/SS400/SECC", thickness: 3.2, deduction: 5.4, verified: false),
        .init(material: "SUS", thickness: 1.0, deduction: 1.9, verified: false),
        .init(material: "SUS", thickness: 1.5, deduction: 2.7, verified: false),
        .init(material: "SUS", thickness: 2.0, deduction: 3.6, verified: false),
        .init(material: "SUS", thickness: 3.0, deduction: 5.3, verified: false),
    ]
}

/// タップ下穴表
struct TapEntry: Codable, Hashable, Identifiable {
    var id = UUID()
    var size: String
    var drill: Double

    static let defaults: [TapEntry] = [
        .init(size: "M2", drill: 1.6),
        .init(size: "M2.5", drill: 2.05),
        .init(size: "M3", drill: 2.5),
        .init(size: "M4", drill: 3.3),
        .init(size: "M5", drill: 4.2),
        .init(size: "M6", drill: 5.0),
        .init(size: "M8", drill: 6.8),
        .init(size: "M10", drill: 8.5),
        .init(size: "M12", drill: 10.2),
    ]
}

struct SettingsData: Codable {
    var model: String = "claude-opus-5-5"
    var kFactor: Double = 0.4
    var innerRadiusRatio: Double = 1.0
    var bendTable: [BendEntry] = BendEntry.companyDefaults
    var tapTable: [TapEntry] = TapEntry.defaults
    var exportBendLines: Bool = false
    var exportMarks: Bool = true
    var exportText: Bool = false
}

/// 計算に使う設定値（View から切り離して渡す）
struct CalcConfig {
    var bendTable: [BendEntry]
    var tapTable: [TapEntry]
    var kFactor: Double
    var innerRadiusRatio: Double

    func tapDrill(_ size: String) -> Double? {
        let key = CalcConfig.normalizeTap(size)
        guard !key.isEmpty else { return nil }
        return tapTable.first { CalcConfig.normalizeTap($0.size) == key }?.drill
    }

    /// "M5×0.8" "m5" "M5タップ" → "M5"
    static func normalizeTap(_ s: String) -> String {
        var t = s.uppercased()
            .replacingOccurrences(of: " ", with: "")
            .replacingOccurrences(of: "Ｍ", with: "M")
        if let r = t.range(of: "×") { t = String(t[..<r.lowerBound]) }
        if let r = t.range(of: "X") { t = String(t[..<r.lowerBound]) }
        let allowed = Set("M0123456789.")
        return String(t.filter { allowed.contains($0) })
    }
}

@Observable
final class AppSettings {
    var data: SettingsData

    private static let defaultsKey = "settings.v1"

    init() {
        if let raw = UserDefaults.standard.data(forKey: AppSettings.defaultsKey),
           let d = try? JSONDecoder().decode(SettingsData.self, from: raw) {
            data = d
        } else {
            data = SettingsData()
        }
    }

    func save() {
        if let raw = try? JSONEncoder().encode(data) {
            UserDefaults.standard.set(raw, forKey: AppSettings.defaultsKey)
        }
    }

    var config: CalcConfig {
        CalcConfig(bendTable: data.bendTable, tapTable: data.tapTable,
                   kFactor: data.kFactor, innerRadiusRatio: data.innerRadiusRatio)
    }

    var apiKey: String {
        get { KeychainHelper.read("claude-api-key") ?? "" }
        set { KeychainHelper.save("claude-api-key", newValue) }
    }
}
