import Foundation
import Observation
import Security
import SwiftUI
import UIKit

// MARK: - Keychain（APIキー保存）

enum KeychainHelper {
    private static let service = "SheetMaster"

    static func save(_ key: String, _ value: String) {
        let base: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key,
        ]
        SecItemDelete(base as CFDictionary)
        guard !value.isEmpty else { return }
        var add = base
        add[kSecValueData as String] = Data(value.utf8)
        add[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlock
        SecItemAdd(add as CFDictionary, nil)
    }

    static func read(_ key: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne,
        ]
        var out: AnyObject?
        guard SecItemCopyMatching(query as CFDictionary, &out) == errSecSuccess,
              let data = out as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
}

// MARK: - フォルダ

enum AppFolders {
    static var documents: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
    static func folder(_ name: String) -> URL {
        let url = documents.appendingPathComponent(name, isDirectory: true)
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }
    static var images: URL { folder("図面画像") }
    static var dxf: URL { folder("DXF") }
    static var data: URL { folder(".data") }
}

// MARK: - 画像

enum ImageStore {
    static func save(_ image: UIImage) -> String {
        let name = UUID().uuidString + ".jpg"
        if let d = image.jpegData(compressionQuality: 0.9) {
            try? d.write(to: AppFolders.images.appendingPathComponent(name))
        }
        return name
    }

    static func load(_ name: String) -> UIImage? {
        guard !name.isEmpty else { return nil }
        return UIImage(contentsOfFile: AppFolders.images.appendingPathComponent(name).path)
    }

    static func delete(_ name: String) {
        guard !name.isEmpty else { return }
        try? FileManager.default.removeItem(at: AppFolders.images.appendingPathComponent(name))
    }

    /// API送信用に縮小・圧縮（base64後 5MB 未満に収める）
    static func jpegForAPI(_ image: UIImage, maxSide: CGFloat = 2400) -> Data? {
        let size = image.size
        let scale = min(1, maxSide / max(size.width, size.height))
        let target = CGSize(width: floor(size.width * scale), height: floor(size.height * scale))
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        let resized = UIGraphicsImageRenderer(size: target, format: format).image { _ in
            image.draw(in: CGRect(origin: .zero, size: target))
        }
        var q: CGFloat = 0.85
        while q > 0.3 {
            if let d = resized.jpegData(compressionQuality: q), d.count < 3_600_000 { return d }
            q -= 0.1
        }
        return resized.jpegData(compressionQuality: 0.3)
    }
}

// MARK: - 読み取り履歴

@Observable
final class JobStore {
    var jobs: [Job] = []

    private var fileURL: URL { AppFolders.data.appendingPathComponent("jobs.json") }

    init() { load() }

    func load() {
        guard let d = try? Data(contentsOf: fileURL),
              let list = try? JSONDecoder().decode([Job].self, from: d) else { return }
        jobs = list
    }

    func save() {
        if let d = try? JSONEncoder().encode(jobs) {
            try? d.write(to: fileURL, options: .atomic)
        }
    }

    func add(_ job: Job) {
        jobs.insert(job, at: 0)
        save()
    }

    func delete(at offsets: IndexSet) {
        for i in offsets { ImageStore.delete(jobs[i].imageFile) }
        jobs.remove(atOffsets: offsets)
        save()
    }

    // MARK: 板ごと（材質・板厚別）

    struct LibraryItem: Identifiable {
        var id: UUID { part.id }
        let jobID: UUID
        let jobTitle: String
        let drawingNumber: String
        let imageFile: String
        let part: Part
    }

    struct MaterialGroup: Identifiable {
        var id: String { key }
        let key: String
        let items: [LibraryItem]
        var notExportedCount: Int { items.filter { $0.part.exportedAt == nil }.count }
    }

    static let unsetKey = "材質・板厚 未設定"

    /// 全図面のレーザー部品を、材質・板厚ごとにまとめる
    var materialGroups: [MaterialGroup] {
        var dict: [String: [LibraryItem]] = [:]
        for job in jobs {
            for p in job.analysis.parts where p.process == .laser {
                let key = p.materialKey ?? JobStore.unsetKey
                dict[key, default: []].append(LibraryItem(jobID: job.id, jobTitle: job.title,
                                                          drawingNumber: job.analysis.drawing.drawingNumber,
                                                          imageFile: job.imageFile, part: p))
            }
        }
        return dict.map { MaterialGroup(key: $0.key, items: $0.value) }
            .sorted { a, b in
                if a.key == JobStore.unsetKey { return false }
                if b.key == JobStore.unsetKey { return true }
                return a.key.localizedStandardCompare(b.key) == .orderedAscending
            }
    }

    func partBinding(jobID: UUID, partID: UUID) -> Binding<Part>? {
        guard let j = jobs.firstIndex(where: { $0.id == jobID }),
              jobs[j].analysis.parts.contains(where: { $0.id == partID }) else { return nil }
        return Binding(
            get: {
                self.jobs.first(where: { $0.id == jobID })?
                    .analysis.parts.first(where: { $0.id == partID }) ?? Part()
            },
            set: { newValue in
                if let j = self.jobs.firstIndex(where: { $0.id == jobID }),
                   let p = self.jobs[j].analysis.parts.firstIndex(where: { $0.id == partID }) {
                    self.jobs[j].analysis.parts[p] = newValue
                    self.save()
                }
            }
        )
    }

    func setExported(_ partIDs: Set<UUID>, date: Date?) {
        for j in jobs.indices {
            for p in jobs[j].analysis.parts.indices where partIDs.contains(jobs[j].analysis.parts[p].id) {
                jobs[j].analysis.parts[p].exportedAt = date
            }
        }
        save()
    }

    func binding(for id: UUID) -> Binding<Job>? {
        guard jobs.contains(where: { $0.id == id }) else { return nil }
        return Binding(
            get: { self.jobs.first(where: { $0.id == id }) ?? Job.placeholder },
            set: { newValue in
                if let i = self.jobs.firstIndex(where: { $0.id == id }) {
                    self.jobs[i] = newValue
                    self.save()
                }
            }
        )
    }
}
