import SwiftUI

struct SettingsView: View {
    @Environment(AppSettings.self) private var settings
    @Environment(\.dismiss) private var dismiss

    @State private var apiKey = ""
    @State private var savedMessage = false

    var body: some View {
        @Bindable var settings = settings
        NavigationStack {
            Form {
                Section {
                    SecureField("sk-ant-...", text: $apiKey)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    Button("APIキーを保存") {
                        settings.apiKey = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
                        savedMessage = true
                    }
                    if savedMessage { Text("保存しました").font(.caption).foregroundStyle(.green) }
                    HStack {
                        Text("モデル")
                        Spacer()
                        TextField("claude-opus-5-5", text: $settings.data.model)
                            .multilineTextAlignment(.trailing)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                    }
                } header: {
                    Text("Claude API")
                } footer: {
                    Text("精度重視: claude-opus-5-5 ／ 速さ・費用重視: claude-sonnet-5-5。APIキーはiPhoneのキーチェーンに保存されます。")
                }

                Section {
                    NavigationLink {
                        BendTableView()
                    } label: {
                        LabeledContent("曲げ控除表", value: "\(settings.data.bendTable.count)件")
                    }
                    NumberField(label: "K係数（90°以外の計算用）", value: $settings.data.kFactor)
                    NumberField(label: "内R ÷ 板厚", value: $settings.data.innerRadiusRatio)
                } header: {
                    Text("曲げ展開")
                } footer: {
                    Text("90°曲げは控除表の値を使います。表に無い組み合わせは出力前に入力を求めます。90°以外の角度は K係数と内Rから計算し、要確認として表示します。")
                }

                Section {
                    NavigationLink {
                        TapTableView()
                    } label: {
                        LabeledContent("タップ下穴表", value: "\(settings.data.tapTable.count)件")
                    }
                } header: {
                    Text("穴")
                }

                Section("アプリ情報") {
                    LabeledContent("バージョン",
                                   value: Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "-")
                }
            }
            .navigationTitle("設定")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完了") { settings.save(); dismiss() }
                }
            }
            .onAppear { apiKey = settings.apiKey }
            .onDisappear { settings.save() }
        }
    }
}

// MARK: - 曲げ控除表

struct BendTableView: View {
    @Environment(AppSettings.self) private var settings
    @State private var showReferenceAlert = false
    @State private var showCompanyAlert = false

    var body: some View {
        @Bindable var settings = settings
        List {
            Section {
                ForEach($settings.data.bendTable) { $e in
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Text("材質")
                            Spacer()
                            TextField("例 SUS", text: $e.material)
                                .multilineTextAlignment(.trailing)
                                .textInputAutocapitalization(.characters)
                        }
                        NumberField(label: "板厚", value: $e.thickness, unit: "mm")
                        NumberField(label: "控除値（90°）", value: $e.deduction, unit: "mm")
                        NumberField(label: "金型 V幅", value: Binding(
                            get: { e.vWidth ?? 0 },
                            set: { e.vWidth = $0 == 0 ? nil : $0 }), unit: "")
                        TextField("メモ", text: Binding(
                            get: { e.note ?? "" },
                            set: { e.note = $0.isEmpty ? nil : $0 }))
                            .font(.caption)
                        Toggle("確認済み", isOn: $e.verified)
                    }
                    .padding(.vertical, 4)
                    .listRowBackground(e.verified ? Color(.secondarySystemGroupedBackground) : Color.yellow.opacity(0.2))
                }
                .onDelete { settings.data.bendTable.remove(atOffsets: $0) }
                Button {
                    settings.data.bendTable.append(BendEntry(material: "SUS", thickness: 3, deduction: 0, verified: true))
                } label: {
                    Label("行を追加", systemImage: "plus")
                }
            } header: {
                Text("90°曲げ・外寸基準")
            } footer: {
                Text("黄色は手書きの追記・訂正があった値です。確認したら「確認済み」をオンにしてください。控除値 = 外寸の合計 − 展開長（曲げ1か所あたり）。例：外寸50＋50のL曲げを展開して94.6なら 5.4。材質は「SPCC/SPHC」のように / 区切りで複数書けます。部品の材質名に含まれていれば一致します。")
            }

            Section {
                Button("会社の控除表を入れ直す") { showCompanyAlert = true }
                Button("一般的な参考値を追加") { showReferenceAlert = true }
            } footer: {
                Text("参考値は黄色で表示され、使うと「要確認」になります。自社のプレスブレーキ・金型で実測した値に置き換えてください。")
            }
        }
        .navigationTitle("曲げ控除表")
        .navigationBarTitleDisplayMode(.inline)
        .onDisappear { settings.save() }
        .alert("会社の控除表を入れ直しますか？", isPresented: $showCompanyAlert) {
            Button("入れ直す", role: .destructive) {
                settings.data.bendTable = BendEntry.companyDefaults.map { var e = $0; e.id = UUID(); return e }
            }
            Button("キャンセル", role: .cancel) {}
        } message: {
            Text("今の控除表を、登録済みの会社の表（SPCC・SUS・AL）に置き換えます。")
        }
        .alert("参考値を追加しますか？", isPresented: $showReferenceAlert) {
            Button("追加") {
                settings.data.bendTable.append(contentsOf: BendEntry.references.map {
                    var e = $0; e.id = UUID(); return e
                })
            }
            Button("キャンセル", role: .cancel) {}
        } message: {
            Text("一般的な値（V幅 約6〜8t）です。金型や材料ロットで変わるため、必ず実測して修正してください。")
        }
    }
}

// MARK: - タップ下穴表

struct TapTableView: View {
    @Environment(AppSettings.self) private var settings

    var body: some View {
        @Bindable var settings = settings
        List {
            Section {
                ForEach($settings.data.tapTable) { $e in
                    HStack {
                        TextField("M5", text: $e.size)
                            .textInputAutocapitalization(.characters)
                            .frame(width: 80)
                        NumberField(label: "下穴 φ", value: $e.drill, unit: "mm")
                    }
                }
                .onDelete { settings.data.tapTable.remove(atOffsets: $0) }
                Button {
                    settings.data.tapTable.append(TapEntry(size: "M", drill: 0))
                } label: {
                    Label("行を追加", systemImage: "plus")
                }
            } footer: {
                Text("図面のタップ穴（M3など）は、この表の下穴径でレーザーカットします。")
            }
            Section {
                Button("初期値に戻す", role: .destructive) { settings.data.tapTable = TapEntry.defaults }
            }
        }
        .navigationTitle("タップ下穴表")
        .navigationBarTitleDisplayMode(.inline)
        .onDisappear { settings.save() }
    }
}
