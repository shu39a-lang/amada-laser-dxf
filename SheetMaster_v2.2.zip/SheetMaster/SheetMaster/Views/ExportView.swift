import SwiftUI

struct ExportView: View {
    @Binding var job: Job
    @Environment(AppSettings.self) private var settings

    @State private var selected: Set<UUID> = []
    @State private var files: [URL] = []
    @State private var showWarning = false
    @State private var errorMessage: String?

    private var laserParts: [Part] { job.analysis.parts.filter { $0.process == .laser } }

    var body: some View {
        @Bindable var settings = settings
        let config = settings.config
        List {
            Section {
                if laserParts.isEmpty {
                    Text("レーザー加工の部品がありません。部品画面で「加工」をレーザーにしてください。")
                        .foregroundStyle(.secondary)
                }
                ForEach(laserParts) { p in
                    let issues = Validator.issues(p, config)
                    let errors = issues.filter { $0.severity == .error }.count
                    let warnings = issues.count - errors
                    let fp = FlatBuilder.build(p, config: config)
                    Button {
                        toggle(p.id)
                    } label: {
                        HStack(alignment: .top, spacing: 12) {
                            Image(systemName: selected.contains(p.id) ? "checkmark.square.fill" : "square")
                                .font(.title3)
                                .foregroundStyle(errors > 0 ? Color.gray : Color.accentColor)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(p.name).font(.headline).foregroundStyle(.primary)
                                Text("\(p.material) t\(ValField.format(p.thickness.value)) ・ \(ValField.format(p.quantity.value))個 ・ \(ValField.format((fp.width * 10).rounded() / 10))×\(ValField.format((fp.height * 10).rounded() / 10))")
                                    .font(.caption).foregroundStyle(.secondary)
                                if errors > 0 {
                                    Text("未入力 \(errors)件 — 部品画面で入力してください").font(.caption.bold()).foregroundStyle(.red)
                                } else if warnings > 0 {
                                    Text("要確認 \(warnings)件").font(.caption.bold()).foregroundStyle(.orange)
                                }
                            }
                        }
                    }
                    .disabled(errors > 0)
                }
            } header: {
                Text("出力する部品")
            } footer: {
                Text("部品ごとに1つのDXFファイルを作ります。未入力がある部品は出力できません。")
            }

            Section("出力するレイヤー") {
                LabeledContent("外形（CUT_OUTER）・穴（CUT_INNER）", value: "常に出力")
                Toggle("曲げ線（BEND）", isOn: $settings.data.exportBendLines)
                Toggle("けがき線（MARK）", isOn: $settings.data.exportMarks)
                Toggle("部品名などの文字（TEXT）", isOn: $settings.data.exportText)
            }

            Section {
                Button {
                    if hasWarnings(config) { showWarning = true } else { generate(config) }
                } label: {
                    Label("DXFファイルを作成", systemImage: "doc.badge.gearshape").font(.headline)
                }
                .disabled(selected.isEmpty)

                if !files.isEmpty {
                    ShareLink(items: files) {
                        Label("共有・保存（\(files.count)ファイル）", systemImage: "square.and.arrow.up")
                    }
                    ForEach(files, id: \.self) { Text($0.lastPathComponent).font(.caption) }
                    Text("「DXF」フォルダの中に、材質・板厚ごとのフォルダに分けて保存しました。下の「板ごと」タブからまとめて出すこともできます。")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }

            Section {
                NavigationLink {
                    TransferGuideView()
                } label: {
                    Label("会社のパソコンへ送る方法", systemImage: "desktopcomputer")
                }
            }
        }
        .navigationTitle("DXF出力")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            if selected.isEmpty {
                selected = Set(laserParts.filter { Validator.errorCount($0, config) == 0 }.map(\.id))
            }
        }
        .onDisappear { settings.save() }
        .alert("要確認の値が残っています", isPresented: $showWarning) {
            Button("このまま作成") { generate(config) }
            Button("戻って確認", role: .cancel) {}
        } message: {
            Text("黄色（AI推定・参考値・計算値）の項目があります。図面と照らし合わせてから出力することをおすすめします。")
        }
        .alert("作成できませんでした",
               isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(errorMessage ?? "")
        }
    }

    private func toggle(_ id: UUID) {
        if selected.contains(id) { selected.remove(id) } else { selected.insert(id) }
    }

    private func hasWarnings(_ config: CalcConfig) -> Bool {
        laserParts.filter { selected.contains($0.id) }
            .contains { Validator.issues($0, config).contains { $0.severity == .warning } }
    }

    private func generate(_ config: CalcConfig) {
        settings.save()
        let targets = laserParts.filter { selected.contains($0.id) && Validator.errorCount($0, config) == 0 }
        do {
            files = try DXFWriter.export(targets.map { (part: $0, drawingNumber: job.analysis.drawing.drawingNumber) },
                                         config: config, layers: DXFWriter.layers(from: settings.data))
            let ids = Set(targets.map(\.id))
            let now = Date()
            for i in job.analysis.parts.indices where ids.contains(job.analysis.parts[i].id) {
                job.analysis.parts[i].exportedAt = now
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

// MARK: - 会社PCへの転送ガイド

struct TransferGuideView: View {
    var body: some View {
        List {
            Section {
                Text("DXFは「外形＝CUT_OUTER」「穴＝CUT_INNER」のレイヤーに分かれています。単位はmmです。")
            }
            Section("方法1　OneDrive / Googleドライブ（おすすめ）") {
                step(1, "DXF出力画面で「共有・保存」をタップ")
                step(2, "OneDrive または Googleドライブ を選んで保存")
                step(3, "会社のパソコンで同じドライブのフォルダを開く")
                step(4, "DXFファイルをパソコンのデスクトップなどにコピー")
            }
            Section("方法2　メールで自分宛てに送る") {
                step(1, "「共有・保存」→「メール」を選ぶ")
                step(2, "会社のパソコンで受け取れる自分のアドレス宛てに送信")
                step(3, "パソコンで添付ファイルを保存")
            }
            Section("方法3　USBケーブル（ネットに出したくない場合）") {
                step(1, "iPhoneを会社のパソコンにケーブルで接続し、「このコンピュータを信頼」を許可")
                step(2, "パソコンで「Apple Devices」アプリ（または iTunes）を開く")
                step(3, "iPhone →「ファイル」→「SHEET MASTER」を選ぶ")
                step(4, "「DXF」フォルダをパソコンにドラッグしてコピー")
            }
            Section("加工機ソフトでの読み込み") {
                step(1, "加工プログラム作成ソフト（CAD/CAM）で「DXF読込」を選ぶ")
                step(2, "単位が mm になっているか確認")
                step(3, "CUT_OUTER を外形、CUT_INNER を穴として加工対象に指定（BEND・MARK・TEXT は加工しない設定に）")
                step(4, "材質・板厚を設定し、割付・加工条件を決めてプログラムを作成")
                step(5, "最初の1枚は寸法を実測し、曲げ後の寸法がずれたら設定の「曲げ控除表」を修正")
            }
        }
        .navigationTitle("パソコンへ送る")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func step(_ n: Int, _ text: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Text("\(n)").font(.caption.bold()).foregroundStyle(.white)
                .frame(width: 22, height: 22).background(Circle().fill(Color.accentColor))
            Text(text).font(.subheadline)
        }
    }
}
