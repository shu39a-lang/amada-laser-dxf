import SwiftUI

/// 「板ごと」タブ：全図面のレーザー部品を、材質・板厚のボタンでまとめて出す
struct MaterialLibraryView: View {
    @Environment(JobStore.self) private var store

    private let columns = [GridItem(.adaptive(minimum: 150), spacing: 12)]

    var body: some View {
        NavigationStack {
            let groups = store.materialGroups
            ScrollView {
                if groups.isEmpty {
                    ContentUnavailableView("レーザー部品がありません",
                                           systemImage: "square.stack.3d.up",
                                           description: Text("「図面」タブで図面を読み取ると、ここに材質・板厚ごとに並びます"))
                        .padding(.top, 60)
                }
                LazyVGrid(columns: columns, spacing: 12) {
                    ForEach(groups) { g in
                        NavigationLink {
                            MaterialGroupView(groupKey: g.key)
                        } label: {
                            MaterialButton(group: g)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding()
            }
            .navigationTitle("板ごとに出す")
        }
    }
}

private struct MaterialButton: View {
    let group: JobStore.MaterialGroup

    var body: some View {
        let unset = group.key == JobStore.unsetKey
        VStack(alignment: .leading, spacing: 6) {
            Text(group.key)
                .font(.title3.bold())
                .lineLimit(2)
                .minimumScaleFactor(0.7)
            Text("\(group.items.count)部品")
                .font(.subheadline)
            if group.notExportedCount > 0 {
                Text("未出力 \(group.notExportedCount)")
                    .font(.caption.bold())
                    .padding(.horizontal, 8).padding(.vertical, 2)
                    .background(Capsule().fill(Color.orange.opacity(0.25)))
            } else {
                Text("すべて出力済み").font(.caption).foregroundStyle(.secondary)
            }
        }
        .frame(maxWidth: .infinity, minHeight: 110, alignment: .topLeading)
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 14)
            .fill(unset ? Color.red.opacity(0.12) : Color.accentColor.opacity(0.12)))
        .overlay(RoundedRectangle(cornerRadius: 14)
            .stroke(unset ? Color.red.opacity(0.5) : Color.accentColor.opacity(0.5), lineWidth: 1))
    }
}

/// 1つの材質・板厚の部品一覧と、まとめて出力
struct MaterialGroupView: View {
    let groupKey: String

    @Environment(JobStore.self) private var store
    @Environment(AppSettings.self) private var settings

    @State private var selected: Set<UUID> = []
    @State private var onlyNotExported = true
    @State private var files: [URL] = []
    @State private var showWarning = false
    @State private var errorMessage: String?
    @State private var didInitSelection = false

    private var group: JobStore.MaterialGroup? {
        store.materialGroups.first { $0.key == groupKey }
    }

    var body: some View {
        let config = settings.config
        let allItems = group?.items ?? []
        let items = onlyNotExported ? allItems.filter { $0.part.exportedAt == nil } : allItems
        List {
            if groupKey == JobStore.unsetKey {
                Section {
                    Text("材質または板厚が入っていない部品です。部品をタップして入力すると、該当する板のボタンに移ります。")
                        .font(.subheadline).foregroundStyle(.red)
                }
            }

            Section {
                Toggle("未出力の部品だけ表示", isOn: $onlyNotExported)
                if !items.isEmpty {
                    HStack {
                        Button("すべて選択") {
                            selected = Set(items.filter { Validator.errorCount($0.part, config) == 0 }.map(\.id))
                        }
                        Spacer()
                        Button("選択を解除") { selected.removeAll() }
                    }
                    .buttonStyle(.borderless)
                    .font(.subheadline)
                }
            }

            Section {
                if items.isEmpty {
                    Text(onlyNotExported ? "未出力の部品はありません" : "部品がありません")
                        .foregroundStyle(.secondary)
                }
                ForEach(items) { item in
                    LibraryRow(item: item, config: config,
                               isSelected: selected.contains(item.id),
                               onToggle: { toggle(item.id) })
                }
            } header: {
                Text("\(groupKey)（\(items.count)部品）")
            } footer: {
                Text("部品名をタップすると編集画面を開きます。未入力のある部品は出力できません。")
            }

            if groupKey != JobStore.unsetKey {
                Section {
                    Button {
                        if hasWarnings(config) { showWarning = true } else { generate(config) }
                    } label: {
                        Label("選んだ \(selected.count) 部品のDXFをまとめて作成", systemImage: "doc.on.doc")
                            .font(.headline)
                    }
                    .disabled(selected.isEmpty)

                    if !files.isEmpty {
                        ShareLink(items: files) {
                            Label("まとめて共有・保存（\(files.count)ファイル）", systemImage: "square.and.arrow.up")
                        }
                        Text("「DXF/\(MaterialKey.folderName(groupKey))」フォルダにも保存しました。")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }

                if !selected.isEmpty {
                    Section {
                        Button("選んだ部品を「未出力」に戻す") {
                            store.setExported(selected, date: nil)
                        }
                        .font(.subheadline)
                    }
                }
            }
        }
        .navigationTitle(groupKey)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            guard !didInitSelection else { return }
            didInitSelection = true
            selected = Set(items.filter { Validator.errorCount($0.part, config) == 0 }.map(\.id))
        }
        .alert("要確認の値が残っています", isPresented: $showWarning) {
            Button("このまま作成") { generate(config) }
            Button("戻って確認", role: .cancel) {}
        } message: {
            Text("黄色（AI推定・参考値・計算値）の項目がある部品があります。図面と照らし合わせてから出力することをおすすめします。")
        }
        .alert("作成できませんでした",
               isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(errorMessage ?? "")
        }
    }

    private func toggle(_ id: UUID) {
        if selected.contains(id) { selected.remove(id) } else { selected.insert(id) }
    }

    private func targets(_ config: CalcConfig) -> [JobStore.LibraryItem] {
        (group?.items ?? []).filter { selected.contains($0.id) && Validator.errorCount($0.part, config) == 0 }
    }

    private func hasWarnings(_ config: CalcConfig) -> Bool {
        targets(config).contains { Validator.issues($0.part, config).contains { $0.severity == .warning } }
    }

    private func generate(_ config: CalcConfig) {
        let list = targets(config)
        do {
            files = try DXFWriter.export(list.map { (part: $0.part, drawingNumber: $0.drawingNumber) },
                                         config: config, layers: DXFWriter.layers(from: settings.data))
            store.setExported(Set(list.map(\.id)), date: Date())
            selected.removeAll()
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

private struct LibraryRow: View {
    let item: JobStore.LibraryItem
    let config: CalcConfig
    let isSelected: Bool
    let onToggle: () -> Void

    @Environment(JobStore.self) private var store

    var body: some View {
        let issues = Validator.issues(item.part, config)
        let errors = issues.filter { $0.severity == .error }.count
        let warnings = issues.count - errors
        let fp = FlatBuilder.build(item.part, config: config)
        HStack(spacing: 12) {
            Button(action: onToggle) {
                Image(systemName: isSelected ? "checkmark.square.fill" : "square")
                    .font(.title3)
                    .foregroundStyle(errors > 0 ? Color.gray : Color.accentColor)
            }
            .buttonStyle(.borderless)
            .disabled(errors > 0)

            NavigationLink {
                if let b = store.partBinding(jobID: item.jobID, partID: item.part.id) {
                    PartEditView(part: b, drawingImage: item.imageFile)
                } else {
                    Text("部品が見つかりません")
                }
            } label: {
                VStack(alignment: .leading, spacing: 3) {
                    Text(item.part.name).font(.headline)
                    Text(item.jobTitle).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                    Text("\(ValField.format(item.part.quantity.value))個 ・ \(ValField.format((fp.width * 10).rounded() / 10))×\(ValField.format((fp.height * 10).rounded() / 10)) mm")
                        .font(.caption).foregroundStyle(.secondary)
                    HStack(spacing: 8) {
                        if errors > 0 { Text("未入力 \(errors)").foregroundStyle(.red) }
                        if warnings > 0 { Text("要確認 \(warnings)").foregroundStyle(.orange) }
                        if let d = item.part.exportedAt {
                            Text("出力済み \(d.formatted(date: .numeric, time: .shortened))").foregroundStyle(.green)
                        }
                    }
                    .font(.caption.bold())
                }
            }
        }
    }
}
