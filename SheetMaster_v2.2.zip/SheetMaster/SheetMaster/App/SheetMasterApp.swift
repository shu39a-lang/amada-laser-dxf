import SwiftUI

@main
struct SheetMasterApp: App {
    @State private var store = JobStore()
    @State private var settings = AppSettings()

    var body: some Scene {
        WindowGroup {
            TabView {
                HomeView()
                    .tabItem { Label("図面", systemImage: "doc.viewfinder") }
                MaterialLibraryView()
                    .tabItem { Label("板ごと", systemImage: "square.stack.3d.up") }
            }
            .environment(store)
            .environment(settings)
        }
    }
}
