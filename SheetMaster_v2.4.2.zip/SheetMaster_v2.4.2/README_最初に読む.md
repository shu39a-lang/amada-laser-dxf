# SHEET MASTER v2.4.2(完成版一式)

このフォルダは、そのままビルドしてアップロードできる Xcode プロジェクト一式です。
**ソースコードの変更・既存コードとの合体はしないでください。**(前回、旧画面と混ざって読み取り結果が表示されませんでした)

## 作業は3つだけ
1. 今のリポジトリの中身(アプリのプロジェクトとソース)を、このフォルダの中身に**丸ごと置き換える**。
   GitHub Actions などのアップロード用の設定ファイルは今のものを残してよい。
   その場合、ワークフロー内のプロジェクト名・スキーム名を `SheetMaster.xcodeproj` / `SheetMaster` に合わせる。
2. `Config.xcconfig` の3行(Bundle ID・Team ID・ビルド番号)だけを書き換える。
   Bundle ID は今の TestFlight のアプリと同じにする(同じアプリの更新になる)。
3. Release でアーカイブして TestFlight にアップロードする。

## 中身
- iOS 17 以上 / SwiftUI / 外部ライブラリなし
- バージョン 2.4.2、アイコン・カメラ/写真の許可文・暗号化申告(なし)は設定済み
- 共有スキーム `SheetMaster` 入り(コマンドラインからもビルド可)
  例: `xcodebuild -project SheetMaster.xcodeproj -scheme SheetMaster -configuration Release -destination 'generic/platform=iOS' archive -archivePath build/SheetMaster.xcarchive`

## もしビルドエラーが出たら
エラーの出た行の文法・型だけを直し、画面構成・読み取り処理・データの形は変えないこと。

## v2.4.2 の変更点(前回からの差分は3ファイル)
- `SheetMaster/Reading/ClaudeClient.swift`:AIが回答を控えた場合(stop_reason "refusal")に自動で再送
- `SheetMaster/Reading/DrawingReader.swift`:それでも失敗したら、もう一方のAIモデルで再試行
- `SheetMaster/Reading/Prompts.swift`:展開形状の指示文を見直し
- バージョン表記を 2.4.2 に変更
- `Config.xcconfig` は前回の Bundle ID・Team ID のまま、**ビルド番号だけ前回より大きく**する
