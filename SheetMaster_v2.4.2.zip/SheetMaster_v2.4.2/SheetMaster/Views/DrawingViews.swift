import SwiftUI
import PhotosUI

// MARK: - 図面一覧

struct DrawingListView: View {
    @Environment(AppStore.self) private var store

    var body: some View {
        List {
            Section {
                NavigationLink {
                    NewReadingView()
                } label: {
                    Label("新しい図面を読み取る", systemImage: "camera.viewfinder")
                        .font(.headline)
                }
            }
            Section("読み取った図面") {
                if store.drawings.isEmpty {
                    Text("まだありません").foregroundStyle(.secondary)
                }
                ForEach(store.drawings) { d in
                    NavigationLink {
                        DrawingDetailView(drawingID: d.id)
                    } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(d.title.isEmpty ? "(品名なし)" : d.title).font(.headline)
                            Text("\(d.drawingNumber)  製番 \(d.productNumber)").font(.caption).foregroundStyle(.secondary)
                            Text(d.parts.filter { $0.process == .laser }.map(\.groupKey).uniqued().joined(separator: " / "))
                                .font(.caption2).foregroundStyle(.blue)
                        }
                    }
                }
                .onDelete { idx in
                    for i in idx { store.delete(store.drawings[i]) }
                }
            }
        }
        .navigationTitle("SHEET MASTER")
    }
}

extension Array where Element: Hashable {
    func uniqued() -> [Element] {
        var seen = Set<Element>()
        return filter { seen.insert($0).inserted }
    }
}

// MARK: - 新規読み取り

struct NewReadingView: View {
    @Environment(AppStore.self) private var store
    @State private var picks: [PhotosPickerItem] = []
    @State private var images: [UIImage] = []
    @State private var showCamera = false
    @State private var running = false
    @State private var progressText = ""
    @State private var errorText: String?
    @State private var openID: UUID?

    var body: some View {
        Form {
            Section {
                Text("図面全体が入るように、真上からまっすぐ撮ってください。小さい数字が読みにくい図面は、部分のアップ写真も追加すると精度が上がります(最大4枚)。")
                    .font(.footnote).foregroundStyle(.secondary)
                PhotosPicker(selection: $picks, maxSelectionCount: 4, matching: .images) {
                    Label("写真を選ぶ", systemImage: "photo.on.rectangle")
                }
                if UIImagePickerController.isSourceTypeAvailable(.camera) {
                    Button { showCamera = true } label: { Label("カメラで撮る", systemImage: "camera") }
                        .disabled(images.count >= 4)
                }
            }
            if !images.isEmpty {
                Section("写真(\(images.count)枚)") {
                    ScrollView(.horizontal) {
                        HStack {
                            ForEach(images.indices, id: \.self) { i in
                                Image(uiImage: images[i]).resizable().scaledToFit().frame(height: 120)
                                    .overlay(alignment: .topTrailing) {
                                        Button { images.remove(at: i) } label: {
                                            Image(systemName: "xmark.circle.fill").foregroundStyle(.white, .red)
                                        }
                                    }
                            }
                        }
                    }
                }
            }
            Section {
                Button {
                    Task { await run() }
                } label: {
                    HStack {
                        if running { ProgressView() }
                        Text(running ? progressText : "読み取り開始").bold()
                    }
                }
                .disabled(images.isEmpty || running)
                if let e = errorText {
                    Text(e).foregroundStyle(.red).font(.footnote)
                }
            } footer: {
                Text("モデル: \(store.settings.model) / \(store.settings.tileMode.label)。複雑な図面は1〜3分かかります。")
            }
        }
        .navigationTitle("図面の読み取り")
        .onChange(of: picks) { _, newValue in
            Task {
                var out: [UIImage] = []
                for item in newValue {
                    if let d = try? await item.loadTransferable(type: Data.self), let img = UIImage(data: d) { out.append(img) }
                }
                images = Array(out.prefix(4))
            }
        }
        .sheet(isPresented: $showCamera) {
            CameraPicker { img in if let img { images.append(img) } }
                .ignoresSafeArea()
        }
        .navigationDestination(item: $openID) { id in
            DrawingDetailView(drawingID: id)
        }
    }

    private func run() async {
        errorText = nil
        running = true
        defer { running = false }
        var rec = DrawingRecord()
        rec.imageFiles = images.compactMap { store.storeImage($0) }
        let reader = DrawingReader(apiKey: store.apiKey, settings: store.settings)
        do {
            let result = try await reader.read(images: images, into: rec) { text in progressText = text }
            store.upsert(result)
            images = []
            picks = []
            openID = result.id
        } catch {
            errorText = error.localizedDescription
            for f in rec.imageFiles { try? FileManager.default.removeItem(at: store.imagesDir.appendingPathComponent(f)) }
        }
    }
}

// MARK: - 図面の詳細(部品一覧)

struct DrawingDetailView: View {
    @Environment(AppStore.self) private var store
    let drawingID: UUID
    @State private var rerunning = false
    @State private var progressText = ""
    @State private var errorText: String?
    @State private var showAnalysis = false

    private var index: Int? { store.drawings.firstIndex { $0.id == drawingID } }

    var body: some View {
        if let i = index {
            let d = store.drawings[i]
            List {
                Section {
                    LabeledContent("品名", value: d.title)
                    LabeledContent("図番", value: d.drawingNumber)
                    LabeledContent("製番", value: d.productNumber)
                    if !d.notes.isEmpty {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("注記").font(.caption).foregroundStyle(.secondary)
                            ForEach(d.notes, id: \.self) { Text("・" + $0).font(.footnote) }
                        }
                    }
                }
                if !d.questions.isEmpty {
                    Section("確認してほしいこと") {
                        ForEach(d.questions, id: \.self) { q in
                            Label(q, systemImage: "questionmark.circle").font(.footnote).foregroundStyle(.orange)
                        }
                    }
                }
                Section("部品") {
                    ForEach(d.parts) { p in
                        NavigationLink {
                            PartDetailView(drawingID: drawingID, partID: p.id)
                        } label: {
                            PartRow(part: p, settings: store.settings)
                        }
                    }
                }
                Section {
                    Button {
                        Task { await rerunAll() }
                    } label: {
                        HStack {
                            if rerunning { ProgressView() }
                            Text(rerunning ? progressText : "この図面をすべて読み直す")
                        }
                    }
                    .disabled(rerunning)
                    if let e = errorText { Text(e).foregroundStyle(.red).font(.footnote) }
                    Button("AIの読み取りメモを見る") { showAnalysis = true }
                    NavigationLink("AIの返答(部品一覧・生データ)を見る") {
                        RawTextView(title: "部品一覧の返答", text: d.rawInventory ?? "まだ返答がありません")
                    }
                }
                if !d.imageFiles.isEmpty {
                    Section("元の写真") {
                        ForEach(d.imageFiles, id: \.self) { f in
                            if let img = store.loadImage(f) {
                                Image(uiImage: img).resizable().scaledToFit()
                            }
                        }
                    }
                }
            }
            .navigationTitle(d.title.isEmpty ? "図面" : d.title)
            .navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented: $showAnalysis) {
                NavigationStack {
                    ScrollView { Text(d.analysis).font(.footnote).padding().textSelection(.enabled) }
                        .navigationTitle("読み取りメモ")
                }
            }
        } else {
            Text("図面が見つかりません")
        }
    }

    private func rerunAll() async {
        guard let i = index else { return }
        rerunning = true
        errorText = nil
        defer { rerunning = false }
        let base = store.drawings[i]
        let imgs = base.imageFiles.compactMap { store.loadImage($0) }
        guard !imgs.isEmpty else { errorText = "元の写真がありません"; return }
        let reader = DrawingReader(apiKey: store.apiKey, settings: store.settings)
        do {
            var fresh = base
            fresh.parts = []
            let r = try await reader.read(images: imgs, into: fresh) { progressText = $0 }
            store.upsert(r)
        } catch {
            errorText = error.localizedDescription
        }
    }
}

struct PartRow: View {
    let part: Part
    let settings: AppSettings

    var body: some View {
        let built = part.process == .laser ? Geometry.build(part: part, settings: settings) : nil
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 3) {
                HStack {
                    Text("\(part.partKey) \(part.name)").font(.headline)
                    if part.mirrorPair { Text("勝手違い有").font(.caption2).padding(3).background(.purple.opacity(0.15)).clipShape(RoundedRectangle(cornerRadius: 4)) }
                }
                Text("\(part.process.label)  \(part.groupKey)  ×\(part.quantity)")
                    .font(.caption).foregroundStyle(.secondary)
                if let b = built {
                    if !b.blocking.isEmpty {
                        Text(b.blocking.joined(separator: "、")).font(.caption2).foregroundStyle(.red)
                    } else {
                        Text("展開 \(Fmt.num(b.width)) × \(Fmt.num(b.height))  警告\(b.warnings.count)件")
                            .font(.caption2).foregroundStyle(b.warnings.isEmpty ? Color.green : Color.orange)
                    }
                }
            }
            Spacer()
            if let b = built, !b.outline.isEmpty {
                PartPreview(built: b, showBends: false).frame(width: 70, height: 50)
            }
        }
    }
}
