import SwiftUI
import UIKit

// MARK: - 板厚・材質別まとめ書き出し

struct GroupExportView: View {
    @Environment(AppStore.self) private var store
    @State private var selected: String?
    @State private var shareURLs: [URL] = []
    @State private var showShare = false
    @State private var skipped: [String] = []

    var body: some View {
        let groups = Exporter.groups(store.drawings)
        List {
            Section {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(groups) { g in
                            Button {
                                selected = g.key
                            } label: {
                                VStack {
                                    Text(g.key).bold()
                                    Text("\(g.items.count)部品").font(.caption2)
                                }
                                .padding(.horizontal, 12).padding(.vertical, 8)
                                .background(selected == g.key ? Color.accentColor : Color.gray.opacity(0.15))
                                .foregroundStyle(selected == g.key ? Color.white : Color.primary)
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
            } footer: {
                Text("材質・板厚のボタンを押すと、その板で抜く部品がまとまって出ます。割付はアマダ側のソフトで行ってください。")
            }

            if let key = selected, let g = groups.first(where: { $0.key == key }) {
                Section(key) {
                    ForEach(g.items) { it in
                        HStack {
                            VStack(alignment: .leading) {
                                Text("\(it.part.partKey) \(it.part.name)").font(.subheadline)
                                Text("\(it.drawing.drawingNumber)  ×\(it.part.quantity)\(it.part.mirrorPair ? " +勝手違い" : "")")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            let b = Geometry.build(part: it.part, settings: store.settings)
                            if !b.outline.isEmpty {
                                PartPreview(built: b, showBends: false).frame(width: 60, height: 40)
                            } else {
                                Image(systemName: "xmark.octagon").foregroundStyle(.red)
                            }
                        }
                    }
                    Button {
                        let r = Exporter.export(items: g.items, settings: store.settings)
                        shareURLs = r.urls
                        skipped = r.skipped
                        showShare = !r.urls.isEmpty
                    } label: {
                        Label("\(key) のDXFをまとめて書き出す", systemImage: "square.and.arrow.up").bold()
                    }
                    ForEach(skipped, id: \.self) { Text("書き出せなかった: " + $0).font(.caption).foregroundStyle(.red) }
                }
            }
        }
        .navigationTitle("板厚・材質別")
        .sheet(isPresented: $showShare) { ShareSheet(items: shareURLs) }
        .onAppear { if selected == nil { selected = groups.first?.key } }
    }
}

// MARK: - 設定

struct SettingsView: View {
    @Environment(AppStore.self) private var store
    @State private var keyText = ""

    var body: some View {
        @Bindable var store = store
        Form {
            Section("Claude APIキー") {
                SecureField("sk-ant-…", text: $keyText)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                Button("保存") { store.apiKey = keyText.trimmingCharacters(in: .whitespacesAndNewlines) }
                Text(store.apiKey.isEmpty ? "未設定" : "設定済み").font(.caption).foregroundStyle(.secondary)
            }
            Section("読み取り") {
                Picker("AIモデル", selection: $store.settings.model) {
                    ForEach(AppSettings.models.indices, id: \.self) { i in
                        Text(AppSettings.models[i].label).tag(AppSettings.models[i].id)
                    }
                }
                Picker("拡大の細かさ", selection: $store.settings.tileMode) {
                    ForEach(TileMode.allCases) { Text($0.label).tag($0) }
                }
            }
            Section("DXF") {
                Toggle("曲げ線をBENDレイヤーに出す", isOn: $store.settings.includeBendLayer)
                Toggle("ファイル名を英数字のみにする", isOn: $store.settings.asciiFileNames)
            }
            Section {
                NavigationLink("曲げ控除表") { DeductionTableView() }
                NavigationLink("タップ下穴表") { TapTableView() }
            } footer: {
                Text("控除表の初期値はすべて仮の値です。現場の曲げ控除表の数値に必ず入れ替えてください。")
            }
            Section { LabeledContent("バージョン", value: AppInfo.version) }
        }
        .navigationTitle("設定")
        .onAppear { keyText = store.apiKey }
    }
}

struct DeductionTableView: View {
    @Environment(AppStore.self) private var store

    var body: some View {
        @Bindable var store = store
        List {
            ForEach(["SPCC", "SUS", "AL"], id: \.self) { g in
                Section(g == "SPCC" ? "SPCC / SPHC / SS400" : (g == "SUS" ? "SUS" : "アルミ")) {
                    ForEach($store.settings.deductions) { $row in
                        if row.materialGroup == g {
                            HStack {
                                NumField(label: "t", value: $row.thickness)
                                NumField(label: "V", value: $row.vWidth)
                                NumField(label: "控除", value: $row.value90)
                                    .onChange(of: row.value90) { _, _ in $row.provisional.wrappedValue = false }
                                if row.provisional { Text("仮").font(.caption2).foregroundStyle(.orange) }
                            }
                        }
                    }
                    Button("\(g) の行を追加") {
                        store.settings.deductions.append(DeductionRow(materialGroup: g, thickness: 0, vWidth: 0, value90: 0, provisional: false))
                    }
                }
            }
            Section {
                Button("仮値マークをすべて外す(会社の表を入力済み)") {
                    for i in store.settings.deductions.indices { store.settings.deductions[i].provisional = false }
                }
                Button("初期値に戻す", role: .destructive) { store.settings.deductions = AppSettings.defaultDeductions }
            } footer: {
                Text("90°曲げ1回あたりの控除値(mm)。展開長 = 外寸の合計 − 控除値×曲げ回数。同じ板厚が複数行あるときは上の行を使います。")
            }
        }
        .navigationTitle("曲げ控除表")
    }
}

struct TapTableView: View {
    @Environment(AppStore.self) private var store

    var body: some View {
        @Bindable var store = store
        List {
            ForEach($store.settings.tapDrills) { $row in
                HStack {
                    TextField("M3", text: $row.size).frame(width: 70)
                    NumField(label: "下穴φ", value: $row.drill)
                }
            }
            .onDelete { store.settings.tapDrills.remove(atOffsets: $0) }
            Button("行を追加") { store.settings.tapDrills.append(TapDrillRow(size: "M", drill: 0)) }
        }
        .navigationTitle("タップ下穴表")
    }
}

// MARK: - 転送案内

struct TransferGuideView: View {
    var body: some View {
        List {
            Section("iPhone → 会社のパソコン") {
                Label("「板厚別」タブで材質・板厚を選び、DXFをまとめて書き出す", systemImage: "1.circle")
                Label("共有メニューで OneDrive / Googleドライブ / メール などに保存", systemImage: "2.circle")
                Label("会社のWindowsパソコンで同じ場所からDXFを取り出す(USBメモリ経由でも可)", systemImage: "3.circle")
                Label("アマダのプログラム作成ソフトでDXFを読み込み、割付・加工条件を設定", systemImage: "4.circle")
            }
            Section("DXFの中身") {
                Text("・形式: AutoCAD R12(AC1009)、単位mm、原点は左下\n・切断線はすべて CUT レイヤー(LINE / ARC / CIRCLE)\n・曲げ線は設定でONにしたときだけ BEND レイヤー\n・勝手違いは _MIRROR 付きの別ファイル\n・ファイル名の _x2 は必要数量")
                    .font(.footnote)
            }
        }
        .navigationTitle("転送案内")
    }
}

// MARK: - UIKit 部品

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

struct CameraPicker: UIViewControllerRepresentable {
    let onPick: (UIImage?) -> Void
    @Environment(\.dismiss) private var dismiss

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let p = UIImagePickerController()
        p.sourceType = .camera
        p.delegate = context.coordinator
        return p
    }
    func updateUIViewController(_ vc: UIImagePickerController, context: Context) {}

    final class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent: CameraPicker
        init(_ p: CameraPicker) { parent = p }
        func imagePickerController(_ picker: UIImagePickerController,
                                   didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            parent.onPick(info[.originalImage] as? UIImage)
            parent.dismiss()
        }
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.onPick(nil)
            parent.dismiss()
        }
    }
}
