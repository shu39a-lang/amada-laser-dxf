import SwiftUI

// MARK: - 展開形状のプレビュー

struct PartPreview: View {
    let built: BuiltPart
    var showBends: Bool = true
    var showDims: Bool = false

    var body: some View {
        Canvas { ctx, size in
            let pad: CGFloat = showDims ? 22 : 4
            let w = max(built.width, 1), h = max(built.height, 1)
            let s = min((size.width - pad * 2) / w, (size.height - pad * 2) / h)
            let ox = (size.width - w * s) / 2, oy = (size.height + h * s) / 2
            func pt(_ p: P2) -> CGPoint { CGPoint(x: ox + p.x * s, y: oy - p.y * s) }
            func path(_ segs: [Seg]) -> Path {
                var path = Path()
                for seg in segs {
                    switch seg {
                    case .line(let a, let b):
                        path.move(to: pt(a)); path.addLine(to: pt(b))
                    case .arc(let c, let r, let s0, let e0):
                        // 画面はY下向きなので角度の符号を反転
                        var sub = Path()
                        sub.addArc(center: pt(c), radius: r * s,
                                   startAngle: .degrees(-s0), endAngle: .degrees(-e0), clockwise: true)
                        path.addPath(sub)
                    case .circle(let c, let r):
                        path.addEllipse(in: CGRect(x: pt(c).x - r * s, y: pt(c).y - r * s, width: r * 2 * s, height: r * 2 * s))
                    }
                }
                return path
            }
            ctx.stroke(path(built.outline), with: .color(.primary), lineWidth: 1.2)
            ctx.stroke(path(built.holes), with: .color(.blue), lineWidth: 1)
            if showBends {
                ctx.stroke(path(built.bendLines), with: .color(.red), style: StrokeStyle(lineWidth: 0.8, dash: [4, 3]))
            }
            if showDims {
                ctx.draw(Text(Fmt.num(built.width)).font(.caption2), at: CGPoint(x: size.width / 2, y: oy + 12))
                ctx.draw(Text(Fmt.num(built.height)).font(.caption2), at: CGPoint(x: ox - 12, y: size.height / 2))
            }
        }
    }
}

// MARK: - 部品の詳細・修正

struct PartDetailView: View {
    @Environment(AppStore.self) private var store
    let drawingID: UUID
    let partID: UUID
    @State private var mirroredPreview = false
    @State private var rereading = false
    @State private var errorText: String?
    @State private var shareURLs: [URL] = []
    @State private var showShare = false

    private var di: Int? { store.drawings.firstIndex { $0.id == drawingID } }
    private var pi: Int? {
        guard let di else { return nil }
        return store.drawings[di].parts.firstIndex { $0.id == partID }
    }

    var body: some View {
        @Bindable var store = store
        if let di, let pi {
            let part = store.drawings[di].parts[pi]
            let built = Geometry.build(part: part, settings: store.settings, mirrored: mirroredPreview)
            let binding = $store.drawings[di].parts[pi]
            Form {
                if part.process == .laser {
                    Section {
                        if !built.outline.isEmpty {
                            PartPreview(built: built, showBends: true, showDims: true)
                                .frame(height: 220)
                            if part.mirrorPair {
                                Toggle("勝手違い(反転)を表示", isOn: $mirroredPreview)
                            }
                        }
                        ForEach(built.blocking, id: \.self) { Label($0, systemImage: "xmark.octagon").foregroundStyle(.red).font(.footnote) }
                        ForEach(built.warnings, id: \.self) { Label($0, systemImage: "exclamationmark.triangle").foregroundStyle(.orange).font(.footnote) }
                    }
                }
                Section("部品情報") {
                    TextField("名前", text: binding.name)
                    Picker("加工", selection: binding.process) {
                        ForEach(PartProcess.allCases) { Text($0.label).tag($0) }
                    }
                    TextField("材質", text: binding.material)
                    HStack {
                        Text("板厚 t")
                        ThicknessField(part: binding)
                    }
                    if !part.thicknessEvidence.isEmpty {
                        Text("板厚の根拠(\(part.thicknessSource)): \(part.thicknessEvidence)").font(.caption).foregroundStyle(.secondary)
                    }
                    Stepper("数量 \(part.quantity)", value: binding.quantity, in: 1...999)
                    Toggle("勝手違い(反転品)も出す", isOn: binding.mirrorPair)
                    Toggle("書き出しに含める", isOn: binding.include)
                }
                if part.process == .laser {
                    flatEditors(binding: binding)
                    Section("読み直し") {
                        TextField("AIへの指示(例: 下の正面図の板だけ。U溝は2か所。板厚t4)", text: binding.userHint, axis: .vertical)
                            .lineLimit(2...5)
                        Button {
                            Task { await reread() }
                        } label: {
                            HStack { if rereading { ProgressView() }; Text(rereading ? "読み取り中…" : "この部品だけ読み直す") }
                        }
                        .disabled(rereading)
                        if let e = errorText ?? part.readError { Text(e).foregroundStyle(.red).font(.footnote) }
                    }
                    Section {
                        Button("この部品のDXFを書き出す") {
                            let item = Exporter.Item(drawing: store.drawings[di], part: part)
                            let r = Exporter.export(items: [item], settings: store.settings)
                            shareURLs = r.urls
                            errorText = r.skipped.isEmpty ? nil : r.skipped.joined(separator: "\n")
                            showShare = !r.urls.isEmpty
                        }
                        .disabled(!built.blocking.isEmpty)
                    }
                    if let f = part.flat, !f.analysis.isEmpty {
                        Section("AIの読み取りメモ") { Text(f.analysis).font(.caption).textSelection(.enabled) }
                    }
                    Section {
                        NavigationLink("AIの返答(生データ)を見る") {
                            RawTextView(title: "\(part.partKey) の返答", text: part.flat?.rawJSON ?? (part.readError ?? "まだ返答がありません"))
                        }
                    } footer: {
                        Text("うまく読めないときは、この画面のスクショを開発担当に送ってください")
                    }
                }
            }
            .navigationTitle("\(part.partKey) \(part.name)")
            .navigationBarTitleDisplayMode(.inline)
            .onDisappear { store.save() }
            .sheet(isPresented: $showShare) { ShareSheet(items: shareURLs) }
        } else {
            Text("部品が見つかりません")
        }
    }

    @ViewBuilder
    private func flatEditors(binding: Binding<Part>) -> some View {
        let flat = Binding<FlatPattern>(
            get: { binding.wrappedValue.flat ?? FlatPattern() },
            set: { binding.wrappedValue.flat = $0 }
        )
        Section {
            Picker("座標の種類", selection: flat.developedBy) {
                Text("平板(図面寸法そのまま)").tag(DevelopMode.flat)
                Text("曲げあり(外寸合算→控除)").tag(DevelopMode.outerDims)
            }
            .font(.footnote)
        }
        Section {
            ForEach(flat.outline) { $v in
                VStack(alignment: .leading) {
                    HStack {
                        NumField(label: "X", value: $v.x)
                        NumField(label: "Y", value: $v.y)
                    }
                    HStack {
                        Picker("角", selection: $v.cornerType) {
                            ForEach(CornerType.allCases) { Text($0.label).tag($0) }
                        }
                        .labelsHidden()
                        if v.cornerType != .none { NumField(label: "大きさ", value: $v.cornerSize) }
                        if v.arcToNext != nil { Text("次まで円弧").font(.caption2).foregroundStyle(.purple) }
                    }
                }
            }
            .onDelete { flat.wrappedValue.outline.remove(atOffsets: $0) }
            Button("頂点を追加") { flat.wrappedValue.outline.append(OutlineVertex(x: 0, y: 0)) }
        } header: {
            Text("外形の頂点(反時計回り・mm)")
        }
        Section("穴(\(flat.wrappedValue.holes.count)個)") {
            ForEach(flat.holes) { $h in
                VStack(alignment: .leading) {
                    Picker("種類", selection: $h.type) { ForEach(HoleType.allCases) { Text($0.label).tag($0) } }
                        .pickerStyle(.segmented)
                    switch h.type {
                    case .circle:
                        HStack { NumField(label: "X", value: $h.cx); NumField(label: "Y", value: $h.cy); NumField(label: "φ", value: $h.d) }
                    case .slot:
                        HStack { NumField(label: "X1", value: $h.x1); NumField(label: "Y1", value: $h.y1) }
                        HStack { NumField(label: "X2", value: $h.x2); NumField(label: "Y2", value: $h.y2); NumField(label: "幅", value: $h.width) }
                    case .rect:
                        HStack { NumField(label: "X", value: $h.cx); NumField(label: "Y", value: $h.cy) }
                        HStack { NumField(label: "幅", value: $h.w); NumField(label: "高", value: $h.h); NumField(label: "角度", value: $h.angle); NumField(label: "R", value: $h.cornerR) }
                    case .polygon:
                        Text("頂点 \(h.points.count)個(編集は読み直しで)").font(.caption)
                    }
                    if !h.note.isEmpty { Text(h.note).font(.caption2).foregroundStyle(.secondary) }
                }
            }
            .onDelete { flat.wrappedValue.holes.remove(atOffsets: $0) }
            Button("丸穴を追加") { flat.wrappedValue.holes.append(Hole(type: .circle, d: 10)) }
        }
        Section("曲げ線(\(flat.wrappedValue.bends.count)本)") {
            ForEach(flat.bends) { $b in
                HStack {
                    Picker("", selection: $b.axis) { ForEach(BendAxis.allCases) { Text($0.rawValue.uppercased()).tag($0) } }
                        .labelsHidden().frame(width: 60)
                    NumField(label: "位置", value: $b.position)
                    NumField(label: "角度", value: $b.angleDeg)
                }
            }
            .onDelete { flat.wrappedValue.bends.remove(atOffsets: $0) }
            Button("曲げ線を追加") { flat.wrappedValue.bends.append(Bend()) }
        }
    }

    private func reread() async {
        guard let di, let pi else { return }
        rereading = true
        errorText = nil
        defer { rereading = false }
        let d = store.drawings[di]
        let part = d.parts[pi]
        let imgs = d.imageFiles.compactMap { store.loadImage($0) }
        guard !imgs.isEmpty else { errorText = "元の写真がありません"; return }
        let reader = DrawingReader(apiKey: store.apiKey, settings: store.settings)
        do {
            let f = try await reader.reread(part: part, drawing: d, images: imgs)
            if let di2 = store.drawings.firstIndex(where: { $0.id == drawingID }),
               let pi2 = store.drawings[di2].parts.firstIndex(where: { $0.id == partID }) {
                store.drawings[di2].parts[pi2].flat = f
                store.drawings[di2].parts[pi2].readError = nil
                store.save()
            }
        } catch {
            errorText = error.localizedDescription
        }
    }
}

struct NumField: View {
    let label: String
    @Binding var value: Double

    var body: some View {
        HStack(spacing: 2) {
            Text(label).font(.caption2).foregroundStyle(.secondary)
            TextField(label, value: $value, format: .number)
                .keyboardType(.numbersAndPunctuation)
                .textFieldStyle(.roundedBorder)
                .font(.footnote.monospacedDigit())
        }
    }
}

struct ThicknessField: View {
    @Binding var part: Part
    @State private var text = ""

    var body: some View {
        TextField("未確定", text: $text)
            .keyboardType(.decimalPad)
            .multilineTextAlignment(.trailing)
            .onAppear { text = part.thickness.map(Fmt.num) ?? "" }
            .onChange(of: text) { _, t in
                let v = Double(t.trimmingCharacters(in: .whitespaces))
                if v != part.thickness {
                    part.thickness = v
                    part.thicknessSource = v == nil ? "unknown" : "user"
                }
            }
    }
}

struct RawTextView: View {
    let title: String
    let text: String

    var body: some View {
        ScrollView {
            Text(text)
                .font(.system(.caption2, design: .monospaced))
                .textSelection(.enabled)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
        }
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                ShareLink(item: text) { Image(systemName: "square.and.arrow.up") }
            }
        }
    }
}
