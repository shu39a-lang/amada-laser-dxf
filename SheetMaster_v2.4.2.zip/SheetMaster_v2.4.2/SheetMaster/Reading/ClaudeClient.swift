import Foundation

enum ClaudeError: LocalizedError {
    case noAPIKey
    case http(Int, String)
    case truncated
    case noToolResult(String)
    case network(String)
    case refused

    var errorDescription: String? {
        switch self {
        case .noAPIKey: return "APIキーが設定されていません(設定タブで入力してください)"
        case .http(let code, let msg):
            switch code {
            case 401: return "APIキーが正しくありません(401)"
            case 403: return "このAPIキーでは使えません(403): \(msg)"
            case 413: return "画像が大きすぎます(413)。写真の枚数を減らしてください"
            case 429: return "利用制限に達しました(429)。少し待ってから再実行してください"
            case 529: return "AIが混み合っています(529)。少し待ってから再実行してください"
            default: return "APIエラー(\(code)): \(msg)"
            }
        case .truncated: return "回答が長すぎて途中で切れました"
        case .noToolResult(let s): return "読み取り結果の形式が不正でした: \(s.prefix(200))"
        case .network(let s): return "通信エラー: \(s)"
        case .refused: return "AIが回答を控えました(安全チェックの誤判定と思われます)。「この部品だけ読み直す」をもう一度押すか、設定でAIモデルを切り替えてください"
        }
    }
}

/// Claude Messages API を「ツール強制」で呼び出し、必ずJSON(ツール入力)で受け取る。
/// v2.2 では自由文の中のJSONを取り出していたため、文章混じり・途中切れで失敗していた。
struct ClaudeClient {
    let apiKey: String
    let model: String

    private static let session: URLSession = {
        let c = URLSessionConfiguration.default
        c.timeoutIntervalForRequest = 600
        c.timeoutIntervalForResource = 900
        return URLSession(configuration: c)
    }()

    func callTool(system: String,
                  content: [[String: Any]],
                  toolName: String,
                  toolDescription: String,
                  inputSchemaJSON: String,
                  maxTokens: Int) async throws -> [String: Any] {
        guard !apiKey.isEmpty else { throw ClaudeError.noAPIKey }
        guard let schemaData = inputSchemaJSON.data(using: .utf8),
              let schema = try JSONSerialization.jsonObject(with: schemaData) as? [String: Any] else {
            throw ClaudeError.noToolResult("schema")
        }
        // 新しいモデルは tool_choice の "tool"/"any"(ツール強制)に非対応のため "auto" にし、
        // 指示文で必ずツールを使わせる。使われなかった場合は本文のJSONを拾い、それも無ければ再試行する。
        let systemWithRule = system + "\n\n【回答方法】必ず \(toolName) ツールを1回だけ呼び出して回答すること。文章だけで答えてはいけない。"
        let body: [String: Any] = [
            "model": model,
            "max_tokens": maxTokens,
            "system": systemWithRule,
            "tools": [["name": toolName, "description": toolDescription, "input_schema": schema]],
            "tool_choice": ["type": "auto"],
            "messages": [["role": "user", "content": content]]
        ]
        let bodyData = try JSONSerialization.data(withJSONObject: body)

        var req = URLRequest(url: URL(string: "https://api.anthropic.com/v1/messages")!)
        req.httpMethod = "POST"
        req.setValue(apiKey, forHTTPHeaderField: "x-api-key")
        req.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
        req.setValue("application/json", forHTTPHeaderField: "content-type")
        req.httpBody = bodyData

        var lastError: Error = ClaudeError.network("unknown")
        var formatRetried = false
        var refusalRetries = 0
        let waits: [UInt64] = [0, 3, 8, 20]
        for (attempt, w) in waits.enumerated() {
            if w > 0 { try await Task.sleep(nanoseconds: w * 1_000_000_000) }
            do {
                let (data, resp) = try await Self.session.data(for: req)
                let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
                if code == 200 {
                    do {
                        return try parse(data, toolName: toolName)
                    } catch ClaudeError.refused {
                        // 安全チェックの誤判定は再送で通ることが多い
                        lastError = ClaudeError.refused
                        if refusalRetries < 2 && attempt < waits.count - 1 { refusalRetries += 1; continue }
                        throw lastError
                    } catch ClaudeError.noToolResult(let raw) {
                        // ツールを使わずに文章で答えた場合は1回だけ聞き直す
                        lastError = ClaudeError.noToolResult(raw)
                        if !formatRetried && attempt < waits.count - 1 { formatRetried = true; continue }
                        throw lastError
                    }
                }
                let msg = Self.errorMessage(data)
                lastError = ClaudeError.http(code, msg)
                // 再試行する価値があるもの
                if [429, 500, 502, 503, 504, 529].contains(code), attempt < waits.count - 1 { continue }
                throw lastError
            } catch let e as ClaudeError {
                throw e
            } catch {
                if (error as? URLError)?.code == .cancelled || error is CancellationError { throw error }
                lastError = ClaudeError.network(error.localizedDescription)
                if attempt < waits.count - 1 { continue }
            }
        }
        throw lastError
    }

    private func parse(_ data: Data, toolName: String) throws -> [String: Any] {
        guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw ClaudeError.noToolResult(String(data: data, encoding: .utf8) ?? "")
        }
        let stop = obj["stop_reason"] as? String
        if stop == "refusal" { throw ClaudeError.refused }
        let blocks = obj["content"] as? [[String: Any]] ?? []
        if let tool = blocks.first(where: { ($0["type"] as? String) == "tool_use" }),
           let input = tool["input"] as? [String: Any] {
            if stop == "max_tokens" { throw ClaudeError.truncated }
            return input
        }
        if stop == "max_tokens" { throw ClaudeError.truncated }
        // 予備: 本文にJSONが書かれていればそれを使う
        let text = blocks.filter { ($0["type"] as? String) == "text" }.compactMap { $0["text"] as? String }.joined(separator: "\n")
        if let s = text.firstIndex(of: "{"), let e = text.lastIndex(of: "}"), s < e,
           let d = String(text[s...e]).data(using: .utf8),
           let o = try? JSONSerialization.jsonObject(with: d) as? [String: Any] {
            return o
        }
        throw ClaudeError.noToolResult(text.isEmpty ? (String(data: data, encoding: .utf8) ?? "") : text)
    }

    private static func errorMessage(_ data: Data) -> String {
        if let o = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let e = o["error"] as? [String: Any], let m = e["message"] as? String { return m }
        return String(data: data, encoding: .utf8)?.prefix(300).description ?? ""
    }

    // MARK: - 画像ブロック

    static func imageBlocks(_ images: [PreparedImage], cacheLast: Bool) -> [[String: Any]] {
        var out: [[String: Any]] = []
        for (i, img) in images.enumerated() {
            out.append(["type": "text", "text": "【画像\(i + 1)】\(img.label)"])
            var block: [String: Any] = [
                "type": "image",
                "source": ["type": "base64", "media_type": "image/jpeg", "data": img.jpeg.base64EncodedString()]
            ]
            if cacheLast && i == images.count - 1 {
                // 部品ごとの2回目以降の呼び出しで画像を再利用(料金と時間の節約)
                block["cache_control"] = ["type": "ephemeral"]
            }
            out.append(block)
        }
        return out
    }
}
