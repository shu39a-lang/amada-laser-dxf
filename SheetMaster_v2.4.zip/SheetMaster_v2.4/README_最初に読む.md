# SHEET MASTER v2.4(完成版一式)

このフォルダは、そのままビルドしてアップロードできる Xcode プロジェクト一式です。
**ソースコードの変更・既存コードとの合体はしないでください。**(前回、旧画面と混ざって読み取り結果が表示されませんでした)

## 作業は3つだけ
1. 今のリポジトリの中身(アプリのプロジェクトとソース)を、このフォルダの中身に**丸ごと置き換える**。
   GitHub Actions などのアップロード用の設定ファイルは今のものを残してよい。
   その場合、ワークフロー内のプロジェクト名・スキーム名を `SheetMaster.xcodeproj` / `SheetMaster` に合わせる。
2. `Config.xcconfig` の3行(Bundle ID・Team ID・ビルド番号)だけを書き換える。
   Bundle ID は今の TestFlight のアプリと同じにする(同じアプリの更新になる)。
3. Release でアーカイブして TestFlight にアップロードする。

## 中身
- iOS 17 以上 / SwiftUI / 外部ライブラリなし
- バージョン 2.4、アイコン・カメラ/写真の許可文・暗号化申告(なし)は設定済み
- 共有スキーム `SheetMaster` 入り(コマンドラインからもビルド可)
  例: `xcodebuild -project SheetMaster.xcodeproj -scheme SheetMaster -configuration Release -destination 'generic/platform=iOS' archive -archivePath build/SheetMaster.xcarchive`

## もしビルドエラーが出たら
エラーの出た行の文法・型だけを直し、画面構成・読み取り処理・データの形は変えないこと。
