import Foundation

// MARK: - 基本型

struct P2: Codable, Hashable {
    var x: Double
    var y: Double
}

struct ArcSpec: Codable, Hashable {
    /// 円弧の中心(この頂点 → 次の頂点 を円弧で結ぶ)
    var cx: Double
    var cy: Double
    /// true = 時計回り
    var clockwise: Bool
}

enum CornerType: String, Codable, CaseIterable, Identifiable {
    case none, chamfer, radius
    var id: String { rawValue }
    var label: String {
        switch self {
        case .none: return "なし"
        case .chamfer: return "C面取り"
        case .radius: return "R"
        }
    }
}

struct OutlineVertex: Codable, Hashable, Identifiable {
    var id = UUID()
    var x: Double
    var y: Double
    var cornerType: CornerType = .none
    var cornerSize: Double = 0
    var arcToNext: ArcSpec? = nil

    enum CodingKeys: String, CodingKey { case x, y, cornerType, cornerSize, arcToNext }
}

enum HoleType: String, Codable, CaseIterable, Identifiable {
    case circle, slot, rect, polygon
    var id: String { rawValue }
    var label: String {
        switch self {
        case .circle: return "丸穴"
        case .slot: return "長穴"
        case .rect: return "角穴"
        case .polygon: return "多角形"
        }
    }
}

struct Hole: Codable, Hashable, Identifiable {
    var id = UUID()
    var type: HoleType = .circle
    // circle / rect
    var cx: Double = 0
    var cy: Double = 0
    var d: Double = 0
    // slot(両端の円の中心と幅)
    var x1: Double = 0
    var y1: Double = 0
    var x2: Double = 0
    var y2: Double = 0
    var width: Double = 0
    // rect
    var w: Double = 0
    var h: Double = 0
    var angle: Double = 0
    var cornerR: Double = 0
    // polygon
    var points: [P2] = []
    var note: String = ""

    enum CodingKeys: String, CodingKey {
        case type, cx, cy, d, x1, y1, x2, y2, width, w, h, angle, cornerR, points, note
    }
}

enum BendAxis: String, Codable, CaseIterable, Identifiable {
    /// x = 縦の曲げ線(x = position の直線)
    case x
    /// y = 横の曲げ線(y = position の直線)
    case y
    var id: String { rawValue }
    var label: String { self == .x ? "縦線(X位置)" : "横線(Y位置)" }
}

struct Bend: Codable, Hashable, Identifiable {
    var id = UUID()
    var axis: BendAxis = .x
    var position: Double = 0
    var angleDeg: Double = 90
    var up: Bool = true
    var note: String = ""

    enum CodingKeys: String, CodingKey { case axis, position, angleDeg, up, note }
}

struct KeyDimension: Codable, Hashable, Identifiable {
    var id = UUID()
    var label: String
    var value: Double
    /// "x" = 展開前の全体横寸法, "y" = 全体縦寸法, "none" = 参考
    var axis: String

    enum CodingKeys: String, CodingKey { case label, value, axis }
}

enum DevelopMode: String, Codable {
    /// 曲げなし。座標は図面寸法そのまま
    case flat
    /// 曲げあり。外寸を足し合わせた座標(控除はアプリが引く)
    case outerDims
}

struct FlatPattern: Codable, Hashable {
    var developedBy: DevelopMode = .flat
    var outline: [OutlineVertex] = []
    var holes: [Hole] = []
    var bends: [Bend] = []
    var keyDimensions: [KeyDimension] = []
    var uncertain: [String] = []
    var analysis: String = ""
    var confidence: Double = 0
    /// AIの返答そのもの(原因調査用)
    var rawJSON: String? = nil
}

enum PartProcess: String, Codable, CaseIterable, Identifiable {
    case laser, machined, purchased, other
    var id: String { rawValue }
    var label: String {
        switch self {
        case .laser: return "レーザー(板)"
        case .machined: return "機械加工品"
        case .purchased: return "購入品"
        case .other: return "その他"
        }
    }
}

struct Part: Codable, Hashable, Identifiable {
    var id = UUID()
    var partKey: String = "P1"
    var name: String = ""
    var material: String = ""
    var thickness: Double? = nil
    /// explicit / inferred / unknown / user
    var thicknessSource: String = "unknown"
    var thicknessEvidence: String = ""
    var process: PartProcess = .laser
    var quantity: Int = 1
    var mirrorPair: Bool = false
    var bendsCount: Int = 0
    var viewsDescription: String = ""
    var confidence: Double = 0
    var flat: FlatPattern? = nil
    var readError: String? = nil
    var userHint: String = ""
    var include: Bool = true

    var groupKey: String {
        let mat = material.isEmpty ? "材質未確定" : material
        guard let t = thickness else { return "\(mat) 板厚未確定" }
        return "\(mat) t\(Fmt.num(t))"
    }

    enum CodingKeys: String, CodingKey {
        case partKey, name, material, thickness, thicknessSource, thicknessEvidence, process,
             quantity, mirrorPair, bendsCount, viewsDescription, confidence, flat, readError, userHint, include
    }
}

struct DrawingRecord: Codable, Hashable, Identifiable {
    var id = UUID()
    var createdAt = Date()
    var drawingNumber: String = ""
    var title: String = ""
    var productNumber: String = ""
    var notes: [String] = []
    var questions: [String] = []
    var imageFiles: [String] = []
    var parts: [Part] = []
    var appVersion: String = AppInfo.version
    var analysis: String = ""
    /// 段階AのAIの返答そのもの(原因調査用)
    var rawInventory: String? = nil
}

// MARK: - 設定テーブル

struct DeductionRow: Codable, Hashable, Identifiable {
    var id = UUID()
    /// SPCC / SUS / AL
    var materialGroup: String
    var thickness: Double
    var vWidth: Double
    /// 90°曲げ1回あたりの控除値(mm)
    var value90: Double
    var provisional: Bool = true
}

struct TapDrillRow: Codable, Hashable, Identifiable {
    var id = UUID()
    var size: String   // "M3"
    var drill: Double  // 2.5
}

enum AppInfo {
    static let version = "2.4"
}

enum Fmt {
    static func num(_ v: Double) -> String {
        if abs(v - v.rounded()) < 0.0005 { return String(Int(v.rounded())) }
        var s = String(format: "%.3f", v)
        while s.hasSuffix("0") { s.removeLast() }
        if s.hasSuffix(".") { s.removeLast() }
        return s
    }
}

/// 材質名を控除表のグループにまとめる
func materialGroup(_ material: String) -> String {
    let m = material.uppercased()
    if m.contains("SUS") || m.contains("ステン") { return "SUS" }
    if m.hasPrefix("A") && !m.hasPrefix("AL") && m.count >= 5, m.dropFirst().first?.isNumber == true { return "AL" }
    if m.contains("AL") || m.contains("アルミ") || m.contains("A5052") || m.contains("A1100") { return "AL" }
    return "SPCC"
}
