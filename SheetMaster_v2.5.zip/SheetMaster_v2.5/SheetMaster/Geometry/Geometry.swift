import Foundation

/// 描画・DXF出力用の線分
enum Seg: Hashable {
    case line(P2, P2)
    /// 中心・半径・始点角・終点角(度)。DXFと同じく常に反時計回り(start→end)
    case arc(center: P2, r: Double, startDeg: Double, endDeg: Double)
    case circle(center: P2, r: Double)
}

struct HoleLabel: Hashable {
    var pos: P2
    var text: String
    var position: String
}

struct BuiltPart {
    var holeLabels: [HoleLabel] = []
    var outline: [Seg] = []
    var holes: [Seg] = []
    /// 曲げ線(参考)
    var bendLines: [Seg] = []
    var width: Double = 0
    var height: Double = 0
    var warnings: [String] = []
    var blocking: [String] = []   // これがあるとDXFを出さない
}

enum Geometry {

    // MARK: - 部品 → 展開済みの線分

    static func build(part: Part, settings: AppSettings, mirrored: Bool = false) -> BuiltPart {
        var out = BuiltPart()
        guard var f = part.flat else {
            out.blocking.append(part.readError ?? "展開形状がまだありません")
            return out
        }
        if part.thickness == nil { out.blocking.append("板厚が未確定です") }
        if f.outline.count < 3 { out.blocking.append("外形の頂点が3つ未満です"); return out }

        // 1) 展開前のサイズ確認(AIの検算)
        let pre = bbox(of: polygonPoints(f.outline))
        for k in f.keyDimensions {
            let actual: Double? = k.axis == "x" ? pre.w : (k.axis == "y" ? pre.h : nil)
            if let a = actual, abs(a - k.value) > 0.6 {
                out.warnings.append("全体寸法の不一致: \(k.label) 図面\(Fmt.num(k.value)) / 外形\(Fmt.num(a))")
            }
        }

        // 2) 曲げ控除
        if f.developedBy == .outerDims && !f.bends.isEmpty {
            if let t = part.thickness {
                if let row = settings.deduction(material: part.material, thickness: t) {
                    if row.provisional { out.warnings.append("控除値が仮値です(\(row.materialGroup) t\(Fmt.num(t)) = \(Fmt.num(row.value90))mm)。設定で会社の表に直してください") }
                    f = unfold(f, deduction90: row.value90, warnings: &out.warnings)
                } else {
                    out.blocking.append("控除表に \(materialGroup(part.material)) t\(Fmt.num(t)) がありません(設定で追加してください)")
                }
            }
        }

        // 3) 原点を左下に合わせる
        let b = bbox(of: polygonPoints(f.outline))
        f = translate(f, dx: -b.minX, dy: -b.minY)
        if mirrored { f = mirror(f, width: b.w) }

        out.width = b.w
        out.height = b.h
        var warns = out.warnings
        let outlineSegs = polygonSegments(f.outline, warnings: &warns)
        var holeSegs: [Seg] = []
        for h in f.holes { holeSegs += holeSegments(h, warnings: &warns) }
        out.outline = outlineSegs
        out.holes = holeSegs
        out.warnings = warns
        for bd in f.bends {
            if bd.axis == .x { out.bendLines.append(.line(P2(x: bd.position, y: 0), P2(x: bd.position, y: b.h))) }
            else { out.bendLines.append(.line(P2(x: 0, y: bd.position), P2(x: b.w, y: bd.position))) }
        }

        out.holeLabels = f.holes.map { h in
            let c = holeCenter(h)
            let t: String
            switch h.type {
            case .circle: t = "φ" + Fmt.num(h.d)
            case .slot: t = "長穴" + Fmt.num(h.width) + "×" + Fmt.num(dist(P2(x: h.x1, y: h.y1), P2(x: h.x2, y: h.y2)) + h.width)
            case .rect: t = "□" + Fmt.num(h.w) + "×" + Fmt.num(h.h)
            case .polygon: t = "異形"
            }
            return HoleLabel(pos: c, text: t, position: "(\(Fmt.num(c.x)), \(Fmt.num(c.y)))")
        }

        // 4) 穴が外形の中にあるか
        let poly = sampled(out.outline)
        for (i, h) in f.holes.enumerated() {
            let c = holeCenter(h)
            if !pointInPolygon(c, poly) { out.warnings.append("穴\(i + 1)(\(h.type.label))が外形の外にあります") }
        }
        for i in 0..<f.holes.count {
            for j in (i + 1)..<max(i + 1, f.holes.count) where f.holes[i].type == .circle && f.holes[j].type == .circle {
                if dist(holeCenter(f.holes[i]), holeCenter(f.holes[j])) < 0.3 { out.warnings.append("穴\(i + 1)と穴\(j + 1)が重なっています") }
            }
        }
        if !f.uncertain.isEmpty { out.warnings += f.uncertain.map { "AI確認事項: " + $0 } }
        return out
    }

    // MARK: - 曲げ控除(外寸合算座標 → 展開座標)

    static func unfold(_ f: FlatPattern, deduction90: Double, warnings: inout [String]) -> FlatPattern {
        func ded(_ b: Bend) -> Double {
            let a = b.angleDeg <= 0 ? 90 : b.angleDeg
            return deduction90 * a / 90
        }
        for b in f.bends where b.angleDeg > 0 && abs(b.angleDeg - 90) > 0.5 {
            warnings.append("\(Fmt.num(b.angleDeg))°曲げは90°の控除値から比例計算しています(要確認)")
        }
        let xs = f.bends.filter { $0.axis == .x }.sorted { $0.position < $1.position }
        let ys = f.bends.filter { $0.axis == .y }.sorted { $0.position < $1.position }
        let xd = xs.map { ($0.position, ded($0)) }
        let yd = ys.map { ($0.position, ded($0)) }
        func sx(_ x: Double) -> Double { x - xd.filter { $0.0 < x - 0.001 }.reduce(0) { $0 + $1.1 } }
        func sy(_ y: Double) -> Double { y - yd.filter { $0.0 < y - 0.001 }.reduce(0) { $0 + $1.1 } }
        func sp(_ p: P2) -> P2 { P2(x: sx(p.x), y: sy(p.y)) }

        var g = f
        g.outline = f.outline.map { v in
            var n = v
            n.x = sx(v.x); n.y = sy(v.y)
            if let a = v.arcToNext { n.arcToNext = ArcSpec(cx: sx(a.cx), cy: sy(a.cy), clockwise: a.clockwise) }
            return n
        }
        g.holes = f.holes.map { h in
            var n = h
            let c = sp(P2(x: h.cx, y: h.cy)); n.cx = c.x; n.cy = c.y
            let p1 = sp(P2(x: h.x1, y: h.y1)); n.x1 = p1.x; n.y1 = p1.y
            let p2 = sp(P2(x: h.x2, y: h.y2)); n.x2 = p2.x; n.y2 = p2.y
            n.points = h.points.map(sp)
            return n
        }
        g.bends = f.bends.map { b in
            var n = b
            let d = ded(b)
            n.position = (b.axis == .x ? sx(b.position) : sy(b.position)) - d / 2
            return n
        }
        g.developedBy = .flat
        return g
    }

    static func translate(_ f: FlatPattern, dx: Double, dy: Double) -> FlatPattern {
        var g = f
        g.outline = f.outline.map { v in
            var n = v; n.x += dx; n.y += dy
            if let a = v.arcToNext { n.arcToNext = ArcSpec(cx: a.cx + dx, cy: a.cy + dy, clockwise: a.clockwise) }
            return n
        }
        g.holes = f.holes.map { h in
            var n = h
            n.cx += dx; n.cy += dy; n.x1 += dx; n.y1 += dy; n.x2 += dx; n.y2 += dy
            n.points = h.points.map { P2(x: $0.x + dx, y: $0.y + dy) }
            return n
        }
        g.bends = f.bends.map { b in var n = b; n.position += (b.axis == .x ? dx : dy); return n }
        return g
    }

    /// 左右反転(勝手違い)。外形の回転方向を保つため頂点順も逆にする
    static func mirror(_ f: FlatPattern, width: Double) -> FlatPattern {
        var g = f
        let n = f.outline.count
        var verts: [OutlineVertex] = []
        for k in 0..<n {
            // 反転後は順番を逆にする。元の辺 i→i+1 の円弧は、新しい辺 (i+1)'→i' になる
            let i = (n - k) % n
            var v = f.outline[i]
            v.x = width - v.x
            let prevIdx = (i - 1 + n) % n
            if let a = f.outline[prevIdx].arcToNext {
                v.arcToNext = ArcSpec(cx: width - a.cx, cy: a.cy, clockwise: a.clockwise)
            } else {
                v.arcToNext = nil
            }
            verts.append(v)
        }
        g.outline = verts
        g.holes = f.holes.map { h in
            var m = h
            m.cx = width - h.cx; m.x1 = width - h.x1; m.x2 = width - h.x2
            m.angle = -h.angle
            m.points = h.points.reversed().map { P2(x: width - $0.x, y: $0.y) }
            return m
        }
        g.bends = f.bends.map { b in var m = b; if b.axis == .x { m.position = width - b.position }; return m }
        return g
    }

    // MARK: - 外形(角の面取り・R・円弧辺)

    static func polygonSegments(_ vs: [OutlineVertex], warnings: inout [String]) -> [Seg] {
        let n = vs.count
        guard n >= 3 else { return [] }
        let pts = vs.map { P2(x: $0.x, y: $0.y) }
        var entry = pts, exit = pts
        var cornerSegs: [Seg?] = Array(repeating: nil, count: n)

        for i in 0..<n {
            let v = vs[i]
            let prevI = (i - 1 + n) % n
            guard v.cornerType != .none, v.cornerSize > 0 else { continue }
            if vs[prevI].arcToNext != nil || v.arcToNext != nil {
                warnings.append("頂点\(i + 1): 円弧の辺と面取り/Rが重なるため角処理を省略")
                continue
            }
            let p = pts[i], a = pts[prevI], c = pts[(i + 1) % n]
            let u = norm(sub(a, p)), w = norm(sub(c, p))
            let lenA = dist(a, p), lenC = dist(c, p)
            let cosPhi = max(-1, min(1, dot(u, w)))
            let phi = acos(cosPhi)
            if phi < 0.01 || phi > .pi - 0.01 { continue }
            var dd: Double
            if v.cornerType == .chamfer {
                dd = v.cornerSize
            } else {
                dd = v.cornerSize / tan(phi / 2)
            }
            let maxD = min(lenA, lenC) * 0.5
            if dd > maxD {
                warnings.append("頂点\(i + 1): \(v.cornerType.label)\(Fmt.num(v.cornerSize))が辺より大きいため縮小")
                dd = maxD
            }
            let p1 = add(p, mul(u, dd)), p2 = add(p, mul(w, dd))
            entry[i] = p1; exit[i] = p2
            if v.cornerType == .chamfer {
                cornerSegs[i] = .line(p1, p2)
            } else {
                let r = dd * tan(phi / 2)
                let center = add(p, mul(norm(add(u, w)), r / sin(phi / 2)))
                let din = sub(p, a), dout = sub(c, p)
                let ccw = cross(din, dout) > 0
                cornerSegs[i] = arcSeg(center: center, from: p1, to: p2, ccw: ccw)
            }
        }

        var segs: [Seg] = []
        for i in 0..<n {
            if let cs = cornerSegs[i] { segs.append(cs) }
            let j = (i + 1) % n
            let s = exit[i], e = entry[j]
            if let arc = vs[i].arcToNext {
                segs.append(arcSeg(center: P2(x: arc.cx, y: arc.cy), from: s, to: e, ccw: !arc.clockwise))
            } else if dist(s, e) > 1e-6 {
                segs.append(.line(s, e))
            }
        }
        return segs
    }

    static func arcSeg(center: P2, from s: P2, to e: P2, ccw: Bool) -> Seg {
        let r = dist(center, s)
        let a1 = deg(atan2(s.y - center.y, s.x - center.x))
        let a2 = deg(atan2(e.y - center.y, e.x - center.x))
        return ccw ? .arc(center: center, r: r, startDeg: a1, endDeg: a2)
                   : .arc(center: center, r: r, startDeg: a2, endDeg: a1)
    }

    // MARK: - 穴

    static func holeSegments(_ h: Hole, warnings: inout [String]) -> [Seg] {
        switch h.type {
        case .circle:
            guard h.d > 0 else { warnings.append("径0の丸穴を除外"); return [] }
            return [.circle(center: P2(x: h.cx, y: h.cy), r: h.d / 2)]
        case .slot:
            let p1 = P2(x: h.x1, y: h.y1), p2 = P2(x: h.x2, y: h.y2), r = h.width / 2
            guard r > 0 else { warnings.append("幅0の長穴を除外"); return [] }
            if dist(p1, p2) < 1e-6 { return [.circle(center: p1, r: r)] }
            let d = norm(sub(p2, p1)), nrm = P2(x: -d.y * r, y: d.x * r)
            return [
                .line(add(p1, nrm), add(p2, nrm)),
                arcSeg(center: p2, from: add(p2, nrm), to: sub(p2, nrm), ccw: false),
                .line(sub(p2, nrm), sub(p1, nrm)),
                arcSeg(center: p1, from: sub(p1, nrm), to: add(p1, nrm), ccw: false)
            ]
        case .rect:
            guard h.w > 0, h.h > 0 else { warnings.append("サイズ0の角穴を除外"); return [] }
            let t = h.angle * .pi / 180
            let corners = [(-h.w / 2, -h.h / 2), (h.w / 2, -h.h / 2), (h.w / 2, h.h / 2), (-h.w / 2, h.h / 2)].map { c in
                OutlineVertex(x: h.cx + c.0 * cos(t) - c.1 * sin(t),
                              y: h.cy + c.0 * sin(t) + c.1 * cos(t),
                              cornerType: h.cornerR > 0 ? .radius : .none,
                              cornerSize: h.cornerR)
            }
            return polygonSegments(corners, warnings: &warnings)
        case .polygon:
            guard h.points.count >= 3 else { warnings.append("頂点不足の多角形穴を除外"); return [] }
            return polygonSegments(h.points.map { OutlineVertex(x: $0.x, y: $0.y) }, warnings: &warnings)
        }
    }

    static func holeCenter(_ h: Hole) -> P2 {
        switch h.type {
        case .circle, .rect: return P2(x: h.cx, y: h.cy)
        case .slot: return P2(x: (h.x1 + h.x2) / 2, y: (h.y1 + h.y2) / 2)
        case .polygon:
            guard !h.points.isEmpty else { return P2(x: 0, y: 0) }
            let n = Double(h.points.count)
            return P2(x: h.points.map(\.x).reduce(0, +) / n, y: h.points.map(\.y).reduce(0, +) / n)
        }
    }

    // MARK: - 補助

    static func polygonPoints(_ vs: [OutlineVertex]) -> [P2] { vs.map { P2(x: $0.x, y: $0.y) } }

    struct BBox { var minX, minY, maxX, maxY: Double; var w: Double { maxX - minX }; var h: Double { maxY - minY } }

    static func bbox(of pts: [P2]) -> BBox {
        guard let f = pts.first else { return BBox(minX: 0, minY: 0, maxX: 0, maxY: 0) }
        var b = BBox(minX: f.x, minY: f.y, maxX: f.x, maxY: f.y)
        for p in pts { b.minX = min(b.minX, p.x); b.minY = min(b.minY, p.y); b.maxX = max(b.maxX, p.x); b.maxY = max(b.maxY, p.y) }
        return b
    }

    /// 円弧を細かい点に(プレビュー・内外判定用)
    static func sampled(_ segs: [Seg]) -> [P2] {
        var pts: [P2] = []
        for s in segs {
            switch s {
            case .line(let a, let b): pts.append(a); pts.append(b)
            case .arc(let c, let r, let s0, let e0):
                var e = e0; while e <= s0 { e += 360 }
                // 円弧の向きは start→end(反時計回り)。外形の進行方向とは逆の場合があるが、内外判定では点の集合として扱う
                let steps = max(4, Int((e - s0) / 10))
                var arcPts: [P2] = []
                for k in 0...steps {
                    let a = (s0 + (e - s0) * Double(k) / Double(steps)) * .pi / 180
                    arcPts.append(P2(x: c.x + r * cos(a), y: c.y + r * sin(a)))
                }
                if let last = pts.last, let f = arcPts.first, let l = arcPts.last, dist(last, l) < dist(last, f) {
                    arcPts.reverse()
                }
                pts += arcPts
            case .circle(let c, let r):
                for k in 0..<36 {
                    let a = Double(k) * 10 * .pi / 180
                    pts.append(P2(x: c.x + r * cos(a), y: c.y + r * sin(a)))
                }
            }
        }
        return pts
    }

    static func pointInPolygon(_ p: P2, _ poly: [P2]) -> Bool {
        guard poly.count >= 3 else { return false }
        var inside = false
        var j = poly.count - 1
        for i in 0..<poly.count {
            let a = poly[i], b = poly[j]
            if (a.y > p.y) != (b.y > p.y), p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x { inside.toggle() }
            j = i
        }
        return inside
    }

    static func add(_ a: P2, _ b: P2) -> P2 { P2(x: a.x + b.x, y: a.y + b.y) }
    static func sub(_ a: P2, _ b: P2) -> P2 { P2(x: a.x - b.x, y: a.y - b.y) }
    static func mul(_ a: P2, _ k: Double) -> P2 { P2(x: a.x * k, y: a.y * k) }
    static func dot(_ a: P2, _ b: P2) -> Double { a.x * b.x + a.y * b.y }
    static func cross(_ a: P2, _ b: P2) -> Double { a.x * b.y - a.y * b.x }
    static func dist(_ a: P2, _ b: P2) -> Double { hypot(a.x - b.x, a.y - b.y) }
    static func norm(_ a: P2) -> P2 { let l = hypot(a.x, a.y); return l < 1e-12 ? a : P2(x: a.x / l, y: a.y / l) }
    static func deg(_ r: Double) -> Double { r * 180 / .pi }
}
