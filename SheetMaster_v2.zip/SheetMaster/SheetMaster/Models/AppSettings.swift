import Foundation
import Observation

/// 曲げ控除表の1行（90°曲げ・外寸基準の控除値）
struct BendEntry: Codable, Hashable, Identifiable {
    var id = UUID()
    /// 材質キー。"/" 区切りで複数可（例: "SPCC/SPHC/SS400"）。部品の材質名に含まれていれば一致
    var material: String
    var thickness: Double
    var deduction: Double
    /// false = 参考値（自社で実測・確認していない）
    var verified: Bool

    func matches(material m: String, thickness t: Double) -> Bool {
        guard abs(thickness - t) < 0.01 else { return false }
        let target = m.uppercased().replacingOccurrences(of: " ", with: "")
        guard !target.isEmpty else { return false }
        return material.uppercased()
            .split(separator: "/")
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .contains { !$0.isEmpty && target.contains($0) }
    }

    /// 一般的な参考値（V幅 約6〜8t のエアベンド想定）。必ず自社の実測値に置き換えること
    static let references: [BendEntry] = [
        .init(material: "SPCC/SPHC/SS400/SECC", thickness: 1.0, deduction: 1.7, verified: false),
        .init(material: "SPCC/SPHC/SS400/SECC", thickness: 1.2, deduction: 2.0, verified: false),
        .init(material: "SPCC/SPHC/SS400/SECC", thickness: 1.6, deduction: 2.7, verified: false),
        .init(material: "SPCC/SPHC/SS400/SECC", thickness: 2.3, deduction: 3.9, verified: false),
        .init(material: "SPCC/SPHC/SS400/SECC", thickness: 3.2, deduction: 5.4, verified: false),
        .init(material: "SUS", thickness: 1.0, deduction: 1.9, verified: false),
        .init(material: "SUS", thickness: 1.5, deduction: 2.7, verified: false),
        .init(material: "SUS", thickness: 2.0, deduction: 3.6, verified: false),
        .init(material: "SUS", thickness: 3.0, deduction: 5.3, verified: false),
    ]
}

/// タップ下穴表
struct TapEntry: Codable, Hashable, Identifiable {
    var id = UUID()
    var size: String
    var drill: Double

    static let defaults: [TapEntry] = [
        .init(size: "M2", drill: 1.6),
        .init(size: "M2.5", drill: 2.05),
        .init(size: "M3", drill: 2.5),
        .init(size: "M4", drill: 3.3),
        .init(size: "M5", drill: 4.2),
        .init(size: "M6", drill: 5.0),
        .init(size: "M8", drill: 6.8),
        .init(size: "M10", drill: 8.5),
        .init(size: "M12", drill: 10.2),
    ]
}

struct SettingsData: Codable {
    var model: String = "claude-opus-5-5"
    var kFactor: Double = 0.4
    var innerRadiusRatio: Double = 1.0
    var bendTable: [BendEntry] = []
    var tapTable: [TapEntry] = TapEntry.defaults
    var exportBendLines: Bool = false
    var exportMarks: Bool = true
    var exportText: Bool = false
}

/// 計算に使う設定値（View から切り離して渡す）
struct CalcConfig {
    var bendTable: [BendEntry]
    var tapTable: [TapEntry]
    var kFactor: Double
    var innerRadiusRatio: Double

    func tapDrill(_ size: String) -> Double? {
        let key = CalcConfig.normalizeTap(size)
        guard !key.isEmpty else { return nil }
        return tapTable.first { CalcConfig.normalizeTap($0.size) == key }?.drill
    }

    /// "M5×0.8" "m5" "M5タップ" → "M5"
    static func normalizeTap(_ s: String) -> String {
        var t = s.uppercased()
            .replacingOccurrences(of: " ", with: "")
            .replacingOccurrences(of: "Ｍ", with: "M")
        if let r = t.range(of: "×") { t = String(t[..<r.lowerBound]) }
        if let r = t.range(of: "X") { t = String(t[..<r.lowerBound]) }
        let allowed = Set("M0123456789.")
        return String(t.filter { allowed.contains($0) })
    }
}

@Observable
final class AppSettings {
    var data: SettingsData

    private static let defaultsKey = "settings.v1"

    init() {
        if let raw = UserDefaults.standard.data(forKey: AppSettings.defaultsKey),
           let d = try? JSONDecoder().decode(SettingsData.self, from: raw) {
            data = d
        } else {
            data = SettingsData()
        }
    }

    func save() {
        if let raw = try? JSONEncoder().encode(data) {
            UserDefaults.standard.set(raw, forKey: AppSettings.defaultsKey)
        }
    }

    var config: CalcConfig {
        CalcConfig(bendTable: data.bendTable, tapTable: data.tapTable,
                   kFactor: data.kFactor, innerRadiusRatio: data.innerRadiusRatio)
    }

    var apiKey: String {
        get { KeychainHelper.read("claude-api-key") ?? "" }
        set { KeychainHelper.save("claude-api-key", newValue) }
    }
}
