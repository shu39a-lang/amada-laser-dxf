import Foundation

// MARK: - 読み取り値の確からしさ

/// high = 図面に明記 / low = AI推定（要確認） / missing = 図面に無い（要入力） / user = 作業者が入力・確認済み
enum Confidence: String, Codable, CaseIterable {
    case high, low, missing, user

    init(from decoder: Decoder) throws {
        let s = (try? decoder.singleValueContainer().decode(String.self)) ?? "low"
        self = Confidence(rawValue: s.lowercased()) ?? .low
    }
}

/// 数値＋確からしさ＋根拠メモ
struct Val: Codable, Hashable {
    var value: Double?
    var confidence: Confidence
    var note: String?

    init(_ value: Double?, _ confidence: Confidence? = nil, note: String? = nil) {
        self.value = value
        if value == nil {
            self.confidence = .missing
        } else if let confidence, confidence != .missing {
            self.confidence = confidence
        } else {
            self.confidence = confidence == .missing ? .low : .high
        }
        self.note = note
    }

    static var missing: Val { Val(nil, .missing) }

    var isMissing: Bool { value == nil }
    var number: Double { value ?? 0 }

    enum CodingKeys: String, CodingKey { case value, confidence, note }

    init(from decoder: Decoder) throws {
        if let single = try? decoder.singleValueContainer() {
            if single.decodeNil() { self.init(nil); return }
            if let d = try? single.decode(Double.self) { self.init(d, .high); return }
            if let s = try? single.decode(String.self) { self.init(Double(s), .low); return }
        }
        let c = try decoder.container(keyedBy: CodingKeys.self)
        var v = try? c.decodeIfPresent(Double.self, forKey: .value)
        if v == nil, let s = try? c.decodeIfPresent(String.self, forKey: .value) { v = Double(s) }
        let conf = try? c.decodeIfPresent(Confidence.self, forKey: .confidence)
        let note = try? c.decodeIfPresent(String.self, forKey: .note)
        self.init(v, conf, note: note)
    }
}

/// 配列の一部が壊れていても残りを読み込むためのラッパー
struct Lossy<T: Decodable>: Decodable {
    let value: T?
    init(from decoder: Decoder) throws { value = try? T(from: decoder) }
}

extension KeyedDecodingContainer {
    func val(_ key: Key) -> Val { (try? decodeIfPresent(Val.self, forKey: key)) ?? .missing }
    func str(_ key: Key) -> String { (try? decodeIfPresent(String.self, forKey: key)) ?? "" }
    func int(_ key: Key, _ def: Int = 0) -> Int {
        if let i = try? decodeIfPresent(Int.self, forKey: key) { return i }
        if let d = try? decodeIfPresent(Double.self, forKey: key) { return Int(d) }
        return def
    }
    func list<T: Decodable>(_ type: T.Type, _ key: Key) -> [T] {
        let items = (try? decodeIfPresent([Lossy<T>].self, forKey: key)) ?? []
        return items.compactMap { $0.value }
    }
}

// MARK: - 区分

enum PartProcess: String, Codable, CaseIterable, Identifiable {
    case laser, lathe, purchased, other
    var id: String { rawValue }
    var label: String {
        switch self {
        case .laser: return "レーザー"
        case .lathe: return "旋盤・切削"
        case .purchased: return "購入品"
        case .other: return "その他"
        }
    }
    init(from decoder: Decoder) throws {
        let s = (try? decoder.singleValueContainer().decode(String.self)) ?? ""
        self = PartProcess(rawValue: s.lowercased()) ?? .other
    }
}

enum OutlineKind: String, Codable, CaseIterable, Identifiable {
    case rect, polygon
    var id: String { rawValue }
    init(from decoder: Decoder) throws {
        let s = (try? decoder.singleValueContainer().decode(String.self)) ?? ""
        self = OutlineKind(rawValue: s.lowercased()) ?? .rect
    }
}

enum CornerType: String, Codable, CaseIterable, Identifiable {
    case none, radius, chamfer
    var id: String { rawValue }
    var label: String {
        switch self {
        case .none: return "角"
        case .radius: return "R"
        case .chamfer: return "C"
        }
    }
    init(from decoder: Decoder) throws {
        let s = (try? decoder.singleValueContainer().decode(String.self)) ?? ""
        self = CornerType(rawValue: s.lowercased()) ?? .none
    }
}

enum FeatureKind: String, Codable, CaseIterable, Identifiable {
    case circle, tap, countersink, slot, rect, polygon
    var id: String { rawValue }
    var label: String {
        switch self {
        case .circle: return "丸穴"
        case .tap: return "タップ穴"
        case .countersink: return "皿穴"
        case .slot: return "長穴"
        case .rect: return "角穴"
        case .polygon: return "多角形穴"
        }
    }
    init(from decoder: Decoder) throws {
        let s = (try? decoder.singleValueContainer().decode(String.self)) ?? ""
        self = FeatureKind(rawValue: s.lowercased()) ?? .circle
    }
}

// MARK: - 形状要素

struct Corner: Codable, Hashable {
    var type: CornerType = .none
    var size: Val = .missing

    enum CodingKeys: String, CodingKey { case type, size }
    init(type: CornerType = .none, size: Val = .missing) { self.type = type; self.size = size }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        type = (try? c.decodeIfPresent(CornerType.self, forKey: .type)) ?? .none
        size = c.val(.size)
    }
}

struct Corners: Codable, Hashable {
    var bl = Corner(), br = Corner(), tr = Corner(), tl = Corner()
    enum CodingKeys: String, CodingKey { case bl, br, tr, tl }
    init() {}
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        bl = (try? c.decodeIfPresent(Corner.self, forKey: .bl)) ?? Corner()
        br = (try? c.decodeIfPresent(Corner.self, forKey: .br)) ?? Corner()
        tr = (try? c.decodeIfPresent(Corner.self, forKey: .tr)) ?? Corner()
        tl = (try? c.decodeIfPresent(Corner.self, forKey: .tl)) ?? Corner()
    }
}

struct PolyPoint: Codable, Hashable, Identifiable {
    var id = UUID()
    var x: Val = .missing
    var y: Val = .missing
    var corner = Corner()

    enum CodingKeys: String, CodingKey { case x, y, corner }
    init(x: Val = .missing, y: Val = .missing, corner: Corner = Corner()) { self.x = x; self.y = y; self.corner = corner }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        x = c.val(.x); y = c.val(.y)
        corner = (try? c.decodeIfPresent(Corner.self, forKey: .corner)) ?? Corner()
    }
}

/// 曲げ方向に並んだ「面」。length は外寸。bendAngle は次の面との曲げ角（直角=90）。
struct Segment: Codable, Hashable, Identifiable {
    var id = UUID()
    var length: Val = .missing
    var bendAngle: Val = .missing
    /// 作業者が手入力した曲げ控除値（未入力なら控除表から自動）
    var deduction: Val = .missing

    enum CodingKeys: String, CodingKey { case length, bendAngle, deduction }
    init(length: Val = .missing, bendAngle: Val = .missing) { self.length = length; self.bendAngle = bendAngle }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        length = c.val(.length); bendAngle = c.val(.bendAngle); deduction = c.val(.deduction)
    }
}

struct Outline: Codable, Hashable {
    var kind: OutlineKind = .rect
    var profileX: [Segment] = [Segment()]
    var height: Val = .missing
    var corners = Corners()
    var points: [PolyPoint] = []

    enum CodingKeys: String, CodingKey { case kind, profileX, height, corners, points }
    init() {}
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        kind = (try? c.decodeIfPresent(OutlineKind.self, forKey: .kind)) ?? .rect
        profileX = c.list(Segment.self, .profileX)
        if profileX.isEmpty { profileX = [Segment()] }
        height = c.val(.height)
        corners = (try? c.decodeIfPresent(Corners.self, forKey: .corners)) ?? Corners()
        points = c.list(PolyPoint.self, .points)
    }
}

struct Feature: Codable, Hashable, Identifiable {
    var id = UUID()
    var kind: FeatureKind = .circle
    var segment: Int = 0
    var x: Val = .missing
    var y: Val = .missing
    var diameter: Val = .missing
    var tapSize: String = ""
    var length: Val = .missing
    var width: Val = .missing
    var angle: Val = .missing
    var cornerRadius: Val = .missing
    var points: [PolyPoint] = []
    var note: String = ""

    enum CodingKeys: String, CodingKey {
        case kind, segment, x, y, diameter, tapSize, length, width, angle, cornerRadius, points, note
    }
    init(kind: FeatureKind = .circle) { self.kind = kind }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        kind = (try? c.decodeIfPresent(FeatureKind.self, forKey: .kind)) ?? .circle
        segment = c.int(.segment)
        x = c.val(.x); y = c.val(.y)
        diameter = c.val(.diameter)
        tapSize = c.str(.tapSize)
        length = c.val(.length); width = c.val(.width)
        angle = c.val(.angle); cornerRadius = c.val(.cornerRadius)
        points = c.list(PolyPoint.self, .points)
        note = c.str(.note)
    }
}

struct Mark: Codable, Hashable, Identifiable {
    var id = UUID()
    var segment: Int = 0
    var x1: Val = .missing, y1: Val = .missing, x2: Val = .missing, y2: Val = .missing
    var note: String = ""

    enum CodingKeys: String, CodingKey { case segment, x1, y1, x2, y2, note }
    init() {}
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        segment = c.int(.segment)
        x1 = c.val(.x1); y1 = c.val(.y1); x2 = c.val(.x2); y2 = c.val(.y2)
        note = c.str(.note)
    }
}

// MARK: - 部品・図面

struct Part: Codable, Hashable, Identifiable {
    var id = UUID()
    var name: String = "新しい部品"
    var process: PartProcess = .laser
    var quantity: Val = Val(1, .user)
    var material: String = ""
    var thickness: Val = .missing
    var outline = Outline()
    var features: [Feature] = []
    var marks: [Mark] = []
    var notes: [String] = []
    var questions: [String] = []

    enum CodingKeys: String, CodingKey {
        case name, process, quantity, material, thickness, outline, features, marks, notes, questions
    }
    init() {}
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        name = c.str(.name)
        if name.isEmpty { name = "部品" }
        process = (try? c.decodeIfPresent(PartProcess.self, forKey: .process)) ?? .other
        quantity = c.val(.quantity)
        material = c.str(.material)
        thickness = c.val(.thickness)
        outline = (try? c.decodeIfPresent(Outline.self, forKey: .outline)) ?? Outline()
        features = c.list(Feature.self, .features)
        marks = c.list(Mark.self, .marks)
        notes = c.list(String.self, .notes)
        questions = c.list(String.self, .questions)
    }

    /// AI推定（黄色）の値をすべて「確認済み」にする
    mutating func confirmAllLow() {
        guard let data = try? JSONEncoder().encode(self),
              let obj = try? JSONSerialization.jsonObject(with: data) else { return }
        let replaced = Part.replaceLow(obj)
        guard let newData = try? JSONSerialization.data(withJSONObject: replaced),
              var newPart = try? JSONDecoder().decode(Part.self, from: newData) else { return }
        newPart.id = id
        self = newPart
    }

    private static func replaceLow(_ obj: Any) -> Any {
        if var dict = obj as? [String: Any] {
            for (k, v) in dict {
                if k == "confidence", let s = v as? String, s == Confidence.low.rawValue {
                    dict[k] = Confidence.user.rawValue
                } else {
                    dict[k] = replaceLow(v)
                }
            }
            return dict
        }
        if let arr = obj as? [Any] { return arr.map { replaceLow($0) } }
        return obj
    }
}

struct DrawingInfo: Codable, Hashable {
    var title: String = ""
    var drawingNumber: String = ""
    var material: String = ""
    var notes: [String] = []

    enum CodingKeys: String, CodingKey { case title, drawingNumber, material, notes }
    init() {}
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        title = c.str(.title); drawingNumber = c.str(.drawingNumber)
        material = c.str(.material); notes = c.list(String.self, .notes)
    }
}

struct Analysis: Codable, Hashable {
    var drawing = DrawingInfo()
    var questions: [String] = []
    var parts: [Part] = []

    enum CodingKeys: String, CodingKey { case drawing, questions, parts }
    init() {}
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        drawing = (try? c.decodeIfPresent(DrawingInfo.self, forKey: .drawing)) ?? DrawingInfo()
        questions = c.list(String.self, .questions)
        parts = c.list(Part.self, .parts)
    }
}

struct Job: Codable, Hashable, Identifiable {
    var id = UUID()
    var createdAt = Date()
    var imageFile: String = ""
    var hint: String = ""
    var analysis = Analysis()

    var title: String {
        let t = analysis.drawing.title.isEmpty ? "図面" : analysis.drawing.title
        return analysis.drawing.drawingNumber.isEmpty ? t : "\(t)（\(analysis.drawing.drawingNumber)）"
    }

    static let placeholder = Job()
}
