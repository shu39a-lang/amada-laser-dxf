import Foundation

// MARK: - 幾何の基本

struct P: Hashable {
    var x: Double
    var y: Double
    static func + (a: P, b: P) -> P { P(x: a.x + b.x, y: a.y + b.y) }
    static func - (a: P, b: P) -> P { P(x: a.x - b.x, y: a.y - b.y) }
    static func * (a: P, s: Double) -> P { P(x: a.x * s, y: a.y * s) }
    var length: Double { (x * x + y * y).squareRoot() }
    var normalized: P { let l = length; return l > 1e-9 ? P(x: x / l, y: y / l) : P(x: 0, y: 0) }
    func dot(_ o: P) -> Double { x * o.x + y * o.y }
    func cross(_ o: P) -> Double { x * o.y - y * o.x }
    func rotated(_ deg: Double) -> P {
        let r = deg * .pi / 180
        return P(x: x * cos(r) - y * sin(r), y: x * sin(r) + y * cos(r))
    }
    var angleDeg: Double {
        var a = atan2(y, x) * 180 / .pi
        if a < 0 { a += 360 }
        return a
    }
}

enum Layer: String, CaseIterable, Identifiable {
    case outer = "CUT_OUTER"
    case inner = "CUT_INNER"
    case bend = "BEND"
    case mark = "MARK"
    case text = "TEXT"
    var id: String { rawValue }

    /// DXF の色番号（ACI）
    var aci: Int {
        switch self {
        case .outer: return 7
        case .inner: return 1
        case .bend: return 3
        case .mark: return 4
        case .text: return 2
        }
    }
    var label: String {
        switch self {
        case .outer: return "外形カット"
        case .inner: return "穴カット"
        case .bend: return "曲げ線"
        case .mark: return "けがき"
        case .text: return "文字"
        }
    }
}

enum Entity {
    case line(P, P, Layer)
    /// 中心・半径・開始角・終了角（度、反時計回り）
    case arc(P, Double, Double, Double, Layer)
    case circle(P, Double, Layer)
    case text(P, Double, String, Layer)

    var layer: Layer {
        switch self {
        case .line(_, _, let l), .arc(_, _, _, _, let l), .circle(_, _, let l), .text(_, _, _, let l): return l
        }
    }
}

struct FlatPattern {
    var entities: [Entity] = []
    var width: Double = 0
    var height: Double = 0

    /// 表示用の範囲
    var bounds: (minX: Double, minY: Double, maxX: Double, maxY: Double) {
        var minX = Double.infinity, minY = Double.infinity, maxX = -Double.infinity, maxY = -Double.infinity
        func add(_ p: P) {
            minX = min(minX, p.x); minY = min(minY, p.y)
            maxX = max(maxX, p.x); maxY = max(maxY, p.y)
        }
        for e in entities {
            switch e {
            case .line(let a, let b, _): add(a); add(b)
            case .arc(let c, let r, _, _, _), .circle(let c, let r, _):
                add(P(x: c.x - r, y: c.y - r)); add(P(x: c.x + r, y: c.y + r))
            case .text(let p, _, _, _): add(p)
            }
        }
        if minX == .infinity { return (0, 0, 1, 1) }
        return (minX, minY, maxX, maxY)
    }
}

// MARK: - 曲げ控除

enum DeductionSource: Equatable {
    case user
    case table(verified: Bool)
    case formula
    case unavailable
}

struct BendCalc {
    let config: CalcConfig

    /// 計算式による控除値（外寸基準）。D = 2·(r+t)·tan(θ/2) − θ·(r + k·t)
    func formula(thickness t: Double, angle: Double) -> Double? {
        guard t > 0, angle > 0, angle < 170 else { return nil }
        let r = config.innerRadiusRatio * t
        let a = angle * .pi / 180
        let ossb = (r + t) * tan(a / 2)
        let ba = a * (r + config.kFactor * t)
        return 2 * ossb - ba
    }

    func deduction(part: Part, segment: Segment) -> (value: Double?, source: DeductionSource) {
        if let v = segment.deduction.value { return (v, .user) }
        guard let t = part.thickness.value, let angle = segment.bendAngle.value else { return (nil, .unavailable) }
        if abs(angle) < 0.001 { return (0, .formula) }
        if abs(angle - 90) < 0.01 {
            let material = part.material.isEmpty ? "" : part.material
            if let e = config.bendTable.first(where: { $0.matches(material: material, thickness: t) }) {
                return (e.deduction, .table(verified: e.verified))
            }
            return (nil, .unavailable)
        }
        if let f = formula(thickness: t, angle: angle) { return (f, .formula) }
        return (nil, .unavailable)
    }
}

// MARK: - チェック

struct Issue: Identifiable {
    enum Severity { case error, warning }
    let id = UUID()
    let severity: Severity
    let message: String
}

enum Validator {
    static func issues(_ p: Part, _ c: CalcConfig) -> [Issue] {
        guard p.process == .laser else { return [] }
        var out: [Issue] = []
        func check(_ v: Val, _ label: String, required: Bool = true) {
            if v.value == nil {
                if required { out.append(Issue(severity: .error, message: "\(label)が未入力")) }
            } else if v.confidence == .low {
                out.append(Issue(severity: .warning, message: "\(label)を確認（AI推定）"))
            }
        }
        func checkCorner(_ corner: Corner, _ label: String) {
            if corner.type != .none { check(corner.size, "\(label)の\(corner.type.label)寸法") }
        }

        check(p.thickness, "板厚")
        check(p.quantity, "数量")
        if p.material.trimmingCharacters(in: .whitespaces).isEmpty {
            out.append(Issue(severity: .warning, message: "材質が未入力"))
        }

        switch p.outline.kind {
        case .rect:
            let segs = p.outline.profileX
            if segs.isEmpty { out.append(Issue(severity: .error, message: "外形の寸法がありません")) }
            let calc = BendCalc(config: c)
            for (i, s) in segs.enumerated() {
                check(s.length, segs.count > 1 ? "面\(i + 1)の外寸" : "幅")
                if i < segs.count - 1 {
                    check(s.bendAngle, "曲げ\(i + 1)の角度")
                    let r = calc.deduction(part: p, segment: s)
                    switch r.source {
                    case .unavailable:
                        if s.bendAngle.value != nil && p.thickness.value != nil {
                            out.append(Issue(severity: .error,
                                             message: "曲げ\(i + 1)の控除値が未登録（控除表に登録するか手入力）"))
                        }
                    case .formula:
                        out.append(Issue(severity: .warning, message: "曲げ\(i + 1)の控除値は計算値（要確認）"))
                    case .table(let verified):
                        if !verified {
                            out.append(Issue(severity: .warning, message: "曲げ\(i + 1)の控除値は参考値（実測値に更新推奨）"))
                        }
                    case .user:
                        if s.deduction.confidence == .low {
                            out.append(Issue(severity: .warning, message: "曲げ\(i + 1)の控除値を確認"))
                        }
                    }
                }
            }
            check(p.outline.height, segs.count > 1 ? "曲げ線方向の長さ" : "高さ")
            checkCorner(p.outline.corners.bl, "左下の角")
            checkCorner(p.outline.corners.br, "右下の角")
            checkCorner(p.outline.corners.tr, "右上の角")
            checkCorner(p.outline.corners.tl, "左上の角")
        case .polygon:
            if p.outline.points.count < 3 {
                out.append(Issue(severity: .error, message: "外形の頂点が3点未満です"))
            }
            for (i, pt) in p.outline.points.enumerated() {
                check(pt.x, "頂点\(i + 1)のX"); check(pt.y, "頂点\(i + 1)のY")
                checkCorner(pt.corner, "頂点\(i + 1)")
            }
        }

        for (i, f) in p.features.enumerated() {
            let n = "穴\(i + 1)（\(f.kind.label)）"
            check(f.x, "\(n)のX"); check(f.y, "\(n)のY")
            switch f.kind {
            case .circle, .countersink:
                check(f.diameter, "\(n)の径")
            case .tap:
                if c.tapDrill(f.tapSize) == nil {
                    out.append(Issue(severity: .error, message: "\(n)のタップ呼び「\(f.tapSize)」が下穴表にありません"))
                }
            case .slot:
                check(f.length, "\(n)の全長"); check(f.width, "\(n)の幅")
                check(f.angle, "\(n)の角度", required: false)
            case .rect:
                check(f.length, "\(n)のX寸法"); check(f.width, "\(n)のY寸法")
                check(f.cornerRadius, "\(n)の角R", required: false)
                check(f.angle, "\(n)の角度", required: false)
            case .polygon:
                if f.points.count < 3 { out.append(Issue(severity: .error, message: "\(n)の頂点が3点未満です")) }
                for (j, pt) in f.points.enumerated() {
                    check(pt.x, "\(n)の頂点\(j + 1)X"); check(pt.y, "\(n)の頂点\(j + 1)Y")
                }
            }
            if f.segment >= p.outline.profileX.count && p.outline.kind == .rect {
                out.append(Issue(severity: .error, message: "\(n)の基準面が存在しません"))
            }
        }
        for (i, m) in p.marks.enumerated() {
            let n = "けがき\(i + 1)"
            check(m.x1, "\(n)の始点X"); check(m.y1, "\(n)の始点Y")
            check(m.x2, "\(n)の終点X"); check(m.y2, "\(n)の終点Y")
        }
        return out
    }

    static func errorCount(_ p: Part, _ c: CalcConfig) -> Int {
        issues(p, c).filter { $0.severity == .error }.count
    }
}

// MARK: - 展開図の生成

enum FlatBuilder {

    static func build(_ part: Part, config: CalcConfig) -> FlatPattern {
        var fp = FlatPattern()
        let calc = BendCalc(config: config)
        var segStarts: [Double] = [0]

        switch part.outline.kind {
        case .rect:
            let segs = part.outline.profileX
            var deductions: [Double] = []
            for (i, s) in segs.enumerated() where i < segs.count - 1 {
                deductions.append(calc.deduction(part: part, segment: s).value ?? 0)
            }
            segStarts = []
            var pos = 0.0
            for (i, s) in segs.enumerated() {
                segStarts.append(pos)
                pos += s.length.number
                if i < deductions.count { pos -= deductions[i] }
            }
            let w = pos
            let h = part.outline.height.number
            fp.width = w; fp.height = h

            let c = part.outline.corners
            let pts = [P(x: 0, y: 0), P(x: w, y: 0), P(x: w, y: h), P(x: 0, y: h)]
            fp.entities += polygon(pts, corners: [c.bl, c.br, c.tr, c.tl], layer: .outer)

            // 曲げ線（控除値の中央に近似）
            var acc = 0.0
            for i in 0..<deductions.count {
                acc += segs[i].length.number
                let x = acc - deductions[0..<i].reduce(0, +) - deductions[i] / 2
                fp.entities.append(.line(P(x: x, y: 0), P(x: x, y: h), .bend))
            }

        case .polygon:
            let pts = part.outline.points.map { P(x: $0.x.number, y: $0.y.number) }
            if pts.count >= 3 {
                fp.entities += polygon(pts, corners: part.outline.points.map { $0.corner }, layer: .outer)
                fp.width = (pts.map(\.x).max() ?? 0) - (pts.map(\.x).min() ?? 0)
                fp.height = (pts.map(\.y).max() ?? 0) - (pts.map(\.y).min() ?? 0)
            }
        }

        func origin(_ seg: Int) -> Double {
            guard !segStarts.isEmpty else { return 0 }
            return segStarts[min(max(seg, 0), segStarts.count - 1)]
        }

        for f in part.features {
            let center = P(x: origin(f.segment) + f.x.number, y: f.y.number)
            fp.entities += feature(f, at: center, config: config)
        }

        for m in part.marks {
            let o = origin(m.segment)
            fp.entities.append(.line(P(x: o + m.x1.number, y: m.y1.number),
                                     P(x: o + m.x2.number, y: m.y2.number), .mark))
        }

        let label = "\(part.name) \(part.material) t\(fmt(part.thickness.number)) \(Int(part.quantity.number))個"
        fp.entities.append(.text(P(x: 0, y: fp.height + 5), 5, label, .text))
        return fp
    }

    static func fmt(_ v: Double) -> String {
        v == v.rounded() ? String(Int(v)) : String(format: "%.2f", v)
    }

    // 穴
    static func feature(_ f: Feature, at c: P, config: CalcConfig) -> [Entity] {
        switch f.kind {
        case .circle, .countersink:
            let d = f.diameter.number
            return d > 0 ? [.circle(c, d / 2, .inner)] : []
        case .tap:
            guard let d = config.tapDrill(f.tapSize) else { return [] }
            return [.circle(c, d / 2, .inner)]
        case .slot:
            return slot(center: c, length: f.length.number, width: f.width.number, angle: f.angle.number)
        case .rect:
            let w = f.length.number, h = f.width.number
            guard w > 0, h > 0 else { return [] }
            let local = [P(x: -w / 2, y: -h / 2), P(x: w / 2, y: -h / 2), P(x: w / 2, y: h / 2), P(x: -w / 2, y: h / 2)]
            let pts = local.map { c + $0.rotated(f.angle.number) }
            let r = f.cornerRadius.number
            let corner = r > 0 ? Corner(type: .radius, size: Val(r)) : Corner()
            return polygon(pts, corners: Array(repeating: corner, count: 4), layer: .inner)
        case .polygon:
            let pts = f.points.map { c + P(x: $0.x.number, y: $0.y.number).rotated(f.angle.number) }
            guard pts.count >= 3 else { return [] }
            return polygon(pts, corners: f.points.map { $0.corner }, layer: .inner)
        }
    }

    static func slot(center c: P, length: Double, width: Double, angle: Double) -> [Entity] {
        guard width > 0 else { return [] }
        let r = width / 2
        if length <= width { return [.circle(c, r, .inner)] }
        let half = (length - width) / 2
        let dir = P(x: 1, y: 0).rotated(angle)
        let n = P(x: -dir.y, y: dir.x)
        let c1 = c + dir * half, c2 = c - dir * half
        let a = dir.angleDeg
        return [
            .arc(c1, r, norm(a - 90), norm(a + 90), .inner),
            .line(c1 + n * r, c2 + n * r, .inner),
            .arc(c2, r, norm(a + 90), norm(a + 270), .inner),
            .line(c2 - n * r, c1 - n * r, .inner),
        ]
    }

    static func norm(_ a: Double) -> Double {
        var v = a.truncatingRemainder(dividingBy: 360)
        if v < 0 { v += 360 }
        return v
    }

    /// 角R・C付きの閉じた多角形
    static func polygon(_ pts: [P], corners: [Corner], layer: Layer) -> [Entity] {
        let n = pts.count
        guard n >= 3 else { return [] }
        var inPts = pts, outPts = pts   // 各頂点の「手前側の接点」と「先側の接点」
        var cornerEntities: [Entity?] = Array(repeating: nil, count: n)

        for i in 0..<n {
            let corner = i < corners.count ? corners[i] : Corner()
            let size = corner.size.number
            guard corner.type != .none, size > 0 else { continue }
            let p = pts[i], prev = pts[(i - 1 + n) % n], next = pts[(i + 1) % n]
            let u1 = (prev - p).normalized, u2 = (next - p).normalized
            let cosT = max(-1, min(1, u1.dot(u2)))
            let theta = acos(cosT)
            guard theta > 0.01, theta < .pi - 0.01 else { continue }
            let maxD = min((prev - p).length, (next - p).length) / 2

            if corner.type == .radius {
                let d = min(size / tan(theta / 2), maxD)
                let r = d * tan(theta / 2)
                let t1 = p + u1 * d, t2 = p + u2 * d
                let bis = (u1 + u2).normalized
                let center = p + bis * (r / sin(theta / 2))
                inPts[i] = t1; outPts[i] = t2
                let v1 = t1 - center, v2 = t2 - center
                if v1.cross(v2) > 0 {
                    cornerEntities[i] = .arc(center, r, v1.angleDeg, v2.angleDeg, layer)
                } else {
                    cornerEntities[i] = .arc(center, r, v2.angleDeg, v1.angleDeg, layer)
                }
            } else {
                let d = min(size, maxD)
                let t1 = p + u1 * d, t2 = p + u2 * d
                inPts[i] = t1; outPts[i] = t2
                cornerEntities[i] = .line(t1, t2, layer)
            }
        }

        var result: [Entity] = []
        for i in 0..<n {
            if let ce = cornerEntities[i] { result.append(ce) }
            let a = outPts[i], b = inPts[(i + 1) % n]
            if (b - a).length > 1e-6 { result.append(.line(a, b, layer)) }
        }
        return result
    }
}
