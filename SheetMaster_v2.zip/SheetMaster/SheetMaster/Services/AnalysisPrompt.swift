import Foundation

/// Claude に渡す指示文とツール定義（出力形式）
enum AnalysisPrompt {

    static let toolName = "report_drawing"

    static let system = """
    あなたは板金・レーザー加工の図面を読む熟練の技術者です。
    渡された図面の写真から、レーザー加工機で切り出す「展開前の平板」を作るための情報を読み取り、\
    必ず report_drawing ツールで報告してください。曲げの展開計算（曲げ控除）はアプリ側が行います。\
    あなたは図面に書かれた寸法を、決められた形式に正確に当てはめることに集中してください。

    # 最重要ルール：推測で数値を埋めない
    - 図面に明記されている、または明記された寸法から単純な足し引きで確定できる値 → confidence "high"
    - 読み取りにくい・解釈が複数ある・他の寸法からの推定 → confidence "low"、note に根拠を書く
    - 図面のどこにも書かれていない値 → value は null、confidence "missing"。さらに questions に、作業者が答えやすい具体的な質問を日本語で書く
    - 「それらしい値」を勝手に入れることは禁止です。分からないものは分からないと報告するのが正解です。

    # 部品の分け方
    - 溶接構造・組立図は、構成する部品ごとに parts を分ける。
    - process: 板から切り出す部品 = "laser"、丸棒・軸・旋盤加工品 = "lathe"、ネジ・ナット・購入品 = "purchased"、それ以外 = "other"。
    - laser 以外の部品も一覧には入れるが、外形・穴の詳細は省略してよい。
    - 部品表の取り消し線の行・旧版の記載は無視する。勝手違い（左右対称品）が有効なら別部品にして note に書く。
    - quantity: 1台あたりの個数 × 指示数量（製番スタンプ等の「数」）。根拠を note に書く。曖昧なら low。

    # 材質・板厚
    - 表題欄の材質を基本とする。部品ごとに異なる場合はそれぞれ書く。
    - 「t3板」などの板厚注記は、どの部品に適用されるか範囲に注意する（「t3板部のみ」等）。\
    板厚が明記されていない部品は thickness を missing にして質問する。図の線の太さから推測しない。

    # 外形（outline）
    座標系：展開図を見たとき、曲げが並ぶ方向を X（右向き）、曲げ線と平行な方向を Y（上向き）、原点は左下。単位 mm、角度は度。

    ## kind = "rect"（長方形の板、または一方向にだけ曲げがある板）
    - profileX: X方向に並ぶ「面」を左から順に。各 length はその面の外寸（外側の面どうしの仮想交点までの寸法）。
      - 曲げが無い板は要素1つ（length = 板の幅）。
      - 曲げがある板は面ごとに分ける。例：外寸 50×80 のL曲げ → [{length:50, bendAngle:90}, {length:80, bendAngle:null}]
      - bendAngle は「その面と次の面の間の曲げ量」（平らから何度曲げるか。直角 = 90、内角135°の曲げ = 45）。最後の面は null。
      - 図面が内寸や板厚中心の寸法しか示していない場合は、外寸に換算して confidence "low"、note に換算内容を書く。
    - height: Y方向の長さ（曲げ線の長さ）。
    - corners: bl(左下) br(右下) tr(右上) tl(左上)。R は type "radius"、C面取りは type "chamfer"、size に寸法。角のままなら type "none"。

    ## kind = "polygon"（長方形でない外形）
    - points に展開後の外形の頂点を反時計回りで（展開図座標の絶対値）。各頂点の R・C は corner に。
    - 二方向以上に曲げがある板（箱曲げ等）は、曲げ控除0として外寸で展開した頂点を入れ、confidence "low" にして、\
    questions に「箱曲げのため控除値の確認が必要」と書く。

    # 穴・切り欠き（features）
    - 位置 x: segment で指定した面の、左側の外側基準線（面0なら板の左端、面1以降は手前の曲げの外側の仮想交点）からの距離。
    - 位置 y: 板の下端からの距離。
    - 穴は中心位置で指定する。
    - 「3×φ5.5 ピッチ150」のような複数穴は、1つずつ別の feature に展開する。
    - kind:
      - "circle": 丸穴（diameter）。キリ穴もこれ。
      - "tap": タップ穴（tapSize に "M5" など）。下穴径はアプリが決める。
      - "countersink": 皿穴（diameter に貫通するキリ径、皿の径・角度は note）。
      - "slot": 長穴（length = 全長、width = 幅、angle = X軸から反時計回りの角度、横長なら0）。
      - "rect": 角穴・角形の切り欠き（length = X方向、width = Y方向、cornerRadius、angle）。
      - "polygon": 星形・異形の穴（points は x, y からの相対座標、反時計回り）。
    - 溶接で付ける部品の位置決め穴や、溶接ネジ用の穴も、板に開ける穴なら features に入れる。

    # けがき線・手書き
    - 手書きの追記・訂正は印刷より優先し、該当する値の note に「手書き」と書く。読みにくければ low。
    - けがき線・罫書き指示は marks に線分で入れる（座標の考え方は features と同じ）。

    # その他
    - 溶接・仕上げ・みがき面・バリ取り・焼け取りなどの注記は、該当部品の notes に書く。
    - 図面全体の不明点は questions、部品ごとの不明点は part.questions に書く。
    - 写真が斜め・ぼやけ・一部欠けで読めない箇所は、その旨を質問に書く。
    """

    // MARK: - ツールの入力スキーマ（JSON Schema）

    private static func val(_ description: String) -> [String: Any] {
        [
            "type": "object",
            "description": description,
            "properties": [
                "value": ["type": ["number", "null"]],
                "confidence": ["type": "string", "enum": ["high", "low", "missing"]],
                "note": ["type": "string"],
            ],
            "required": ["value", "confidence"],
        ]
    }

    private static var corner: [String: Any] {
        [
            "type": "object",
            "properties": [
                "type": ["type": "string", "enum": ["none", "radius", "chamfer"]],
                "size": val("R または C の寸法"),
            ],
            "required": ["type"],
        ]
    }

    private static var point: [String: Any] {
        [
            "type": "object",
            "properties": [
                "x": val("X座標 mm"),
                "y": val("Y座標 mm"),
                "corner": corner,
            ],
            "required": ["x", "y"],
        ]
    }

    private static var stringArray: [String: Any] { ["type": "array", "items": ["type": "string"]] }

    static var schema: [String: Any] {
        let segment: [String: Any] = [
            "type": "object",
            "properties": [
                "length": val("面の外寸 mm"),
                "bendAngle": val("次の面との曲げ量（度）。最後の面は value null"),
            ],
            "required": ["length"],
        ]
        let feature: [String: Any] = [
            "type": "object",
            "properties": [
                "kind": ["type": "string", "enum": ["circle", "tap", "countersink", "slot", "rect", "polygon"]],
                "segment": ["type": "integer", "description": "基準にする面の番号（profileX の添字、0始まり）"],
                "x": val("面の左側外側基準線からの距離 mm"),
                "y": val("板の下端からの距離 mm"),
                "diameter": val("穴径 mm（circle / countersink）"),
                "tapSize": ["type": "string", "description": "タップの呼び（例 M5）"],
                "length": val("長穴の全長 / 角穴のX方向寸法 mm"),
                "width": val("長穴の幅 / 角穴のY方向寸法 mm"),
                "angle": val("回転角（度、反時計回り）"),
                "cornerRadius": val("角穴の角R mm"),
                "points": ["type": "array", "items": point],
                "note": ["type": "string"],
            ],
            "required": ["kind", "x", "y"],
        ]
        let mark: [String: Any] = [
            "type": "object",
            "properties": [
                "segment": ["type": "integer"],
                "x1": val("始点X"), "y1": val("始点Y"),
                "x2": val("終点X"), "y2": val("終点Y"),
                "note": ["type": "string"],
            ],
            "required": ["x1", "y1", "x2", "y2"],
        ]
        let outline: [String: Any] = [
            "type": "object",
            "properties": [
                "kind": ["type": "string", "enum": ["rect", "polygon"]],
                "profileX": ["type": "array", "items": segment],
                "height": val("Y方向の長さ（曲げ線の長さ） mm"),
                "corners": [
                    "type": "object",
                    "properties": ["bl": corner, "br": corner, "tr": corner, "tl": corner],
                ],
                "points": ["type": "array", "items": point],
            ],
            "required": ["kind"],
        ]
        let part: [String: Any] = [
            "type": "object",
            "properties": [
                "name": ["type": "string"],
                "process": ["type": "string", "enum": ["laser", "lathe", "purchased", "other"]],
                "quantity": val("必要個数"),
                "material": ["type": "string"],
                "thickness": val("板厚 mm"),
                "outline": outline,
                "features": ["type": "array", "items": feature],
                "marks": ["type": "array", "items": mark],
                "notes": stringArray,
                "questions": stringArray,
            ],
            "required": ["name", "process", "quantity", "material", "thickness"],
        ]
        return [
            "type": "object",
            "properties": [
                "drawing": [
                    "type": "object",
                    "properties": [
                        "title": ["type": "string", "description": "品名"],
                        "drawingNumber": ["type": "string", "description": "図番"],
                        "material": ["type": "string"],
                        "notes": stringArray,
                    ],
                ],
                "questions": stringArray,
                "parts": ["type": "array", "items": part],
            ],
            "required": ["drawing", "questions", "parts"],
        ]
    }
}
