import UIKit

/// APIキー無しで画面の動きを確認するためのデモ
enum DemoData {
    static let json = """
    {
      "drawing": {"title": "デモ ブラケット", "drawingNumber": "DEMO-001", "material": "SUS304",
                  "notes": ["溶接部焼け取り", "みがき面キズ注意"]},
      "questions": ["本体の板厚が図面に記載されていません。何mmですか？"],
      "parts": [
        {
          "name": "L曲げブラケット", "process": "laser",
          "quantity": {"value": 2, "confidence": "high", "note": "1台2個 × 数1"},
          "material": "SUS304",
          "thickness": {"value": 3, "confidence": "high", "note": "t3板 注記"},
          "outline": {
            "kind": "rect",
            "profileX": [
              {"length": {"value": 50, "confidence": "high"}, "bendAngle": {"value": 90, "confidence": "high"}},
              {"length": {"value": 120, "confidence": "low", "note": "全長170から逆算"}, "bendAngle": {"value": null, "confidence": "missing"}}
            ],
            "height": {"value": 80, "confidence": "high"},
            "corners": {
              "bl": {"type": "none"}, "br": {"type": "radius", "size": {"value": 5, "confidence": "high"}},
              "tr": {"type": "radius", "size": {"value": 5, "confidence": "high"}}, "tl": {"type": "none"}
            }
          },
          "features": [
            {"kind": "circle", "segment": 0, "x": {"value": 25, "confidence": "high"}, "y": {"value": 40, "confidence": "high"},
             "diameter": {"value": 10.1, "confidence": "high"}},
            {"kind": "countersink", "segment": 1, "x": {"value": 30, "confidence": "high"}, "y": {"value": 20, "confidence": "high"},
             "diameter": {"value": 5.5, "confidence": "high"}, "note": "皿φ10.4"},
            {"kind": "tap", "segment": 1, "x": {"value": 30, "confidence": "high"}, "y": {"value": 60, "confidence": "high"}, "tapSize": "M5"},
            {"kind": "slot", "segment": 1, "x": {"value": 80, "confidence": "high"}, "y": {"value": 40, "confidence": "high"},
             "length": {"value": 30, "confidence": "high"}, "width": {"value": 8, "confidence": "high"}, "angle": {"value": 0, "confidence": "high"}},
            {"kind": "rect", "segment": 1, "x": {"value": 105, "confidence": "high"}, "y": {"value": 40, "confidence": "high"},
             "length": {"value": 10, "confidence": "high"}, "width": {"value": null, "confidence": "missing"},
             "cornerRadius": {"value": 1, "confidence": "high"}}
          ],
          "marks": [],
          "notes": ["こちら側溶接盛り不可"],
          "questions": ["角穴の縦寸法が読み取れません"]
        },
        {"name": "シャフト φ25", "process": "lathe", "quantity": {"value": 2, "confidence": "high"},
         "material": "SUS304", "thickness": {"value": null, "confidence": "missing"}},
        {"name": "M5×25L 皿ネジ", "process": "purchased", "quantity": {"value": 3, "confidence": "high"},
         "material": "SUS", "thickness": {"value": null, "confidence": "missing"}}
      ]
    }
    """

    static func makeJob() -> Job {
        var job = Job()
        job.analysis = (try? JSONDecoder().decode(Analysis.self, from: Data(json.utf8))) ?? Analysis()
        job.hint = "デモデータ"
        let size = CGSize(width: 600, height: 420)
        let img = UIGraphicsImageRenderer(size: size).image { ctx in
            UIColor.white.setFill(); ctx.fill(CGRect(origin: .zero, size: size))
            let attrs: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: 48), .foregroundColor: UIColor.systemBlue]
            ("DEMO 図面" as NSString).draw(at: CGPoint(x: 160, y: 180), withAttributes: attrs)
        }
        job.imageFile = ImageStore.save(img)
        return job
    }
}
