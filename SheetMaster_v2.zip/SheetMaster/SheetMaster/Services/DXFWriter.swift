import Foundation

/// DXF R12（AC1009）形式で書き出す。単位 mm。
/// レイヤー: CUT_OUTER（外形）/ CUT_INNER（穴）/ BEND（曲げ線）/ MARK（けがき）/ TEXT（文字）
enum DXFWriter {

    static func make(_ fp: FlatPattern, layers: Set<Layer>) -> String {
        var s = ""
        func g(_ code: Int, _ value: String) { s += "\(code)\r\n\(value)\r\n" }
        func num(_ v: Double) -> String { String(format: "%.4f", v) }

        let used = fp.entities.filter { layers.contains($0.layer) }
        let bb = FlatPattern(entities: used, width: fp.width, height: fp.height).bounds

        // HEADER
        g(0, "SECTION"); g(2, "HEADER")
        g(9, "$ACADVER"); g(1, "AC1009")
        g(9, "$DWGCODEPAGE"); g(3, "ANSI_932")
        g(9, "$INSUNITS"); g(70, "4")
        g(9, "$EXTMIN"); g(10, num(bb.minX)); g(20, num(bb.minY)); g(30, "0.0")
        g(9, "$EXTMAX"); g(10, num(bb.maxX)); g(20, num(bb.maxY)); g(30, "0.0")
        g(0, "ENDSEC")

        // TABLES
        g(0, "SECTION"); g(2, "TABLES")
        g(0, "TABLE"); g(2, "LTYPE"); g(70, "1")
        g(0, "LTYPE"); g(2, "CONTINUOUS"); g(70, "0"); g(3, "Solid line"); g(72, "65"); g(73, "0"); g(40, "0.0")
        g(0, "ENDTAB")
        let layerList = Layer.allCases.filter { layers.contains($0) }
        g(0, "TABLE"); g(2, "LAYER"); g(70, "\(layerList.count + 1)")
        g(0, "LAYER"); g(2, "0"); g(70, "0"); g(62, "7"); g(6, "CONTINUOUS")
        for l in layerList {
            g(0, "LAYER"); g(2, l.rawValue); g(70, "0"); g(62, "\(l.aci)"); g(6, "CONTINUOUS")
        }
        g(0, "ENDTAB")
        g(0, "ENDSEC")

        // ENTITIES
        g(0, "SECTION"); g(2, "ENTITIES")
        for e in used {
            switch e {
            case .line(let a, let b, let l):
                g(0, "LINE"); g(8, l.rawValue)
                g(10, num(a.x)); g(20, num(a.y)); g(30, "0.0")
                g(11, num(b.x)); g(21, num(b.y)); g(31, "0.0")
            case .circle(let c, let r, let l):
                g(0, "CIRCLE"); g(8, l.rawValue)
                g(10, num(c.x)); g(20, num(c.y)); g(30, "0.0"); g(40, num(r))
            case .arc(let c, let r, let start, let end, let l):
                g(0, "ARC"); g(8, l.rawValue)
                g(10, num(c.x)); g(20, num(c.y)); g(30, "0.0"); g(40, num(r))
                g(50, num(start)); g(51, num(end))
            case .text(let p, let h, let str, let l):
                g(0, "TEXT"); g(8, l.rawValue)
                g(10, num(p.x)); g(20, num(p.y)); g(30, "0.0"); g(40, num(h)); g(1, str)
            }
        }
        g(0, "ENDSEC")
        g(0, "EOF")
        return s
    }

    /// 日本語を含むため Shift_JIS で保存（失敗時は UTF-8）
    static func data(_ text: String) -> Data {
        text.data(using: .shiftJIS) ?? Data(text.utf8)
    }

    static func fileName(part: Part, drawingNumber: String) -> String {
        var parts: [String] = []
        if !drawingNumber.isEmpty { parts.append(drawingNumber) }
        parts.append(part.name)
        if !part.material.isEmpty { parts.append(part.material) }
        parts.append("t" + FlatBuilder.fmt(part.thickness.number))
        parts.append("\(Int(part.quantity.number))個")
        let raw = parts.joined(separator: "_")
        let bad = CharacterSet(charactersIn: "/\\:*?\"<>| \n\r\t")
        let cleaned = raw.unicodeScalars.map { bad.contains($0) ? "-" : String($0) }.joined()
        return cleaned + ".dxf"
    }
}
