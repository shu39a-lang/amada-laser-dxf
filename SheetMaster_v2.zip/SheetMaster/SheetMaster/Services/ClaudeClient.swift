import Foundation

enum ClaudeError: LocalizedError {
    case noKey
    case http(Int, String)
    case noToolUse
    case truncated
    case decode(String)

    var errorDescription: String? {
        switch self {
        case .noKey: return "Claude APIキーが未設定です。設定画面で入力してください。"
        case .http(let code, let msg): return "通信エラー（\(code)）: \(msg)"
        case .noToolUse: return "AIから読み取り結果が返りませんでした。もう一度お試しください。"
        case .truncated: return "図面の情報量が多く、結果が途中で切れました。図面を分けて撮影してください。"
        case .decode(let msg): return "読み取り結果の解析に失敗しました: \(msg)"
        }
    }
}

struct ClaudeClient {
    let apiKey: String
    let model: String

    func analyze(jpeg: Data, hint: String) async throws -> Analysis {
        guard !apiKey.isEmpty else { throw ClaudeError.noKey }

        var req = URLRequest(url: URL(string: "https://api.anthropic.com/v1/messages")!)
        req.httpMethod = "POST"
        req.timeoutInterval = 300
        req.setValue(apiKey, forHTTPHeaderField: "x-api-key")
        req.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
        req.setValue("application/json", forHTTPHeaderField: "content-type")

        var userText = "この図面を読み取り、report_drawing ツールで報告してください。"
        let trimmed = hint.trimmingCharacters(in: .whitespacesAndNewlines)
        if !trimmed.isEmpty {
            userText += "\n\n【作業者からの補足（図面より優先してください）】\n" + trimmed
        }

        let imageBlock: [String: Any] = [
            "type": "image",
            "source": ["type": "base64", "media_type": "image/jpeg", "data": jpeg.base64EncodedString()],
        ]
        let textBlock: [String: Any] = ["type": "text", "text": userText]
        let tool: [String: Any] = [
            "name": AnalysisPrompt.toolName,
            "description": "図面から読み取った部品・外形・穴・不明点を報告する",
            "input_schema": AnalysisPrompt.schema,
        ]
        let body: [String: Any] = [
            "model": model,
            "max_tokens": 16000,
            "system": AnalysisPrompt.system,
            "tools": [tool],
            "tool_choice": ["type": "tool", "name": AnalysisPrompt.toolName],
            "messages": [["role": "user", "content": [imageBlock, textBlock]]],
        ]
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await URLSession.shared.data(for: req)
        let status = (response as? HTTPURLResponse)?.statusCode ?? 0
        let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]

        guard status == 200 else {
            let msg = ((json["error"] as? [String: Any])?["message"] as? String)
                ?? String(data: data, encoding: .utf8) ?? ""
            throw ClaudeError.http(status, msg)
        }
        if (json["stop_reason"] as? String) == "max_tokens" { throw ClaudeError.truncated }

        let content = json["content"] as? [[String: Any]] ?? []
        guard let toolUse = content.first(where: { ($0["type"] as? String) == "tool_use" }),
              let input = toolUse["input"] else { throw ClaudeError.noToolUse }

        do {
            let inputData = try JSONSerialization.data(withJSONObject: input)
            return try JSONDecoder().decode(Analysis.self, from: inputData)
        } catch {
            throw ClaudeError.decode(error.localizedDescription)
        }
    }
}
