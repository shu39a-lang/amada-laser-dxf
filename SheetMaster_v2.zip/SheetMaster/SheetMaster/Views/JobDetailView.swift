import SwiftUI

struct JobDetailView: View {
    @Binding var job: Job
    @Environment(AppSettings.self) private var settings
    @State private var zoomImage: PendingImage?

    var body: some View {
        let config = settings.config
        List {
            Section {
                if let img = ImageStore.load(job.imageFile) {
                    Image(uiImage: img).resizable().scaledToFit().frame(maxHeight: 220)
                        .onTapGesture { zoomImage = PendingImage(image: img) }
                }
                TextField("品名", text: $job.analysis.drawing.title)
                TextField("図番", text: $job.analysis.drawing.drawingNumber)
                TextField("材質", text: $job.analysis.drawing.material)
            } header: {
                Text("図面")
            } footer: {
                Text("画像をタップすると拡大できます")
            }

            if !job.analysis.questions.isEmpty {
                Section("AIからの確認事項") {
                    ForEach(job.analysis.questions, id: \.self) { q in
                        Label(q, systemImage: "questionmark.bubble").foregroundStyle(.orange)
                    }
                }
            }

            Section {
                ForEach($job.analysis.parts) { $part in
                    NavigationLink {
                        PartEditView(part: $part, drawingImage: job.imageFile)
                    } label: {
                        PartRow(part: part, issues: Validator.issues(part, config))
                    }
                }
                .onDelete { job.analysis.parts.remove(atOffsets: $0) }
                Button {
                    var p = Part()
                    p.material = job.analysis.drawing.material
                    job.analysis.parts.append(p)
                } label: {
                    Label("部品を追加", systemImage: "plus")
                }
            } header: {
                Text("部品")
            } footer: {
                Text("赤 = 図面に無いので入力が必要 / 黄 = AIの推定なので確認推奨")
            }

            Section {
                NavigationLink {
                    ExportView(job: $job)
                } label: {
                    Label("DXFを出力", systemImage: "square.and.arrow.up.on.square").font(.headline)
                }
            }

            if !job.analysis.drawing.notes.isEmpty {
                Section("図面の注記") {
                    ForEach(job.analysis.drawing.notes, id: \.self) { Text($0).font(.subheadline) }
                }
            }
            if !job.hint.isEmpty {
                Section("読み取り時の補足") { Text(job.hint).font(.subheadline) }
            }
        }
        .navigationTitle(job.title)
        .navigationBarTitleDisplayMode(.inline)
        .fullScreenCover(item: $zoomImage) { ZoomImageView(image: $0.image) }
    }
}

struct PartRow: View {
    let part: Part
    let issues: [Issue]

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(part.name).font(.headline)
                Spacer()
                Text(part.process.label)
                    .font(.caption.bold())
                    .padding(.horizontal, 8).padding(.vertical, 2)
                    .background(part.process == .laser ? Color.blue.opacity(0.15) : Color.gray.opacity(0.15))
                    .clipShape(Capsule())
            }
            HStack(spacing: 8) {
                if !part.material.isEmpty { Text(part.material) }
                if let t = part.thickness.value { Text("t\(ValField.format(t))") }
                if let q = part.quantity.value { Text("\(ValField.format(q))個") }
            }
            .font(.caption).foregroundStyle(.secondary)
            if part.process == .laser {
                let errors = issues.filter { $0.severity == .error }.count
                let warnings = issues.count - errors
                HStack(spacing: 10) {
                    if errors > 0 { Text("要入力 \(errors)").foregroundStyle(.red) }
                    if warnings > 0 { Text("要確認 \(warnings)").foregroundStyle(.orange) }
                    if issues.isEmpty { Text("出力できます").foregroundStyle(.green) }
                }
                .font(.caption.bold())
            }
        }
    }
}
