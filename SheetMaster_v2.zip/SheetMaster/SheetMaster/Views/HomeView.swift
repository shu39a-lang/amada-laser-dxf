import PhotosUI
import SwiftUI
import VisionKit

struct PendingImage: Identifiable {
    let id = UUID()
    let image: UIImage
}

struct HomeView: View {
    @Environment(JobStore.self) private var store
    @Environment(AppSettings.self) private var settings

    @State private var path: [UUID] = []
    @State private var showScanner = false
    @State private var showCamera = false
    @State private var showPhotoPicker = false
    @State private var photoItem: PhotosPickerItem?
    @State private var pendingImage: PendingImage?
    @State private var showSettings = false

    var body: some View {
        NavigationStack(path: $path) {
            List {
                if store.jobs.isEmpty {
                    ContentUnavailableView("図面がまだありません",
                                           systemImage: "doc.viewfinder",
                                           description: Text("右上の ＋ から図面をスキャンしてください"))
                }
                ForEach(store.jobs) { job in
                    NavigationLink(value: job.id) { JobRow(job: job, config: settings.config) }
                }
                .onDelete { store.delete(at: $0) }
            }
            .navigationTitle("SHEET MASTER")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { showSettings = true } label: { Image(systemName: "gearshape") }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        if VNDocumentCameraViewController.isSupported {
                            Button("図面をスキャン（おすすめ）", systemImage: "doc.viewfinder") { showScanner = true }
                        }
                        if UIImagePickerController.isSourceTypeAvailable(.camera) {
                            Button("カメラで撮影", systemImage: "camera") { showCamera = true }
                        }
                        Button("写真から選ぶ", systemImage: "photo.on.rectangle") { showPhotoPicker = true }
                        Divider()
                        Button("デモデータで試す", systemImage: "wand.and.stars") {
                            let job = DemoData.makeJob()
                            store.add(job)
                            path.append(job.id)
                        }
                    } label: {
                        Image(systemName: "plus.circle.fill").font(.title2)
                    }
                }
            }
            .navigationDestination(for: UUID.self) { id in
                if let binding = store.binding(for: id) {
                    JobDetailView(job: binding)
                } else {
                    ContentUnavailableView("見つかりません", systemImage: "questionmark")
                }
            }
        }
        .photosPicker(isPresented: $showPhotoPicker, selection: $photoItem, matching: .images)
        .onChange(of: photoItem) { _, item in
            guard let item else { return }
            Task {
                if let data = try? await item.loadTransferable(type: Data.self),
                   let img = UIImage(data: data) {
                    await present(img)
                }
                photoItem = nil
            }
        }
        .fullScreenCover(isPresented: $showScanner) {
            DocumentScannerView { img in
                showScanner = false
                if let img { Task { await present(img) } }
            }
            .ignoresSafeArea()
        }
        .fullScreenCover(isPresented: $showCamera) {
            CameraPicker { img in
                showCamera = false
                if let img { Task { await present(img) } }
            }
            .ignoresSafeArea()
        }
        .sheet(item: $pendingImage) { pending in
            NewJobView(image: pending.image) { jobID in
                pendingImage = nil
                path.append(jobID)
            }
        }
        .sheet(isPresented: $showSettings) {
            SettingsView()
        }
    }

    /// 前の画面が閉じきってから次のシートを開く
    @MainActor
    private func present(_ image: UIImage) async {
        try? await Task.sleep(for: .milliseconds(600))
        pendingImage = PendingImage(image: image)
    }
}

struct JobRow: View {
    let job: Job
    let config: CalcConfig

    var body: some View {
        HStack(spacing: 12) {
            if let img = ImageStore.load(job.imageFile) {
                Image(uiImage: img).resizable().scaledToFill()
                    .frame(width: 56, height: 56).clipShape(RoundedRectangle(cornerRadius: 8))
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(job.title).font(.headline).lineLimit(1)
                Text(job.createdAt.formatted(date: .abbreviated, time: .shortened))
                    .font(.caption).foregroundStyle(.secondary)
                let laser = job.analysis.parts.filter { $0.process == .laser }
                let errors = laser.reduce(0) { $0 + Validator.errorCount($1, config) }
                if errors > 0 {
                    Text("要入力 \(errors)件").font(.caption.bold()).foregroundStyle(.red)
                } else {
                    Text("レーザー部品 \(laser.count)点 ・ 出力可").font(.caption).foregroundStyle(.green)
                }
            }
        }
    }
}

// MARK: - 新規読み取り

struct NewJobView: View {
    let image: UIImage
    var onCreated: (UUID) -> Void

    @Environment(JobStore.self) private var store
    @Environment(AppSettings.self) private var settings
    @Environment(\.dismiss) private var dismiss

    @State private var hint = ""
    @State private var isAnalyzing = false
    @State private var errorMessage: String?

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Image(uiImage: image).resizable().scaledToFit().frame(maxHeight: 300)
                }
                Section {
                    TextField("例）本体はt1.5、勝手違いは不要、など", text: $hint, axis: .vertical)
                        .lineLimit(2...5)
                } header: {
                    Text("補足（任意）")
                } footer: {
                    Text("図面に書かれていないことが分かっていれば入力してください。AIは図面より補足を優先します。")
                }
                Section {
                    Button {
                        Task { await analyze() }
                    } label: {
                        HStack {
                            Spacer()
                            if isAnalyzing {
                                ProgressView().padding(.trailing, 8)
                                Text("AIが図面を読み取り中…")
                            } else {
                                Label("AIで読み取る", systemImage: "sparkles")
                            }
                            Spacer()
                        }
                    }
                    .disabled(isAnalyzing)
                } footer: {
                    Text("30秒〜2分ほどかかります。読み取れなかった値は、次の画面で赤く表示されるので入力してください。")
                }
            }
            .navigationTitle("図面の読み取り")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("閉じる") { dismiss() }.disabled(isAnalyzing)
                }
            }
            .alert("読み取りできませんでした",
                   isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(errorMessage ?? "")
            }
            .interactiveDismissDisabled(isAnalyzing)
        }
    }

    @MainActor
    private func analyze() async {
        guard let jpeg = ImageStore.jpegForAPI(image) else {
            errorMessage = "画像の変換に失敗しました。"
            return
        }
        isAnalyzing = true
        defer { isAnalyzing = false }
        do {
            let client = ClaudeClient(apiKey: settings.apiKey, model: settings.data.model)
            let analysis = try await client.analyze(jpeg: jpeg, hint: hint)
            var job = Job()
            job.imageFile = ImageStore.save(image)
            job.hint = hint
            job.analysis = analysis
            store.add(job)
            onCreated(job.id)
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
