import SwiftUI

struct PartEditView: View {
    @Binding var part: Part
    let drawingImage: String

    @Environment(AppSettings.self) private var settings
    @State private var zoomImage: PendingImage?

    var body: some View {
        let config = settings.config
        let issues = Validator.issues(part, config)
        Form {
            if !issues.isEmpty {
                Section("入力・確認が必要な項目") {
                    IssueList(issues: issues)
                    if issues.contains(where: { $0.severity == .warning }) {
                        Button("黄色（AI推定）をすべて確認済みにする") { part.confirmAllLow() }
                    }
                }
            }

            Section("基本") {
                TextField("部品名", text: $part.name)
                Picker("加工", selection: $part.process) {
                    ForEach(PartProcess.allCases) { Text($0.label).tag($0) }
                }
                ValField(label: "数量", val: $part.quantity, unit: "個")
                HStack {
                    Text("材質")
                    Spacer()
                    TextField("例 SUS304", text: $part.material).multilineTextAlignment(.trailing)
                }
                ValField(label: "板厚", val: $part.thickness)
            }

            if part.process == .laser {
                outlineSections(config: config)
                featureSection
                markSection
                Section {
                    NavigationLink {
                        PreviewView(part: part)
                    } label: {
                        Label("展開図プレビュー", systemImage: "eye")
                    }
                }
            }

            if !part.questions.isEmpty {
                Section("AIからの質問") {
                    ForEach(part.questions, id: \.self) { Label($0, systemImage: "questionmark.bubble").foregroundStyle(.orange) }
                }
            }
            if !part.notes.isEmpty {
                Section("注記（溶接・仕上げ等）") {
                    ForEach(part.notes, id: \.self) { Text($0).font(.subheadline) }
                }
            }
        }
        .navigationTitle(part.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    if let img = ImageStore.load(drawingImage) { zoomImage = PendingImage(image: img) }
                } label: {
                    Label("図面", systemImage: "doc.text.magnifyingglass")
                }
            }
        }
        .fullScreenCover(item: $zoomImage) { ZoomImageView(image: $0.image) }
    }

    // MARK: 外形

    @ViewBuilder
    private func outlineSections(config: CalcConfig) -> some View {
        Section {
            Picker("外形", selection: $part.outline.kind) {
                Text("長方形・曲げ").tag(OutlineKind.rect)
                Text("多角形").tag(OutlineKind.polygon)
            }
            .pickerStyle(.segmented)
        } header: {
            Text("外形")
        } footer: {
            Text(part.outline.kind == .rect
                 ? "曲げがある場合は、曲げの並ぶ方向に「面」を左から順に外寸で入力します。展開長はアプリが控除値で計算します。"
                 : "展開後の外形の頂点を反時計回りに入力します（左下原点）。")
        }

        if part.outline.kind == .rect {
            Section("曲げ方向（X）の面") {
                ForEach($part.outline.profileX) { $seg in
                    let index = part.outline.profileX.firstIndex(where: { $0.id == seg.id }) ?? 0
                    let isLast = index == part.outline.profileX.count - 1
                    SegmentEditor(segment: $seg, index: index, isLast: isLast,
                                  count: part.outline.profileX.count, part: part, config: config)
                }
                .onDelete { offsets in
                    part.outline.profileX.remove(atOffsets: offsets)
                    if part.outline.profileX.isEmpty { part.outline.profileX = [Segment()] }
                }
                Button {
                    part.outline.profileX.append(Segment())
                } label: {
                    Label("曲げを追加（面を追加）", systemImage: "plus")
                }
                LabeledContent("展開後の幅", value: flatSizeText(config: config))
            }
            Section("曲げ線方向（Y）・角") {
                ValField(label: part.outline.profileX.count > 1 ? "曲げ線方向の長さ" : "高さ", val: $part.outline.height)
                CornerEditor(label: "左下", corner: $part.outline.corners.bl)
                CornerEditor(label: "右下", corner: $part.outline.corners.br)
                CornerEditor(label: "右上", corner: $part.outline.corners.tr)
                CornerEditor(label: "左上", corner: $part.outline.corners.tl)
            }
        } else {
            Section("頂点（反時計回り）") {
                ForEach($part.outline.points) { $pt in
                    let i = part.outline.points.firstIndex(where: { $0.id == pt.id }) ?? 0
                    PointEditor(point: $pt, title: "頂点\(i + 1)")
                }
                .onDelete { part.outline.points.remove(atOffsets: $0) }
                .onMove { part.outline.points.move(fromOffsets: $0, toOffset: $1) }
                Button {
                    part.outline.points.append(PolyPoint())
                } label: {
                    Label("頂点を追加", systemImage: "plus")
                }
            }
        }
    }

    private func flatSizeText(config: CalcConfig) -> String {
        let fp = FlatBuilder.build(part, config: config)
        return "\(ValField.format((fp.width * 100).rounded() / 100)) × \(ValField.format((fp.height * 100).rounded() / 100)) mm"
    }

    // MARK: 穴

    private var featureSection: some View {
        Section {
            ForEach($part.features) { $f in
                let i = part.features.firstIndex(where: { $0.id == f.id }) ?? 0
                NavigationLink {
                    FeatureEditView(feature: $f, title: "穴\(i + 1)",
                                    segmentCount: part.outline.kind == .rect ? part.outline.profileX.count : 1)
                } label: {
                    FeatureRow(feature: f, index: i)
                }
            }
            .onDelete { part.features.remove(atOffsets: $0) }
            Menu {
                ForEach(FeatureKind.allCases) { kind in
                    Button(kind.label) { part.features.append(Feature(kind: kind)) }
                }
            } label: {
                Label("穴・切り欠きを追加", systemImage: "plus")
            }
        } header: {
            Text("穴・切り欠き（\(part.features.count)）")
        } footer: {
            Text("X = 基準の面の左側外寸線から、Y = 板の下端から、穴の中心までの距離。")
        }
    }

    // MARK: けがき

    private var markSection: some View {
        Section {
            ForEach($part.marks) { $m in
                let i = part.marks.firstIndex(where: { $0.id == m.id }) ?? 0
                DisclosureGroup("けがき\(i + 1) \(m.note)") {
                    if part.outline.kind == .rect && part.outline.profileX.count > 1 {
                        Picker("基準の面", selection: $m.segment) {
                            ForEach(0..<part.outline.profileX.count, id: \.self) { Text("面\($0 + 1)").tag($0) }
                        }
                    }
                    ValField(label: "始点X", val: $m.x1)
                    ValField(label: "始点Y", val: $m.y1)
                    ValField(label: "終点X", val: $m.x2)
                    ValField(label: "終点Y", val: $m.y2)
                    TextField("メモ", text: $m.note)
                }
            }
            .onDelete { part.marks.remove(atOffsets: $0) }
            Button {
                part.marks.append(Mark())
            } label: {
                Label("けがき線を追加", systemImage: "plus")
            }
        } header: {
            Text("けがき線（\(part.marks.count)）")
        }
    }
}

// MARK: - 面（曲げ）の入力

struct SegmentEditor: View {
    @Binding var segment: Segment
    let index: Int
    let isLast: Bool
    let count: Int
    let part: Part
    let config: CalcConfig

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(count > 1 ? "面\(index + 1)" : "幅").font(.subheadline.bold())
            ValField(label: "外寸", val: $segment.length)
            if !isLast {
                ValField(label: "曲げ\(index + 1)の角度", val: $segment.bendAngle, unit: "°")
                deductionView
            }
        }
        .padding(.vertical, 4)
    }

    @ViewBuilder
    private var deductionView: some View {
        let calc = BendCalc(config: config)
        let result = calc.deduction(part: part, segment: segment)
        HStack {
            Text("控除値").font(.caption)
            Spacer()
            switch result.source {
            case .user:
                Text("手入力").font(.caption).foregroundStyle(.secondary)
            case .table(let verified):
                Text("\(ValField.format(result.value)) mm（控除表\(verified ? "" : "・参考値")）")
                    .font(.caption).foregroundStyle(verified ? Color.secondary : Color.orange)
            case .formula:
                Text("\(ValField.format(result.value)) mm（計算値）").font(.caption).foregroundStyle(.orange)
            case .unavailable:
                Text("未登録").font(.caption.bold()).foregroundStyle(.red)
            }
        }
        ValField(label: "控除値を手入力", val: $segment.deduction, required: false)
        if result.source == .unavailable || result.source == .formula,
           let t = part.thickness.value, let a = segment.bendAngle.value,
           let f = calc.formula(thickness: t, angle: a) {
            Button("計算値 \(ValField.format((f * 100).rounded() / 100)) mm を使う") {
                segment.deduction = Val((f * 100).rounded() / 100, .user, note: "計算値（K=\(config.kFactor)）")
            }
            .font(.caption)
            .buttonStyle(.borderless)
        }
    }
}

// MARK: - 頂点の入力

struct PointEditor: View {
    @Binding var point: PolyPoint
    let title: String

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.subheadline.bold())
            ValField(label: "X", val: $point.x)
            ValField(label: "Y", val: $point.y)
            CornerEditor(label: "角", corner: $point.corner)
        }
        .padding(.vertical, 4)
    }
}

// MARK: - 穴の一覧行

struct FeatureRow: View {
    let feature: Feature
    let index: Int

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text("穴\(index + 1)　\(feature.kind.label)　\(spec)")
            Text("X \(ValField.format(feature.x.value).ifEmpty("？"))  Y \(ValField.format(feature.y.value).ifEmpty("？"))\(feature.segment > 0 ? "（面\(feature.segment + 1)基準）" : "")")
                .font(.caption).foregroundStyle(.secondary)
        }
        .foregroundStyle(hasMissing ? Color.red : Color.primary)
    }

    private var spec: String {
        switch feature.kind {
        case .circle, .countersink: return "φ" + ValField.format(feature.diameter.value).ifEmpty("？")
        case .tap: return feature.tapSize.ifEmpty("M？")
        case .slot: return "\(ValField.format(feature.length.value).ifEmpty("？"))×\(ValField.format(feature.width.value).ifEmpty("？"))"
        case .rect: return "\(ValField.format(feature.length.value).ifEmpty("？"))×\(ValField.format(feature.width.value).ifEmpty("？"))"
        case .polygon: return "\(feature.points.count)点"
        }
    }

    private var hasMissing: Bool {
        if feature.x.isMissing || feature.y.isMissing { return true }
        switch feature.kind {
        case .circle, .countersink: return feature.diameter.isMissing
        case .tap: return feature.tapSize.isEmpty
        case .slot, .rect: return feature.length.isMissing || feature.width.isMissing
        case .polygon: return feature.points.count < 3
        }
    }
}

extension String {
    func ifEmpty(_ alt: String) -> String { isEmpty ? alt : self }
}
