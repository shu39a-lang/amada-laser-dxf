import SwiftUI

struct PreviewView: View {
    let part: Part
    @Environment(AppSettings.self) private var settings

    @State private var scale: CGFloat = 1
    @State private var lastScale: CGFloat = 1
    @State private var offset: CGSize = .zero
    @State private var lastOffset: CGSize = .zero

    var body: some View {
        let config = settings.config
        let fp = FlatBuilder.build(part, config: config)
        let errors = Validator.issues(part, config).filter { $0.severity == .error }

        VStack(spacing: 0) {
            if !errors.isEmpty {
                Text("未入力が \(errors.count) 件あります。未入力の値は 0 として仮表示しています。")
                    .font(.caption).foregroundStyle(.white)
                    .frame(maxWidth: .infinity).padding(8).background(Color.red)
            }
            FlatCanvas(pattern: fp)
                .scaleEffect(scale)
                .offset(offset)
                .gesture(
                    MagnifyGesture()
                        .onChanged { scale = max(0.5, lastScale * $0.magnification) }
                        .onEnded { _ in lastScale = scale }
                        .simultaneously(with: DragGesture()
                            .onChanged { offset = CGSize(width: lastOffset.width + $0.translation.width,
                                                         height: lastOffset.height + $0.translation.height) }
                            .onEnded { _ in lastOffset = offset })
                )
                .onTapGesture(count: 2) { scale = 1; lastScale = 1; offset = .zero; lastOffset = .zero }
                .clipped()
            VStack(alignment: .leading, spacing: 6) {
                Text("展開サイズ　\(ValField.format((fp.width * 100).rounded() / 100)) × \(ValField.format((fp.height * 100).rounded() / 100)) mm")
                    .font(.headline)
                HStack(spacing: 14) {
                    legend(.outer, .primary)
                    legend(.inner, .red)
                    legend(.bend, .green)
                    legend(.mark, .cyan)
                }
                .font(.caption)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(.bar)
        }
        .navigationTitle("展開図")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func legend(_ layer: Layer, _ color: Color) -> some View {
        HStack(spacing: 4) {
            Rectangle().fill(color).frame(width: 14, height: 3)
            Text(layer.label)
        }
    }
}

/// 展開図の描画（Y軸上向き・左下原点で描く）
struct FlatCanvas: View {
    let pattern: FlatPattern

    var body: some View {
        Canvas { ctx, size in
            let b = pattern.bounds
            let w = CGFloat(max(b.maxX - b.minX, 1)), h = CGFloat(max(b.maxY - b.minY, 1))
            let margin: CGFloat = 24
            let s = min((size.width - margin * 2) / w, (size.height - margin * 2) / h)
            let ox = (size.width - w * s) / 2, oy = (size.height - h * s) / 2

            func tr(_ p: P) -> CGPoint {
                CGPoint(x: ox + CGFloat(p.x - b.minX) * s, y: size.height - oy - CGFloat(p.y - b.minY) * s)
            }

            for e in pattern.entities {
                var path = Path()
                switch e {
                case .line(let a, let c, _):
                    path.move(to: tr(a)); path.addLine(to: tr(c))
                case .circle(let c, let r, _):
                    let cc = tr(c)
                    let rr = CGFloat(r) * s
                    path.addEllipse(in: CGRect(x: cc.x - rr, y: cc.y - rr, width: rr * 2, height: rr * 2))
                case .arc(let c, let r, let start, let end, _):
                    var sweep = end - start
                    if sweep <= 0 { sweep += 360 }
                    let steps = max(8, Int(sweep / 4))
                    for i in 0...steps {
                        let a = (start + sweep * Double(i) / Double(steps)) * .pi / 180
                        let pt = tr(P(x: c.x + r * cos(a), y: c.y + r * sin(a)))
                        if i == 0 { path.move(to: pt) } else { path.addLine(to: pt) }
                    }
                case .text(let p, let hgt, let str, _):
                    ctx.draw(Text(str).font(.system(size: max(9, min(14, CGFloat(hgt) * s)))).foregroundColor(.yellow),
                             at: tr(p), anchor: .bottomLeading)
                    continue
                }
                let style: StrokeStyle = e.layer == .bend
                    ? StrokeStyle(lineWidth: 1, dash: [6, 4])
                    : StrokeStyle(lineWidth: 1.5)
                ctx.stroke(path, with: .color(color(e.layer)), style: style)
            }
        }
        .background(Color(.systemBackground))
    }

    private func color(_ l: Layer) -> Color {
        switch l {
        case .outer: return .primary
        case .inner: return .red
        case .bend: return .green
        case .mark: return .cyan
        case .text: return .yellow
        }
    }
}
