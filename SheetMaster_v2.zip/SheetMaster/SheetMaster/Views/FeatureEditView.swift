import SwiftUI

struct FeatureEditView: View {
    @Binding var feature: Feature
    let title: String
    let segmentCount: Int

    @Environment(AppSettings.self) private var settings

    var body: some View {
        Form {
            Section {
                Picker("種類", selection: $feature.kind) {
                    ForEach(FeatureKind.allCases) { Text($0.label).tag($0) }
                }
                if segmentCount > 1 {
                    Picker("基準の面", selection: $feature.segment) {
                        ForEach(0..<segmentCount, id: \.self) { Text("面\($0 + 1)").tag($0) }
                    }
                }
            }

            Section {
                ValField(label: "X（中心）", val: $feature.x)
                ValField(label: "Y（中心）", val: $feature.y)
            } header: {
                Text("位置")
            } footer: {
                Text("X は基準の面の左側外寸線から、Y は板の下端から測った距離です。")
            }

            Section("寸法") {
                switch feature.kind {
                case .circle:
                    ValField(label: "穴径 φ", val: $feature.diameter)
                case .countersink:
                    ValField(label: "キリ径 φ（貫通）", val: $feature.diameter)
                    Text("皿の加工はレーザー後に行います。DXFにはキリ径の丸穴で出力します。")
                        .font(.caption).foregroundStyle(.secondary)
                case .tap:
                    Picker("呼び", selection: $feature.tapSize) {
                        Text("選択").tag("")
                        ForEach(settings.data.tapTable) { Text($0.size).tag($0.size) }
                        if !feature.tapSize.isEmpty && !settings.data.tapTable.contains(where: { $0.size == feature.tapSize }) {
                            Text(feature.tapSize).tag(feature.tapSize)
                        }
                    }
                    if let d = settings.config.tapDrill(feature.tapSize) {
                        LabeledContent("下穴径", value: "φ\(ValField.format(d))")
                    } else {
                        Text("下穴表に無い呼びです。設定 → タップ下穴表 に追加してください。")
                            .font(.caption).foregroundStyle(.red)
                    }
                case .slot:
                    ValField(label: "全長", val: $feature.length)
                    ValField(label: "幅", val: $feature.width)
                    ValField(label: "角度", val: $feature.angle, unit: "°", required: false)
                case .rect:
                    ValField(label: "X方向の寸法", val: $feature.length)
                    ValField(label: "Y方向の寸法", val: $feature.width)
                    ValField(label: "角R", val: $feature.cornerRadius, required: false)
                    ValField(label: "角度", val: $feature.angle, unit: "°", required: false)
                case .polygon:
                    ValField(label: "回転角度", val: $feature.angle, unit: "°", required: false)
                    Text("頂点は「位置」からの相対座標で、反時計回りに入力します。")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }

            if feature.kind == .polygon {
                Section("頂点（\(feature.points.count)）") {
                    ForEach($feature.points) { $pt in
                        let i = feature.points.firstIndex(where: { $0.id == pt.id }) ?? 0
                        PointEditor(point: $pt, title: "頂点\(i + 1)")
                    }
                    .onDelete { feature.points.remove(atOffsets: $0) }
                    Button {
                        feature.points.append(PolyPoint())
                    } label: {
                        Label("頂点を追加", systemImage: "plus")
                    }
                    Button {
                        feature.points = FeatureEditView.starPoints(outer: 20, inner: 8, count: 5)
                    } label: {
                        Label("星形のひな形を入れる（外径40・内径16）", systemImage: "star")
                    }
                }
            }

            Section("メモ") {
                TextField("例）皿φ10.4、溶接ネジ用 など", text: $feature.note, axis: .vertical)
            }
        }
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
    }

    static func starPoints(outer: Double, inner: Double, count: Int) -> [PolyPoint] {
        (0..<(count * 2)).map { i in
            let r = i % 2 == 0 ? outer : inner
            let a = (90 + Double(i) * 180 / Double(count)) * .pi / 180
            let x = (r * cos(a) * 1000).rounded() / 1000
            let y = (r * sin(a) * 1000).rounded() / 1000
            return PolyPoint(x: Val(x, .user), y: Val(y, .user))
        }
    }
}
