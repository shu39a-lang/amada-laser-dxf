import SwiftUI
import UIKit
import VisionKit

// MARK: - 数値入力（読み取り値の確からしさを色で表示）

/// 赤 = 図面に無い（要入力） / 黄 = AI推定（要確認） / 無色 = 図面に明記 or 入力済み
struct ValField: View {
    let label: String
    @Binding var val: Val
    var unit: String = "mm"
    var required: Bool = true

    @State private var text = ""
    @FocusState private var focused: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack {
                Text(label)
                Spacer()
                TextField(required ? "要入力" : "—", text: $text)
                    .keyboardType(.numbersAndPunctuation)
                    .multilineTextAlignment(.trailing)
                    .frame(maxWidth: 110)
                    .focused($focused)
                Text(unit).font(.caption).foregroundStyle(.secondary)
                if val.confidence == .low && val.value != nil {
                    Button {
                        val.confidence = .user
                    } label: {
                        Image(systemName: "checkmark.circle")
                    }
                    .buttonStyle(.borderless)
                    .accessibilityLabel("この値で確認済みにする")
                }
            }
            if let note = val.note, !note.isEmpty {
                Text(note).font(.caption2).foregroundStyle(.secondary)
            }
        }
        .listRowBackground(background)
        .onAppear { text = ValField.format(val.value) }
        .onChange(of: text) { _, new in
            guard focused else { return }
            let s = ValField.normalize(new)
            if s.isEmpty {
                val.value = nil
                val.confidence = .missing
            } else if let v = Double(s) {
                val.value = v
                val.confidence = .user
            }
        }
        .onChange(of: val.value) { _, nv in
            if !focused { text = ValField.format(nv) }
        }
    }

    private var background: Color {
        if val.value == nil { return required ? Color.red.opacity(0.15) : Color(.secondarySystemGroupedBackground) }
        if val.confidence == .low { return Color.yellow.opacity(0.25) }
        return Color(.secondarySystemGroupedBackground)
    }

    static func format(_ v: Double?) -> String {
        guard let v else { return "" }
        if v == v.rounded() { return String(Int(v)) }
        var s = String(format: "%.3f", v)
        while s.hasSuffix("0") { s.removeLast() }
        if s.hasSuffix(".") { s.removeLast() }
        return s
    }

    /// 全角数字・カンマを半角に
    static func normalize(_ s: String) -> String {
        let map: [Character: Character] = ["０": "0", "１": "1", "２": "2", "３": "3", "４": "4",
                                           "５": "5", "６": "6", "７": "7", "８": "8", "９": "9",
                                           "．": ".", ",": ".", "，": ".", "－": "-", "ー": "-"]
        return String(s.map { map[$0] ?? $0 }).trimmingCharacters(in: .whitespaces)
    }
}

/// 設定画面用の単純な数値入力
struct NumberField: View {
    let label: String
    @Binding var value: Double
    var unit: String = ""

    @State private var text = ""
    @FocusState private var focused: Bool

    var body: some View {
        HStack {
            Text(label)
            Spacer()
            TextField("0", text: $text)
                .keyboardType(.numbersAndPunctuation)
                .multilineTextAlignment(.trailing)
                .frame(maxWidth: 90)
                .focused($focused)
            if !unit.isEmpty { Text(unit).font(.caption).foregroundStyle(.secondary) }
        }
        .onAppear { text = ValField.format(value) }
        .onChange(of: text) { _, new in
            guard focused, let v = Double(ValField.normalize(new)) else { return }
            value = v
        }
    }
}

// MARK: - 角（R / C）

struct CornerEditor: View {
    let label: String
    @Binding var corner: Corner

    var body: some View {
        Picker(label, selection: $corner.type) {
            ForEach(CornerType.allCases) { Text($0.label).tag($0) }
        }
        .pickerStyle(.menu)
        if corner.type != .none {
            ValField(label: "　\(label)の\(corner.type.label)", val: $corner.size)
        }
    }
}

// MARK: - 書類スキャナ（斜めの写真を自動で真っ直ぐに補正）

struct DocumentScannerView: UIViewControllerRepresentable {
    var onFinish: (UIImage?) -> Void

    func makeUIViewController(context: Context) -> VNDocumentCameraViewController {
        let vc = VNDocumentCameraViewController()
        vc.delegate = context.coordinator
        return vc
    }
    func updateUIViewController(_ uiViewController: VNDocumentCameraViewController, context: Context) {}
    func makeCoordinator() -> Coordinator { Coordinator(onFinish: onFinish) }

    final class Coordinator: NSObject, VNDocumentCameraViewControllerDelegate {
        let onFinish: (UIImage?) -> Void
        init(onFinish: @escaping (UIImage?) -> Void) { self.onFinish = onFinish }

        func documentCameraViewController(_ controller: VNDocumentCameraViewController,
                                          didFinishWith scan: VNDocumentCameraScan) {
            onFinish(scan.pageCount > 0 ? scan.imageOfPage(at: 0) : nil)
        }
        func documentCameraViewControllerDidCancel(_ controller: VNDocumentCameraViewController) {
            onFinish(nil)
        }
        func documentCameraViewController(_ controller: VNDocumentCameraViewController,
                                          didFailWithError error: Error) {
            onFinish(nil)
        }
    }
}

// MARK: - カメラ

struct CameraPicker: UIViewControllerRepresentable {
    var onFinish: (UIImage?) -> Void

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let vc = UIImagePickerController()
        vc.sourceType = .camera
        vc.delegate = context.coordinator
        return vc
    }
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
    func makeCoordinator() -> Coordinator { Coordinator(onFinish: onFinish) }

    final class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let onFinish: (UIImage?) -> Void
        init(onFinish: @escaping (UIImage?) -> Void) { self.onFinish = onFinish }

        func imagePickerController(_ picker: UIImagePickerController,
                                   didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            onFinish(info[.originalImage] as? UIImage)
        }
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) { onFinish(nil) }
    }
}

// MARK: - 図面の拡大表示

struct ZoomImageView: View {
    let image: UIImage
    @Environment(\.dismiss) private var dismiss
    @State private var scale: CGFloat = 1
    @State private var lastScale: CGFloat = 1
    @State private var offset: CGSize = .zero
    @State private var lastOffset: CGSize = .zero

    var body: some View {
        ZStack(alignment: .topTrailing) {
            Color.black.ignoresSafeArea()
            Image(uiImage: image)
                .resizable()
                .scaledToFit()
                .scaleEffect(scale)
                .offset(offset)
                .gesture(
                    MagnifyGesture()
                        .onChanged { scale = max(1, lastScale * $0.magnification) }
                        .onEnded { _ in lastScale = scale }
                        .simultaneously(with: DragGesture()
                            .onChanged { offset = CGSize(width: lastOffset.width + $0.translation.width,
                                                         height: lastOffset.height + $0.translation.height) }
                            .onEnded { _ in lastOffset = offset })
                )
                .onTapGesture(count: 2) {
                    scale = 1; lastScale = 1; offset = .zero; lastOffset = .zero
                }
            Button {
                dismiss()
            } label: {
                Image(systemName: "xmark.circle.fill").font(.largeTitle).foregroundStyle(.white)
            }
            .padding()
        }
    }
}

// MARK: - 問題点の表示

struct IssueList: View {
    let issues: [Issue]
    var body: some View {
        ForEach(issues) { issue in
            Label(issue.message,
                  systemImage: issue.severity == .error ? "exclamationmark.octagon.fill" : "exclamationmark.triangle.fill")
                .font(.subheadline)
                .foregroundStyle(issue.severity == .error ? .red : .orange)
        }
    }
}
