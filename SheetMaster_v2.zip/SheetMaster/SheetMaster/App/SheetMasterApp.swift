import SwiftUI

@main
struct SheetMasterApp: App {
    @State private var store = JobStore()
    @State private var settings = AppSettings()

    var body: some Scene {
        WindowGroup {
            HomeView()
                .environment(store)
                .environment(settings)
        }
    }
}
